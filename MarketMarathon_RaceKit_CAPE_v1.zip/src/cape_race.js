/* ===========================================================================
   WORLD STOCK MARKETS BY CAPE RATIO | 1982-2026
   Market Marathon bar-chart-race renderer, CAPE edition.

     node src/cape_race.js [config.json]

   Architecture is deliberately identical to the channel's racekit_q.js:
   every frame is an SVG document built in Node, rasterised by @resvg/resvg-js,
   and piped as PNG into ffmpeg over image2pipe. 1920x1080 design grid,
   30 fps, Source Serif 4 SemiBold, no system fonts, no browser.

   It is a SEPARATE renderer rather than a fork of racekit_q.js because that
   engine takes "YYYY-Qn" quarters (this is monthly), fixes TOPN at 10,
   formats every value as a currency, and mandates a canonical period file
   with index, dividend and CPI series plus an ROI scoreboard - none of which
   exist or mean anything for a valuation ratio. The visual standard is
   reproduced here constant for constant; the market-cap furniture is not.

   Environment overrides (all optional):
     FPS SECONDS_PER_MONTH TOP_N RASTER_W OUT
     PREVIEW_FROM PREVIEW_TO   YYYY-MM, restrict the visible range
     STILL=<period>[,...]      write single frames to frames/ and exit
     LAYOUT=single|split       one board, or most-expensive vs cheapest
     DATA=data/....json        monthly or quarterly dataset
     NO_INTRO=1 NO_OUTRO=1 NO_HOLD=1
     SEG_START SEG_END         half-open frame range, for sharded renders
     PNG_DIR                   also dump every frame as a PNG
     FRAME_COUNT_ONLY=1        print the frame plan and exit
   ======================================================================== */
'use strict';
const { Resvg } = require('@resvg/resvg-js');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const CFG  = JSON.parse(fs.readFileSync(process.argv[2] || path.join(ROOT, 'config.json'), 'utf8'));
const P    = CFG.palette;

const W = CFG.VIDEO_WIDTH, H = CFG.VIDEO_HEIGHT;
const FPS    = +(process.env.FPS || CFG.FPS);
const SPM    = +(process.env.SECONDS_PER_PERIOD || process.env.SECONDS_PER_MONTH || CFG.SECONDS_PER_PERIOD || CFG.SECONDS_PER_MONTH);
const TOPN   = +(process.env.TOP_N || CFG.TOP_N);
const RASTER = +(process.env.RASTER_W || CFG.RASTER_W);
const K      = +CFG.RANK_TRANSITION_SPEED;

/* ---------- assets ------------------------------------------------------ */
const FONT = path.join(ROOT, CFG.font);
if (!fs.existsSync(FONT)) { console.error(`FATAL: font missing at ${FONT}`); process.exit(2); }

const FLAGS = (() => {
  const dir = path.join(ROOT, CFG.flags_dir), out = {};
  if (!fs.existsSync(dir)) return out;
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.png'))) {
    const b = fs.readFileSync(path.join(dir, f));
    out[f.replace('.png', '')] = { w: b.readUInt32BE(16), h: b.readUInt32BE(20),
                                   uri: 'data:image/png;base64,' + b.toString('base64') };
  }
  return out;
})();

const LOGO = (() => {
  const p = path.join(ROOT, CFG.logo || '');
  if (!CFG.logo || !fs.existsSync(p)) return null;
  const b = fs.readFileSync(p);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), uri: 'data:image/png;base64,' + b.toString('base64') };
})();

/* ---------- data -------------------------------------------------------- */
const DATA = JSON.parse(fs.readFileSync(path.join(ROOT, process.env.DATA || CFG.data), 'utf8'));
if (DATA.schema !== 'MarketMarathon-CAPE-Race-1') {
  console.error(`FATAL: unexpected dataset schema "${DATA.schema}". Rebuild with src/build_dataset.py.`);
  process.exit(2);
}
// Bar colours come from a named scheme, so swapping the whole board is one config line
// and never touches the dataset. A country's colour is fixed for the whole video.
const SCHEME = process.env.COLOUR_SCHEME || CFG.COLOUR_SCHEME;
if (SCHEME) {
  const pals = JSON.parse(fs.readFileSync(path.join(ROOT, CFG.palettes || 'data/palettes.json'), 'utf8'));
  const pal = pals[SCHEME];
  if (!pal) { console.error(`FATAL: unknown COLOUR_SCHEME "${SCHEME}". Known: ${Object.keys(pals).filter(k => k[0] !== '_').join(', ')}`); process.exit(2); }
  const missing = DATA.countries.filter(c => !pal[c.label]).map(c => c.label);
  if (missing.length) { console.error(`FATAL: scheme "${SCHEME}" has no colour for: ${missing.join(', ')}`); process.exit(2); }
  for (const c of DATA.countries) c.colour = pal[c.label];
}
// region key for the intro card - only drawn when the colour scheme carries meaning
const LEGEND = (SCHEME === 'region' && fs.existsSync(path.join(ROOT, 'data/region_legend.json')))
  ? JSON.parse(fs.readFileSync(path.join(ROOT, 'data/region_legend.json'), 'utf8')).regions : null;
const EV = CFG.events && fs.existsSync(path.join(ROOT, CFG.events))
  ? JSON.parse(fs.readFileSync(path.join(ROOT, CFG.events), 'utf8')) : { label: '', events: [] };

const QUARTERLY = DATA.period_kind === 'quarter';
const PARTIAL = DATA.partial_periods || [];
const QN = ['FIRST QUARTER', 'SECOND QUARTER', 'THIRD QUARTER', 'FOURTH QUARTER'];
const ALLP = DATA.periods;                       // includes 1981-12, source history
const iOf = p => ALLP.indexOf(p);

const VIS_FROM = process.env.PREVIEW_FROM || (QUARTERLY ? DATA.visible_from : CFG.VISIBLE_START_DATE);
const VIS_TO   = process.env.PREVIEW_TO   || (QUARTERLY ? DATA.visible_to   : CFG.VISIBLE_END_DATE);
const A = iOf(VIS_FROM), B = iOf(VIS_TO);
if (A < 0 || B < 0 || B < A) {
  console.error(`FATAL: visible range ${VIS_FROM}..${VIS_TO} is not in the dataset (${ALLP[0]}..${ALLP[ALLP.length-1]}).`);
  process.exit(2);
}
const VIS = ALLP.slice(A, B + 1);                // the months actually shown
const NV = VIS.length;

const CO = DATA.countries;
const vals = CO.map(c => c.vals.map(v => (v == null ? 0 : v)));
const hasv = CO.map(c => c.vals.map(v => v != null && v > 0));

/* value at a continuous period position, interpolated between genuine months.
   These intermediate numbers are ANIMATION ONLY and are never written back. */
const lerp = (a, b, t) => a + (b - a) * t;
const vAt = (ci, pi) => {
  const i = Math.max(0, Math.min(ALLP.length - 1, Math.floor(pi)));
  const j = Math.min(i + 1, ALLP.length - 1);
  const f = pi - Math.floor(pi);
  const a = hasv[ci][i] ? vals[ci][i] : 0;
  const b = hasv[ci][j] ? vals[ci][j] : 0;
  return lerp(a, b, f);
};

/* ---------- timeline ---------------------------------------------------- */
const pacingFactor = p => {
  if (!CFG.VARIABLE_PACING) return 1;
  let f = 1;
  for (const wnd of (CFG.PACING_WINDOWS || [])) if (p >= wnd.from && p <= wnd.to) f = Math.max(f, wnd.factor);
  return f;
};
// frames spent travelling FROM visible month m TO m+1 (the last month has none)
const stepFrames = [];
for (let m = 0; m < NV - 1; m++) stepFrames.push(Math.max(1, Math.round(SPM * pacingFactor(VIS[m]) * FPS)));
const cum = [0];
for (const f of stepFrames) cum.push(cum[cum.length - 1] + f);
const RACE_FR = cum[cum.length - 1];

const INTRO_FR = process.env.NO_INTRO ? 0 : Math.round(+CFG.INTRO_DURATION * FPS);
const HOLD_FR  = process.env.NO_HOLD  ? 0 : Math.round(+CFG.ENDING_HOLD_DURATION * FPS);
const OUTRO_FR = process.env.NO_OUTRO ? 0 : Math.round(+CFG.OUTRO_DURATION * FPS);
const COVER_FR = (process.env.NO_COVERAGE || !CFG.coverage_heading) ? 0 : Math.round(+(CFG.COVERAGE_DURATION || 0) * FPS);
const TOTAL_FR = INTRO_FR + RACE_FR + HOLD_FR + COVER_FR + OUTRO_FR;
const FADE_FR  = Math.round(0.8 * FPS);          // intro -> board dissolve

// race frame -> continuous absolute period index
const posAt = fr => {
  if (fr >= RACE_FR) return A + NV - 1;
  let m = 0; while (m < stepFrames.length && cum[m + 1] <= fr) m++;
  const inM = fr - cum[m];
  return A + m + (stepFrames[m] ? inM / stepFrames[m] : 0);
};

if (process.env.FRAME_COUNT_ONLY) {
  console.log(`FRAMES ${TOTAL_FR} INTRO ${INTRO_FR} RACE ${RACE_FR} HOLD ${HOLD_FR} COVERAGE ${COVER_FR} OUTRO ${OUTRO_FR} FPS ${FPS}`);
  console.log(`MONTHS ${NV} (${VIS[0]} to ${VIS[NV-1]})  DURATION ${(TOTAL_FR/FPS/60).toFixed(2)} min`);
  process.exit(0);
}

/* ---------- geometry (brand constants) ---------------------------------- */
const LAYOUT = (process.env.LAYOUT || CFG.LAYOUT || 'single').toLowerCase();   // 'single' | 'split'
if (!['single', 'split'].includes(LAYOUT)) { console.error(`FATAL: LAYOUT must be single or split, got "${LAYOUT}"`); process.exit(2); }
const M = { top: LAYOUT === 'split' ? 274 : 230, left: 430, bottom: 160 };
const chartH = H - M.top - M.bottom;
const ROWS = LAYOUT === 'split' ? +(CFG.SPLIT_PER_SIDE || 10) : TOPN;   // the MAXIMUM rows a board shows
const MIN_ROWS = Math.min(ROWS, +(CFG.MIN_ROWS || 8));
const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
const GRIDS = +CFG.AXIS_GRIDLINES;
// Rows are dynamic: early on only eleven markets exist, and a board of twenty slots
// would be two thirds empty. rowsCur eases toward what the field actually needs, so
// the board fills the frame throughout and thickens as markets join.
let rowsCur = null;
const RE = { rowH: 0, barH: 0, name: 0, value: 0, fw: 0, fh: 0 };
function setRows(v) {
  rowsCur = v;
  RE.rowH  = chartH / rowsCur;
  RE.barH  = RE.rowH * (1 - +CFG.BAR_GAP);
  RE.name  = clampN(RE.rowH * 0.46, 15, 28);
  RE.value = clampN(RE.rowH * 0.45, 14, 28);
  RE.fh    = Math.round(clampN(RE.rowH * 0.62, 13, 36));
  RE.fw    = Math.round(RE.fh * 4 / 3);
}
setRows(ROWS);
const rowsTargetFor = need => clampN(need, MIN_ROWS, ROWS);
const rowY = r => M.top + r * RE.rowH + (RE.rowH - RE.barH) / 2;
const FADE_EDGE = () => M.top + (rowsCur + (+CFG.BAR_GAP) / 2) * RE.rowH;
const FLAG_W_MAX = Math.round(clampN(chartH / MIN_ROWS * 0.62, 13, 36) * 4 / 3);

/* One descriptor per board. `sign` is the direction bars grow; every x is a canvas x. */
const SIDES = LAYOUT === 'split'
  ? [{ key: 'L', sign:  1, flagX: 150 - FLAG_W_MAX, nameX: 372,     anchor: 'end',   barX: 394,     width: 470,
       plateA: 56,      plateB: 380,     heading: CFG.SPLIT_HEADING_LEFT  || 'MOST EXPENSIVE', headX: 60,     headAnchor: 'start' },
     { key: 'R', sign: -1, flagX: W - 150,      nameX: W - 372, anchor: 'start', barX: W - 394, width: 470,
       plateA: W - 380, plateB: W - 56,  heading: CFG.SPLIT_HEADING_RIGHT || 'CHEAPEST',       headX: W - 60, headAnchor: 'end' }]
  : [{ key: 'S', sign: 1, flagX: 150 - FLAG_W_MAX, nameX: M.left - 22, anchor: 'end', barX: M.left, width: 1540 - M.left,
       plateA: 56, plateB: M.left - 14, heading: null, headX: 60, headAnchor: 'start' }];

/* ---------- text helpers ------------------------------------------------ */
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const GLYPH = 0.515;                             // Source Serif 4 SemiBold, mixed case, measured average
const widthOf = (s, px) => String(s).length * px * GLYPH;
const fit = (s, px, maxW, floor) => { let f = px; while (f > floor && widthOf(s, f) > maxW) f -= 0.5; return f; };
const MONN = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
const fmtVal = v => (CFG.VALUE_PREFIX || '') + v.toFixed(+CFG.VALUE_DECIMALS) + (CFG.VALUE_SUFFIX || '');
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lum = hex => { const n = parseInt(hex.slice(1), 16), r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
  const f = c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
const onBar = hex => lum(hex) > 0.34 ? '#12202f' : '#ffffff';   // keep the value legible on every bar
const smooth = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };

/* ---------- axis -------------------------------------------------------- */
const LADDER = CFG.AXIS_LADDER.slice().sort((a, b) => a - b);
const axisTargetFor = (peak, floor) => {
  const need = Math.max(peak * +CFG.AXIS_HEADROOM, floor);
  for (const s of LADDER) if (s >= need) return s;
  return LADDER[LADDER.length - 1];
};
const axisCur = {};                    // eased per board, so ordinary periods never rescale it

/* ---------- stateful row glide ------------------------------------------ */
// one y per country PER BOARD. A country off a board sits at its parked row with
// alpha 0, so it rises into view rather than popping in.
const curY = {};
for (const sd of SIDES) curY[sd.key] = new Array(CO.length).fill(null);

/* ---------- deterministic easing tables --------------------------------- */
// Every frame must be a pure function of its index or a sharded render shows seams.
// The row count and each board's axis ceiling are eased ONCE across the whole
// timeline here, so shard 14 draws frame 4900 exactly as a single pass would.
const ROWS_AT = new Float32Array(RACE_FR + 1);
const AXIS_AT = {};
for (const sd of SIDES) AXIS_AT[sd.key] = new Float32Array(RACE_FR + 1);
(function precompute() {
  const eR = +(CFG.ROWS_EASE || 0.02), eA = +CFG.AXIS_EASE;
  let r = null; const a = {};
  for (let f = 0; f <= RACE_FR; f++) {
    const pi = posAt(f);
    const now = CO.map((c, ci) => ({ ci, v: vAt(ci, pi) }));
    const bs = boards(now);
    const tR = rowsTargetFor(Math.max(...bs.map(b => b.items.length)));
    r = (r == null) ? tR : r + (tR - r) * eR;
    ROWS_AT[f] = r;
    for (const b of bs) {
      const peak = b.items.length ? Math.max(...b.items.map(o => o.v)) : b.floor;
      const t = axisTargetFor(peak, b.floor);
      a[b.sd.key] = (a[b.sd.key] == null) ? t : a[b.sd.key] + (t - a[b.sd.key]) * eA;
      AXIS_AT[b.sd.key][f] = a[b.sd.key];
    }
  }
})();

/* ---------- drawing ----------------------------------------------------- */
// which countries each board shows this frame, and at what rank
function boards(now) {
  const live = now.filter(o => o.v > 0);
  const desc = live.slice().sort((a, b) => b.v - a.v);
  if (LAYOUT === 'single') return [{ sd: SIDES[0], items: desc, floor: +CFG.AXIS_MIN_CEILING }];
  // 10 a side, but never the same country twice: with fewer than 20 markets the
  // field is split down the middle instead of overlapping.
  const n = live.length, per = +(CFG.SPLIT_PER_SIDE || 10);
  const nL = Math.min(per, Math.ceil(n / 2)), nR = Math.min(per, Math.floor(n / 2));
  const L = desc.slice(0, nL);
  const R = desc.slice(n - nR).reverse();                 // cheapest first
  return [{ sd: SIDES[0], items: L, floor: +CFG.AXIS_MIN_CEILING },
          { sd: SIDES[1], items: R, floor: +(CFG.AXIS_MIN_CEILING_CHEAP || 20) }];
}

function drawSide(g, sd, items, floor, rf) {
  const { rowH, barH } = RE;
  const peak = items.length ? Math.max(...items.map(o => o.v)) : floor;
  const tgt = axisTargetFor(peak, floor);
  const xmax = Math.max(AXIS_AT[sd.key][rf], 1), x = v => sd.width * (v / xmax);

  // row glide
  const cy = curY[sd.key];
  const rank = new Array(CO.length).fill(999);
  items.forEach((o, r) => rank[o.ci] = r);
  for (let ci = 0; ci < CO.length; ci++) {
    const t = rowY(Math.min(rank[ci], Math.round(rowsCur)));
    cy[ci] = (cy[ci] == null) ? t : cy[ci] + (t - cy[ci]) * K;
  }

  if (CFG.SHOW_AXIS) {
    let step = 5; for (const c of [5, 10, 20, 25, 50]) { step = c; if (tgt / c <= GRIDS + 1) break; }
    for (let t = 0; t * step <= xmax + 1e-6; t++) {
      const gv = t * step, gx = sd.barX + sd.sign * x(gv);
      g.push(`<line x1="${gx.toFixed(1)}" y1="${M.top - 8}" x2="${gx.toFixed(1)}" y2="${(M.top + chartH).toFixed(1)}" stroke="${P.gridline}" stroke-opacity="${P.gridline_opacity}"/>`);
      g.push(`<text x="${gx.toFixed(1)}" y="${M.top - 18}" font-size="20" fill="${P.axis_label}" text-anchor="middle">${gv.toFixed(0)}</text>`);
    }
    if (sd.sign > 0) g.push(`<text x="${sd.nameX}" y="${M.top - 18}" font-size="15" fill="${P.axis_label}" text-anchor="end" letter-spacing="1.4">CAPE</text>`);
  }
  if (sd.heading) {
    g.push(`<text x="${sd.headX}" y="${M.top - 62}" font-size="26" font-weight="700" fill="${P.gold}" text-anchor="${sd.headAnchor}" letter-spacing="3">${esc(sd.heading)}</text>`);
    g.push(`<text x="${sd.headX}" y="${M.top - 38}" font-size="14" fill="${P.footer}" text-anchor="${sd.headAnchor}" letter-spacing="1.2">own scale \u00b7 0 to ${Math.round(xmax)}\u00d7</text>`);
  }

  // bars, painted bottom-up so a rising bar crosses over the one it passes
  const vis = items.filter(o => cy[o.ci] < FADE_EDGE() + 2).sort((a, b) => cy[b.ci] - cy[a.ci]);
  for (const o of vis) {
    const c = CO[o.ci], y = cy[o.ci];
    const a = clamp((FADE_EDGE() - y) / rowH, 0, 1);
    if (a <= 0.01) continue;
    const w = Math.max(3, x(o.v)), mid = y + barH / 2;
    g.push(`<g opacity="${a.toFixed(3)}">`);
    // opaque plate in the label gutter: bars are painted bottom-up, so when two rows
    // cross, the upper one's plate covers the lower one's name instead of overprinting
    g.push(`<rect x="${sd.plateA}" y="${(mid - rowH * 0.5).toFixed(1)}" width="${(sd.plateB - sd.plateA).toFixed(1)}" height="${rowH.toFixed(1)}" fill="${P.bg}"/>`);
    const bx = sd.sign > 0 ? sd.barX : sd.barX - w;
    g.push(`<rect x="${bx.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${barH.toFixed(1)}" fill="${c.colour}"/>`);
    if (CFG.SHOW_FLAGS && FLAGS[c.iso]) {
      const fx = sd.sign > 0 ? sd.flagX + (FLAG_W_MAX - RE.fw) : sd.flagX, fy = mid - RE.fh / 2;
      g.push(`<rect x="${fx - 1}" y="${(fy - 1).toFixed(1)}" width="${RE.fw + 2}" height="${RE.fh + 2}" fill="#ffffff" fill-opacity="0.16"/>`);
      g.push(`<image x="${fx}" y="${fy.toFixed(1)}" width="${RE.fw}" height="${RE.fh}" preserveAspectRatio="none" href="${FLAGS[c.iso].uri}"/>`);
    }
    const avail = Math.abs(sd.nameX - (sd.flagX + (sd.sign > 0 ? FLAG_W_MAX + 16 : -16)));
    const np = fit(c.label, RE.name, avail, 13);
    g.push(`<text x="${sd.nameX}" y="${(mid + np * 0.34).toFixed(1)}" font-size="${np.toFixed(1)}" font-weight="700" fill="${P.bar_label}" text-anchor="${sd.anchor}">${esc(c.label)}</text>`);
    // value: inside the bar wherever it fits, so two rows crossing never overprint
    const vs = fmtVal(o.v), vw = widthOf(vs, RE.value), vy = mid + RE.value * 0.36;
    if (w > vw + 42) {
      const vx = sd.barX + sd.sign * (w - 18);
      g.push(`<text x="${vx.toFixed(1)}" y="${vy.toFixed(1)}" font-size="${RE.value.toFixed(1)}" font-weight="600" fill="${onBar(c.colour)}" text-anchor="${sd.sign > 0 ? 'end' : 'start'}">${vs}</text>`);
    } else {
      const vx = sd.barX + sd.sign * (w + 16);
      g.push(`<text x="${vx.toFixed(1)}" y="${vy.toFixed(1)}" font-size="${RE.value.toFixed(1)}" font-weight="600" fill="${P.bar_value}" text-anchor="${sd.sign > 0 ? 'start' : 'end'}">${vs}</text>`);
    }
    g.push(`</g>`);
  }
}

function board(fr, opacity, holdTag) {
  const rf = Math.max(0, Math.min(RACE_FR, Math.round(fr)));
  const pi = posAt(fr);
  const now = CO.map((c, ci) => ({ ci, v: vAt(ci, pi) }));
  const g = [];
  const bs = boards(now);
  setRows(ROWS_AT[rf]);
  for (const b of bs) drawSide(g, b.sd, b.items, b.floor, rf);
  if (LAYOUT === 'split') g.push(`<line x1="960" y1="${M.top - 30}" x2="960" y2="${(M.top + chartH).toFixed(1)}" stroke="${P.rule}" stroke-width="2"/>`);
  const s = [`<g opacity="${opacity.toFixed(3)}">${g.join('')}</g>`];

  /* ---- furniture ---- */
  const f = [];
  const monthIdx = Math.min(ALLP.length - 1, Math.round(pi));
  const per = ALLP[monthIdx];
  const yy = per.slice(0, 4);
  const sub = QUARTERLY ? QN[+per.slice(5) - 1] + (PARTIAL.includes(per) ? ' · PART QUARTER' : '')
                        : MONN[+per.slice(5, 7) - 1];

  f.push(`<text x="60" y="96" font-size="54" font-weight="700" fill="${P.title}" letter-spacing="0.5">${esc(CFG.title_line_1)}</text>`);
  f.push(`<text x="60" y="148" font-size="54" font-weight="700" fill="${P.title}" letter-spacing="0.5">${esc(CFG.title_line_2)}</text>`);
  f.push(`<text x="${60 + widthOf(CFG.title_line_2, 54) + 26}" y="148" font-size="26" fill="${P.subtitle}">${esc(CFG.subtitle)}</text>`);
  f.push(`<text x="1880" y="118" font-size="96" font-weight="700" fill="${P.year}" text-anchor="end">${yy}</text>`);
  const subPx = sub.length > 14 ? 19 : 23;
  f.push(`<text x="1880" y="154" font-size="${subPx}" font-weight="700" fill="${P.gold}" text-anchor="end" letter-spacing="${subPx > 20 ? 3.2 : 2}">${esc(sub)}</text>`);
  if (holdTag) {
    const mw = widthOf(sub, subPx) + sub.length * (subPx > 20 ? 3.2 : 2) + 22;
    f.push(`<text x="${(1880 - mw).toFixed(0)}" y="154" font-size="15" font-weight="600" fill="${P.footer}" text-anchor="end" letter-spacing="1.6">LATEST BARCLAYS OBSERVATION</text>`);
  }
  f.push(`<line x1="60" y1="178" x2="1880" y2="178" stroke="${P.rule}" stroke-width="2"/>`);

  if (CFG.SHOW_EVENT_CAPTIONS) {
    // Two caption shapes are supported. A country story is keyed to one quarter and
    // names its market; a global event still uses a YYYY-MM range. A story stays up for
    // CAPTION_QUARTERS so there is time to read it.
    let pa = per, pb = per;
    if (QUARTERLY) { const y = per.slice(0, 4), q = +per.slice(5);
      pa = `${y}-${String(q * 3 - 2).padStart(2, '0')}`; pb = `${y}-${String(q * 3).padStart(2, '0')}`; }
    const hold = Math.max(1, +(CFG.CAPTION_QUARTERS || 2));
    let e = null, head = EV.label || 'MARKET CONTEXT';
    // A caption for THIS period always wins over one still being held from an earlier
    // period, otherwise consecutive captions block each other.
    let held = null;
    for (const ev of (EV.events || [])) {
      if (ev.quarter) {
        const k = ALLP.indexOf(ev.quarter);
        if (k < 0) continue;
        if (monthIdx === k) { e = ev; break; }
        if (!held && monthIdx > k && monthIdx < k + hold) held = ev;
      } else if (!held && pa <= ev.to && pb >= ev.from) held = ev;
    }
    e = e || held;
    if (e && e.quarter) head = (e.country ? e.country.toUpperCase() + '  \u00b7  ' : '')
      + (QUARTERLY ? `${e.quarter.slice(0,4)} Q${e.quarter.slice(5)}` : e.quarter);
    if (e) {
      f.push(`<text x="60" y="1006" font-size="13" font-weight="700" fill="${P.gold}" letter-spacing="1.4">${esc(head)}</text>`);
      const cp = fit(e.text, 22, 1540, 15);
      f.push(`<text x="60" y="1036" font-size="${cp}" font-weight="600" fill="${P.caption}">${esc(e.text)}</text>`);
    } else if (monthIdx - A < +(QUARTERLY ? (CFG.SHOW_MEASURE_NOTE_QUARTERS || 8) : CFG.SHOW_MEASURE_NOTE_MONTHS)) {
      const cp = fit(CFG.measure_note, 19, 1540, 14);
      f.push(`<text x="60" y="1036" font-size="${cp}" font-weight="600" fill="${P.subtitle}">${esc(CFG.measure_note)}</text>`);
    }
  }
  const foot = (QUARTERLY ? CFG.footer_line_quarterly : CFG.footer_line_monthly)
             + (LAYOUT === 'split' ? (CFG.footer_add_split || '') : '');
  const fp = fit(foot, 15, 1560, 11);
  f.push(`<text x="60" y="1064" font-size="${fp}" fill="${P.footer}">${esc(foot)}</text>`);
  if (CFG.SHOW_LOGO && LOGO) {
    const lw = 180, lh = lw * LOGO.h / LOGO.w;
    f.push(`<image x="${1880 - lw}" y="${1046 - lh}" width="${lw}" height="${lh.toFixed(1)}" preserveAspectRatio="xMaxYMid meet" href="${LOGO.uri}"/>`);
  }
  s.push(`<g opacity="${opacity.toFixed(3)}">${f.join('')}</g>`);
  return s.join('');
}


function intro(fr) {
  const t = fr / FPS, T = INTRO_FR / FPS;
  const a1 = smooth((t - 0.25) / 1.0), a2 = smooth((t - 1.0) / 1.0), a3 = smooth((t - 1.9) / 1.0);
  const out = clamp(1 - (t - (T - 0.7)) / 0.7, 0, 1);
  const s = [];
  s.push(`<g opacity="${out.toFixed(3)}">`);
  s.push(`<text x="960" y="452" font-size="82" font-weight="700" fill="${P.title}" text-anchor="middle" letter-spacing="1.2" opacity="${a1.toFixed(3)}">${esc(CFG.title_line_1)}</text>`);
  s.push(`<text x="960" y="546" font-size="82" font-weight="700" fill="${P.title}" text-anchor="middle" letter-spacing="1.2" opacity="${a1.toFixed(3)}">${esc(CFG.title_line_2)}</text>`);
  s.push(`<line x1="660" y1="600" x2="1260" y2="600" stroke="${P.gold}" stroke-opacity="0.45" stroke-width="1.6" opacity="${a2.toFixed(3)}"/>`);
  s.push(`<text x="960" y="662" font-size="44" font-weight="700" fill="${P.gold}" text-anchor="middle" letter-spacing="4" opacity="${a2.toFixed(3)}">${esc(CFG.subtitle)}</text>`);
  s.push(`<text x="960" y="724" font-size="24" font-weight="600" fill="${P.subtitle}" text-anchor="middle" letter-spacing="3.4" opacity="${a3.toFixed(3)}">${esc(CFG.intro_strapline)}</text>`);
  const cp = fit(CFG.measure_note, 18, 1400, 13);
  s.push(`<text x="960" y="790" font-size="${cp}" fill="${P.footer}" text-anchor="middle" opacity="${a3.toFixed(3)}">${esc(CFG.measure_note)}</text>`);
  if (LOGO) { const lw = 220, lh = lw * LOGO.h / LOGO.w;
    s.push(`<image x="${960 - lw / 2}" y="250" width="${lw}" height="${lh.toFixed(1)}" preserveAspectRatio="xMidYMid meet" href="${LOGO.uri}" opacity="${a1.toFixed(3)}"/>`); }
  if (LEGEND && CFG.SHOW_REGION_KEY !== false) {
    const a4 = smooth((t - 2.7) / 1.0);
    const keys = Object.keys(LEGEND), per = Math.ceil(keys.length / 2);
    s.push(`<text x="960" y="848" font-size="14" fill="${P.footer}" text-anchor="middle" letter-spacing="2.4" opacity="${a4.toFixed(3)}">BAR COLOUR SHOWS THE REGION</text>`);
    for (let r = 0; r < 2; r++) {
      const row = keys.slice(r * per, (r + 1) * per);
      const widths = row.map(k => 20 + 8 + widthOf(k, 17) + 30);
      const total = widths.reduce((x, y) => x + y, 0) - 30;
      let x = 960 - total / 2;
      row.forEach((k, i) => {
        s.push(`<rect x="${x.toFixed(1)}" y="${878 + r * 30}" width="20" height="13" fill="${LEGEND[k]}" opacity="${a4.toFixed(3)}"/>`);
        s.push(`<text x="${(x + 28).toFixed(1)}" y="${889 + r * 30}" font-size="17" fill="${P.subtitle}" opacity="${a4.toFixed(3)}">${esc(k)}</text>`);
        x += widths[i];
      });
    }
  }
  s.push(`</g>`);
  return s.join('');
}

// end-card naming the markets Barclays does not publish, so the absence is stated rather than discovered in the comments
function coverage(fr) {
  const t = fr / FPS, T = COVER_FR / FPS;
  const a1 = smooth((t - 0.15) / 0.8), a2 = smooth((t - 0.7) / 0.8);
  const out = clamp(1 - (t - (T - 0.7)) / 0.7, 0, 1);
  const G = CFG.coverage_groups || [];
  const s = [];
  s.push(`<g opacity="${out.toFixed(3)}">`);
  s.push(`<rect x="0" y="0" width="${W}" height="10" fill="${P.accent}" opacity="${a1.toFixed(3)}"/>`);
  s.push(`<text x="960" y="196" font-size="62" font-weight="700" fill="${P.title}" text-anchor="middle" letter-spacing="3" opacity="${a1.toFixed(3)}">${esc(CFG.coverage_heading)}</text>`);
  const ip = fit(CFG.coverage_intro_line, 27, 1560, 18);
  s.push(`<text x="960" y="252" font-size="${ip}" fill="${P.subtitle}" text-anchor="middle" opacity="${a1.toFixed(3)}">${esc(CFG.coverage_intro_line)}</text>`);
  s.push(`<line x1="560" y1="300" x2="1360" y2="300" stroke="${P.gold}" stroke-opacity="0.4" stroke-width="1.6" opacity="${a1.toFixed(3)}"/>`);
  // two columns, group label in gold above its members
  const per = Math.ceil(G.length / 2);
  const COLX = [620, 1300], ROWH = 140, TOP = 400;
  G.forEach((grp, i) => {
    const col = Math.floor(i / per), row = i % per;
    const x = COLX[col], y = TOP + row * ROWH;
    const a = smooth((t - 0.7 - i * 0.16) / 0.8);
    s.push(`<text x="${x}" y="${y}" font-size="24" font-weight="700" fill="${P.gold}" text-anchor="middle" letter-spacing="2.6" opacity="${a.toFixed(3)}">${esc(String(grp.label).toUpperCase())}</text>`);
    const mp = fit(grp.members, 28, 660, 19);
    s.push(`<text x="${x}" y="${y + 40}" font-size="${mp}" fill="${P.bar_label}" text-anchor="middle" opacity="${a.toFixed(3)}">${esc(grp.members)}</text>`);
  });
  const np = fit(CFG.coverage_note, 22, 1500, 15);
  s.push(`<text x="960" y="892" font-size="${np}" fill="${P.footer}" text-anchor="middle" opacity="${a2.toFixed(3)}">${esc(CFG.coverage_note)}</text>`);
  s.push(`</g>`);
  return s.join('');
}

function outro(fr) {
  const a = smooth(fr / (0.8 * FPS));
  const s = [];
  s.push(`<rect x="0" y="0" width="${W}" height="10" fill="${P.accent}" opacity="${a.toFixed(3)}"/>`);
  s.push(`<g opacity="${a.toFixed(3)}">`);
  if (LOGO) { const lw = 320, lh = lw * LOGO.h / LOGO.w;
    s.push(`<image x="${960 - lw / 2}" y="180" width="${lw}" height="${lh.toFixed(1)}" preserveAspectRatio="xMidYMid meet" href="${LOGO.uri}"/>`); }
  s.push(`<text x="960" y="386" font-size="50" font-weight="700" fill="#eef3f7" text-anchor="middle">Which market looks expensive to you?</text>`);
  s.push(`<text x="960" y="440" font-size="29" font-weight="600" fill="${P.gold}" text-anchor="middle">Share your view in the comments below</text>`);
  s.push(`<line x1="540" y1="492" x2="1380" y2="492" stroke="${P.gold}" stroke-opacity="0.35" stroke-width="1.4"/>`);
  s.push(`<text x="960" y="566" font-size="54" font-weight="700" fill="#f0f4f8" text-anchor="middle" letter-spacing="2">SUBSCRIBE     ·     LIKE     ·     COMMENT</text>`);
  s.push(`<text x="960" y="616" font-size="27" font-weight="600" fill="#96aab9" text-anchor="middle">for more Market Marathon bar chart races</text>`);
  s.push(`</g>`);
  return s.join('');
}

function frameSVG(g) {
  let body;
  if (g < INTRO_FR) {
    body = intro(g);
    const into = g - (INTRO_FR - FADE_FR);
    if (into >= 0) body += board(0, smooth(into / FADE_FR), false);   // dissolve to the first board
  } else if (g < INTRO_FR + RACE_FR) {
    body = board(g - INTRO_FR, 1, false);
  } else if (g < INTRO_FR + RACE_FR + HOLD_FR) {
    body = board(RACE_FR, 1, true);
  } else if (g < INTRO_FR + RACE_FR + HOLD_FR + COVER_FR) {
    const o = g - INTRO_FR - RACE_FR - HOLD_FR;
    const fade = clamp(1 - o / (0.6 * FPS), 0, 1);
    body = (fade > 0 ? board(RACE_FR, fade, true) : '') + coverage(o);
  } else {
    const o = g - INTRO_FR - RACE_FR - HOLD_FR - COVER_FR;
    const fade = COVER_FR ? 0 : clamp(1 - o / (0.6 * FPS), 0, 1);
    body = (fade > 0 ? board(RACE_FR, fade, true) : '') + outro(o);
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`
       + (process.env.TRANSPARENT ? '' : `<rect width="${W}" height="${H}" fill="${P.bg}"/>`)
       + `<g font-family="SourceSerif4 SemiBold">${body}</g></svg>`;
}

/* ---------- raster options --------------------------------------------- */
const ropts = { fitTo: { mode: 'width', value: RASTER },
  font: { loadSystemFonts: false, fontFiles: [FONT], defaultFontFamily: 'SourceSerif4 SemiBold' } };

/* ---------- stills ------------------------------------------------------ */
// STILL_FRAME=0,8000,16500 renders arbitrary GLOBAL frame indices (intro / coverage / outro cards)
if (process.env.STILL_FRAME) {
  const dir = path.join(ROOT, 'frames'); fs.mkdirSync(dir, { recursive: true });
  for (const raw of process.env.STILL_FRAME.split(',').map(s => s.trim())) {
    const g = Math.max(0, Math.min(TOTAL_FR - 1, parseInt(raw, 10)));
    for (const k of Object.keys(axisCur)) delete axisCur[k];
    for (const sd of SIDES) curY[sd.key].fill(null);
    rowsCur = null;
    const png = new Resvg(frameSVG(g), ropts).render().asPng();
    const out = path.join(dir, `CARD_${String(g).padStart(6, '0')}.png`);
    fs.writeFileSync(out, png);
    console.log(`  ${path.relative(ROOT, out)}  (frame ${g})`);
  }
  process.exit(0);
}

if (process.env.STILL) {
  const dir = path.join(ROOT, 'frames'); fs.mkdirSync(dir, { recursive: true });
  for (const want of process.env.STILL.split(',').map(s => s.trim())) {
    const k = VIS.indexOf(want);
    if (k < 0) { console.error(`  skip ${want} - outside the visible range`); continue; }
    const target = INTRO_FR + cum[Math.min(k, cum.length - 1)];
    for (const k of Object.keys(axisCur)) delete axisCur[k];
    for (const sd of SIDES) curY[sd.key].fill(null);
    rowsCur = null;
    const warm = Math.max(0, +(process.env.WARMUP_FRAMES || CFG.WARMUP_FRAMES));
    for (let g = Math.max(INTRO_FR, target - warm); g < target; g++) frameSVG(g);   // settle rows + axis
    const png = new Resvg(frameSVG(target), ropts).render().asPng();
    const out = path.join(dir, `CAPE_${LAYOUT === 'split' ? 'SPLIT_' : ''}${QUARTERLY ? 'Q_' : ''}${want}.png`);
    fs.writeFileSync(out, png);
    console.log(`  ${path.relative(ROOT, out)}  (${want})`);
  }
  process.exit(0);
}

/* ---------- segmented render ------------------------------------------- */
const SEG_A = Math.max(0, Math.floor(+(process.env.SEG_START || 0)));
const SEG_B = Math.min(TOTAL_FR, Math.ceil(+(process.env.SEG_END || TOTAL_FR)));
const WARM  = Math.max(0, +(process.env.WARMUP_FRAMES || CFG.WARMUP_FRAMES));
// The row glide and the axis ease are stateful, so a segment that starts mid-race
// is wound up to its own first frame before anything is emitted. Skip this and a
// shard boundary shows as a jump.
const WARM_A = Math.max(0, SEG_A - WARM);
const OUT = path.resolve(ROOT, process.env.OUT || CFG.out);
fs.mkdirSync(path.dirname(OUT), { recursive: true });
const PNG_DIR = process.env.PNG_DIR ? path.resolve(ROOT, process.env.PNG_DIR) : null;
if (PNG_DIR) fs.mkdirSync(PNG_DIR, { recursive: true });

const ff = spawn('ffmpeg', ['-y', '-thread_queue_size', '1024', '-f', 'image2pipe', '-c:v', 'png',
  '-r', String(FPS), '-i', 'pipe:0',
  '-c:v', 'libx264', '-crf', String(CFG.crf), '-preset', CFG.preset, '-pix_fmt', CFG.pix_fmt,
  '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
  '-x264-params', 'colorprim=bt709:transfer=bt709:colormatrix=bt709',
  '-movflags', '+faststart', '-stats_period', '20', OUT], { stdio: ['pipe', 'inherit', 'inherit'] });
ff.on('error', e => { console.error('FATAL: ffmpeg would not start -', e.message); process.exit(3); });

const write = buf => new Promise((res, rej) => ff.stdin.write(buf, e => e ? rej(e) : res()));

(async () => {
  const t0 = Date.now();
  let emitted = 0;
  console.error(`plan: ${TOTAL_FR} frames  (intro ${INTRO_FR} + race ${RACE_FR} + hold ${HOLD_FR} + coverage ${COVER_FR} + outro ${OUTRO_FR})  ${NV} months ${VIS[0]}..${VIS[NV-1]}  ${(TOTAL_FR/FPS).toFixed(1)}s @${FPS}fps`);
  if (WARM_A < SEG_A) console.error(`warm-up: ${SEG_A - WARM_A} frames drawn but not emitted, to settle the row glide`);
  for (let g = WARM_A; g < SEG_B; g++) {
    const svg = frameSVG(g);
    if (g < SEG_A) continue;                       // warm-up only
    // resvg allocates a native fontdb and image buffer per frame. Left to ordinary GC
    // these pile up and the process is OOM-killed a few hundred frames in, so the
    // handles are dropped explicitly and the collector is nudged on a fixed cadence.
    let r = new Resvg(svg, ropts), img = r.render(), png = img.asPng();
    if (typeof img.free === 'function') img.free();
    r = null; img = null;
    if (PNG_DIR) fs.writeFileSync(path.join(PNG_DIR, `f${String(g).padStart(6, '0')}.png`), png);
    await write(png);
    png = null;
    if (emitted % 20 === 19 && global.gc) global.gc();
    if (++emitted % 300 === 0) {
      const el = (Date.now() - t0) / 1000, r = emitted / el;
      const rss = (process.memoryUsage().rss / 1048576).toFixed(0);
      console.error(`  ${emitted}/${SEG_B - SEG_A} frames  ${r.toFixed(1)} fps  rss ${rss}MB  eta ${(((SEG_B - SEG_A) - emitted) / r / 60).toFixed(1)} min`);
    }
  }
  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  console.error(`done: ${emitted} frames -> ${path.relative(ROOT, OUT)}  in ${((Date.now() - t0) / 1000 / 60).toFixed(1)} min`);
})().catch(e => { console.error('FATAL:', e); process.exit(1); });
