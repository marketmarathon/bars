#!/usr/bin/env python3
"""
World Stock Markets by CAPE Ratio | 1982-2026
Build the race dataset from the validated workbook, and write a validation log.

  python3 src/build_dataset.py

Reads   : data/Global_CAPE_Final_v3.xlsx   sheet Monthly_Race_Wide
Writes  : data/cape_race_monthly.json      (the renderer's only data input)
          logs/validation_<date>.txt       (human readable)
          logs/validation_<date>.json      (machine readable)

It NEVER alters a CAPE value. Blanks stay blank. Nothing is interpolated here -
the renderer interpolates for animation only, between genuine monthly keyframes.
"""
import json, sys, hashlib, datetime, os
import pandas as pd, numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# The workbook lives one level up, in Bar Charts\CAPE\. A frozen copy is kept in data/
# so this project still builds if it is moved; the parent copy always wins.
_CANDIDATES = [os.path.join(ROOT, '..', 'Global_CAPE_Final_v3.xlsx'),
               os.path.join(ROOT, 'data', 'Global_CAPE_Final_v3.xlsx')]
XLSX = next((os.path.abspath(p) for p in _CANDIDATES if os.path.exists(p)), None)
if XLSX is None:
    sys.exit("FATAL: Global_CAPE_Final_v3.xlsx not found in the parent folder or in data/")
OUT  = os.path.join(ROOT, 'data', 'cape_race_monthly.json')
TODAY = datetime.date.today().isoformat()

VISIBLE_START = '1982-01'          # the video's stated period; 1981-12 is source history
EXPECTED_VISIBLE_MONTHS = 536
EXPECTED_LAST = '2026-08'
RUSSIA_LAST = '2022-02'

ISO = {'Australia':'au','Brazil':'br','Canada':'ca','China':'cn','France':'fr','Germany':'de',
 'Hong Kong':'hk','India':'in','Israel':'il','Italy':'it','Japan':'jp','Mexico':'mx',
 'Netherlands':'nl','Poland':'pl','Russia':'ru','Singapore':'sg','South Africa':'za',
 'South Korea':'kr','Spain':'es','Sweden':'se','Switzerland':'ch','Taiwan':'tw',
 'Turkey':'tr','United Kingdom':'gb','United States':'us'}

# Persistent identity colour per country. Derived from each flag's dominant hue,
# then held to one saturation/lightness band so the board reads as one system
# rather than a rainbow. A country NEVER changes colour.
COLOUR = {
 'Australia':'#1E4E8C','Brazil':'#1F9E5A','Canada':'#C8384B','China':'#C43D2E',
 'France':'#2F5FA8','Germany':'#C9952E','Hong Kong':'#B8464F','India':'#D2762E',
 'Israel':'#3E7FC1','Italy':'#2E8B57','Japan':'#CC4B5C','Mexico':'#2E7D5B',
 'Netherlands':'#D2713A','Poland':'#B9455C','Russia':'#4A6FA5','Singapore':'#BF4550',
 'South Africa':'#3C8C6A','South Korea':'#3B6FB0','Spain':'#B5452F','Sweden':'#2D6FA8',
 'Switzerland':'#B23E40','Taiwan':'#33629E','Turkey':'#BE4340','United Kingdom':'#3A5C9A',
 'United States':'#4573B8'}

def main():
    fail, log = [], []
    def chk(name, ok, detail=''):
        log.append({'check':name,'result':'PASS' if ok else 'FAIL','detail':detail})
        if not ok: fail.append(f'{name}: {detail}')
        print(('  PASS  ' if ok else '  FAIL  ')+name+(' - '+detail if detail else ''))

    print(f'CAPE race dataset build  {TODAY}\n')
    wb_bytes = open(XLSX,'rb').read()
    wb_sha = hashlib.sha256(wb_bytes).hexdigest()
    print(f'workbook : {os.path.basename(XLSX)}  {len(wb_bytes):,} bytes\nsha256   : {wb_sha}\n')

    df = pd.read_excel(XLSX, sheet_name='Monthly_Race_Wide')
    df = df[df['Date'].notna()].copy()
    df['Date'] = df['Date'].astype(str).str.strip()
    df = df[df['Date'].str.match(r'^\d{4}-\d{2}$')]
    countries = [c for c in df.columns if c != 'Date']

    print('INTEGRITY CHECKS')
    chk('Europe aggregate excluded', 'Europe' not in countries,
        'Europe column present' if 'Europe' in countries else 'not present in the race sheet')
    chk('Country list is the expected 25', sorted(countries)==sorted(ISO),
        f'{len(countries)} columns: '+', '.join(sorted(set(countries)^set(ISO))) if sorted(countries)!=sorted(ISO) else '25 countries, names match the ISO map')
    chk('No duplicate dates', not df['Date'].duplicated().any(), f'{int(df["Date"].duplicated().sum())} duplicates')

    for c in countries: df[c] = pd.to_numeric(df[c], errors='coerce')

    # zero / error-marker guards
    nz = int((df[countries] == 0).sum().sum())
    chk('No zero placeholders in the data', nz == 0, f'{nz} zero cells')
    nonnum = int(df[countries].map(lambda v: isinstance(v,str)).sum().sum()) if hasattr(df[countries],'map') else 0
    chk('No error markers reach the chart', nonnum == 0, 'all cells numeric or blank')

    df = df.sort_values('Date').reset_index(drop=True)
    all_periods = df['Date'].tolist()
    chk('Source starts at 1981-12', all_periods[0]=='1981-12', f'first source row {all_periods[0]}')
    chk(f'Source ends at {EXPECTED_LAST}', all_periods[-1]==EXPECTED_LAST, f'last source row {all_periods[-1]}')

    # month continuity
    pi = pd.PeriodIndex(all_periods, freq='M')
    gaps = [str(pi[i-1]) for i in range(1,len(pi)) if (pi[i]-pi[i-1]).n != 1]
    chk('No missing months in the source', not gaps, f'gaps after: {gaps[:5]}')

    visible = [p for p in all_periods if p >= VISIBLE_START]
    chk(f'Visible race starts {VISIBLE_START}', visible[0]==VISIBLE_START, f'first visible {visible[0]}')
    chk(f'Visible race is {EXPECTED_VISIBLE_MONTHS} months', len(visible)==EXPECTED_VISIBLE_MONTHS, f'{len(visible)} visible months')
    chk('1981-12 retained in the file but not visible', all_periods[0]=='1981-12' and '1981-12' not in visible,
        'held as the preceding observation for animation continuity only')

    # Russia
    rus = df.loc[df['Russia'].notna(),'Date']
    chk(f'Russia absent after {RUSSIA_LAST}', rus.max()==RUSSIA_LAST, f'last Russia observation {rus.max()}')

    # entry months
    entry = {c: df.loc[df[c].notna(),'Date'].min() for c in countries}
    last  = {c: df.loc[df[c].notna(),'Date'].max() for c in countries}
    counts= {c: int(df[c].notna().sum()) for c in countries}

    # contiguity: exactly one run of data per country
    noncontig=[]
    for c in countries:
        m = df[c].notna().values
        i0, i1 = m.argmax(), len(m)-1-m[::-1].argmax()
        if (~m[i0:i1+1]).sum(): noncontig.append(c)
    chk('Every country series is one contiguous run', not noncontig, f'interior gaps in: {noncontig}')

    # value fidelity against the workbook, to 2dp
    src = pd.read_excel(XLSX, sheet_name='Monthly_Race_Wide')
    src = src[src['Date'].astype(str).str.match(r'^\d{4}-\d{2}$')].set_index('Date')
    cmpdf = df.set_index('Date')[countries].round(2)
    ref = src[countries].apply(pd.to_numeric, errors='coerce').round(2)
    same = (cmpdf.isna()==ref.isna()).all().all() and float(np.nanmax(np.abs((cmpdf-ref).values)) if cmpdf.notna().any().any() else 0) < 1e-9
    chk('Values identical to Global_CAPE_Final_v3.xlsx', same, 'all cells match to 2dp, blanks match')

    # sanity band
    vals = df[countries].values.astype(float); vals = vals[~np.isnan(vals)]
    chk('All values in a plausible CAPE band', float(vals.min())>1 and float(vals.max())<200,
        f'min {vals.min():.2f} max {vals.max():.2f}')

    if fail:
        print('\n*** VALIDATION FAILED - not writing the dataset ***')
        for f in fail: print('   ', f)
        sys.exit(1)

    out = {
      'schema': 'MarketMarathon-CAPE-Race-1',
      'title': 'World Stock Markets by CAPE Ratio',
      'subtitle': '1982-2026',
      'measure': 'CAPE ratio (cyclically adjusted price-to-earnings)',
      'value_format': {'decimals': 1, 'suffix': '×', 'prefix': ''},
      'provider': 'Barclays Indices',
      'dataset': 'Historic CAPE Ratio by Country (Shiller Barclays CAPE framework)',
      'source_workbook': os.path.basename(XLSX),
      'source_workbook_sha256': wb_sha,
      'built': TODAY,
      'periods': all_periods,
      'visible_from': VISIBLE_START,
      'visible_to': EXPECTED_LAST,
      'visible_months': len(visible),
      'countries': [
        {'label': c, 'iso': ISO[c], 'colour': COLOUR[c],
         'first_month': entry[c], 'last_month': last[c], 'observations': counts[c],
         'vals': [None if pd.isna(v) else round(float(v),2) for v in df[c]]}
        for c in sorted(countries)],
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT,'w') as f: json.dump(out,f,indent=1)
    ds = hashlib.sha256(open(OUT,'rb').read()).hexdigest()

    lines=[f'WORLD STOCK MARKETS BY CAPE RATIO | 1982-2026',
           f'Dataset validation log - {TODAY}','',
           f'Source workbook   : {os.path.basename(XLSX)}',
           f'Workbook SHA-256  : {wb_sha}',
           f'Sheet             : Monthly_Race_Wide',
           f'Dataset written   : {os.path.basename(OUT)}',
           f'Dataset SHA-256   : {ds}','',
           f'Source months     : {len(all_periods)}  ({all_periods[0]} to {all_periods[-1]})',
           f'Visible months    : {len(visible)}  ({visible[0]} to {visible[-1]})',
           f'Countries         : {len(countries)}','','CHECKS','']
    for r in log: lines.append(f"  [{r['result']}] {r['check']}" + (f" - {r['detail']}" if r['detail'] else ''))
    lines += ['','COUNTRY ENTRY AND EXIT','',
              f"  {'Country':16s} {'first':>8s} {'last':>8s} {'obs':>5s}"]
    for c in sorted(countries):
        lines.append(f'  {c:16s} {entry[c]:>8s} {last[c]:>8s} {counts[c]:5d}')
    lines += ['', 'No value was altered, interpolated, back-filled or carried forward.',
              'Animation interpolation happens in the renderer only, between genuine monthly keyframes,',
              'and is never written back to this dataset.']
    os.makedirs(os.path.join(ROOT,'logs'), exist_ok=True)
    open(os.path.join(ROOT,'logs',f'validation_{TODAY}.txt'),'w').write('\n'.join(lines)+'\n')
    json.dump({'built':TODAY,'workbook_sha256':wb_sha,'dataset_sha256':ds,
               'source_months':len(all_periods),'visible_months':len(visible),
               'countries':len(countries),'checks':log,
               'entry':entry,'last':last,'observations':counts},
              open(os.path.join(ROOT,'logs',f'validation_{TODAY}.json'),'w'), indent=1, default=str)

    # ---------------------------------------------------------------- quarterly
    # Quarterly CAPE = arithmetic mean of that quarter's monthly observations.
    # A quarter is only shown when ALL THREE months exist, with one exception: the
    # final quarter of the dataset, which is marked PART QUARTER. Same rule as the
    # annual sheet, so a country enters the quarterly race in its first complete
    # quarter. These averages are DERIVED - they are not Barclays observations.
    dfq = df.set_index('Date').copy()
    dfq.index = pd.PeriodIndex(dfq.index, freq='M')
    qidx = dfq.index.asfreq('Q')
    allq = sorted({str(q) for q in qidx})
    last_q = str(qidx[-1])
    months_in_last_q = int((qidx == qidx[-1]).sum())
    qvals, qcount = {}, {}
    for c in countries:
        col, cnt = [], []
        for q in allq:
            m = dfq[c][qidx == pd.Period(q, freq='Q')]
            got = int(m.notna().sum())
            need = 3 if q != last_q else months_in_last_q
            cnt.append(got)
            col.append(round(float(m.mean()), 2) if got == need and got > 0 else None)
        qvals[c], qcount[c] = col, cnt
    vis_q = [q for q in allq if q >= '1982Q1']
    qout = dict(out)
    qout.update({
      'periods': allq, 'period_kind': 'quarter',
      'visible_from': '1982Q1', 'visible_to': last_q,
      'visible_months': len(vis_q),
      'partial_periods': [last_q] if months_in_last_q < 3 else [],
      'partial_period_months': months_in_last_q,
      'measure': 'CAPE ratio, quarterly average of the monthly Barclays observations',
      'countries': [
        {'label': c, 'iso': ISO[c], 'colour': COLOUR[c],
         'first_month': next((q for q, v in zip(allq, qvals[c]) if v is not None), None),
         'last_month':  next((q for q, v in zip(reversed(allq), reversed(qvals[c])) if v is not None), None),
         'observations': sum(1 for v in qvals[c] if v is not None),
         'vals': qvals[c]} for c in sorted(countries)],
    })
    qpath = os.path.join(ROOT, 'data', 'cape_race_quarterly.json')
    with open(qpath, 'w') as f: json.dump(qout, f, indent=1)
    rus_q = [q for q, v in zip(allq, qvals['Russia']) if v is not None]
    print(f"\nQUARTERLY  {len(allq)} quarters {allq[0]} to {allq[-1]}"
          f"  (final quarter has {months_in_last_q} of 3 months"
          f"{' - marked PART QUARTER' if months_in_last_q < 3 else ''})")
    print(f"  visible from 1982Q1: {len(vis_q)} quarters")
    print(f"  Russia last quarter: {rus_q[-1]}")
    for c in sorted(countries):
        fq = next((q for q, v in zip(allq, qvals[c]) if v is not None), None)
        print(f"    {c:16s} enters {fq}")
    print(f"  {qpath}")
    print(f"  sha256 {hashlib.sha256(open(qpath,'rb').read()).hexdigest()}")

    print(f'\nALL CHECKS PASSED')
    print(f'  {OUT}')
    print(f'  dataset sha256 {ds}')
    print(f'  logs/validation_{TODAY}.txt')

if __name__ == '__main__':
    main()
