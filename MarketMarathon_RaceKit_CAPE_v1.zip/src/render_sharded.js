/* Shard driver.
   @resvg/resvg-js 2.6.2 never releases the rendered pixmap (about 8 MB per 1080p frame,
   and global.gc() does not reclaim it), so a single process is OOM-killed after a few
   hundred frames. Each shard therefore runs in a FRESH node process, which is also how
   the channel's GitHub renders are organised. Segments are concatenated with a stream copy.

     node src/render_sharded.js [chunk]          whole video
     PREVIEW_FROM=2020-01 PREVIEW_TO=2026-08 NO_INTRO=1 OUT=previews/x.mp4 \
       node src/render_sharded.js                a slice

   Every shard warms its own row glide (WARMUP_FRAMES), so boundaries do not show. */
'use strict';
const { execFileSync, spawnSync } = require('child_process');
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const CFG = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
const CHUNK = +(process.argv[2] || process.env.CHUNK || 250);
const NODE = ['--expose-gc', '--max-old-space-size=2048'];
const OUT = path.resolve(ROOT, process.env.OUT || CFG.out);
const SEGDIR = path.join(ROOT, 'renders', '_segments');
fs.mkdirSync(SEGDIR, { recursive: true });
fs.mkdirSync(path.dirname(OUT), { recursive: true });

const env = { ...process.env };
const plan = execFileSync('node', [...NODE, path.join(ROOT, 'src/cape_race.js')],
  { env: { ...env, FRAME_COUNT_ONLY: '1' }, encoding: 'utf8' });
process.stdout.write(plan);
const TOTAL = +(/FRAMES (\d+)/.exec(plan) || [])[1];
if (!TOTAL) { console.error('FATAL: could not read the frame plan'); process.exit(2); }

const tag = path.basename(OUT, '.mp4');
const segs = [];
const t0 = Date.now();
for (let a = 0, i = 0; a < TOTAL; a += CHUNK, i++) {
  const b = Math.min(TOTAL, a + CHUNK);
  const seg = path.join(SEGDIR, `${tag}_${String(i).padStart(3, '0')}.mp4`);
  segs.push(seg);
  if (fs.existsSync(seg) && !process.env.FORCE) { console.log(`  shard ${i}: cached`); continue; }
  // write to .part and rename only on a clean exit, so a run killed mid-shard never
  // leaves a truncated segment that the next run would treat as finished
  const part = seg.replace(/\.mp4$/, '.part.mp4');   // keep the .mp4 extension: ffmpeg picks the container from it
  const r = spawnSync('node', [...NODE, path.join(ROOT, 'src/cape_race.js')],
    { env: { ...env, SEG_START: String(a), SEG_END: String(b), OUT: part }, stdio: ['ignore', 'inherit', 'pipe'] });
  if (r.status === 0) fs.renameSync(part, seg);
  if (r.status !== 0) {
    try { fs.unlinkSync(part); } catch (e) {}
    console.error(String(r.stderr || '').split('\n').slice(-12).join('\n'));
    console.error(`FATAL: shard ${i} (frames ${a}..${b - 1}) exited ${r.status}`); process.exit(1);
  }
  const el = (Date.now() - t0) / 1000, done = b, fps = done / el;
  console.log(`  shard ${i}: frames ${a}-${b - 1}  ${fps.toFixed(1)} fps overall  eta ${((TOTAL - done) / fps / 60).toFixed(1)} min`);
}
const list = path.join(SEGDIR, `${tag}_list.txt`);
fs.writeFileSync(list, segs.map(s => `file '${s}'`).join('\n') + '\n');
const c = spawnSync('ffmpeg', ['-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', list,
  '-c', 'copy', '-movflags', '+faststart', OUT], { stdio: 'inherit' });
if (c.status !== 0) { console.error('FATAL: concat failed'); process.exit(1); }
const probe = execFileSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0',
  '-show_entries', 'stream=nb_frames,width,height,r_frame_rate', '-show_entries', 'format=duration',
  '-of', 'default=nw=1', OUT], { encoding: 'utf8' }).trim().replace(/\n/g, '  ');
const got = +(/nb_frames=(\d+)/.exec(probe) || [])[1];
console.log(`\n${path.relative(ROOT, OUT)}\n  ${probe}`);
if (got !== TOTAL) { console.error(`FATAL: expected ${TOTAL} frames, got ${got}`); process.exit(1); }
console.log(`  frame count matches the plan (${TOTAL})`);
for (const s of segs) fs.unlinkSync(s); fs.unlinkSync(list);
console.log(`  segments cleaned  ·  ${((Date.now() - t0) / 60000).toFixed(1)} min`);
