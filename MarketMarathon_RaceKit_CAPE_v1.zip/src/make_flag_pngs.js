/* Rasterise the flag SVGs once into PNG chips the renderer can embed.
   node src/make_flag_pngs.js   ->  assets/flags_png/<iso>.png  (192x144)
   Run again only if the flag set or CHIP_W changes. */
const { Resvg } = require('@resvg/resvg-js');
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'assets', 'flags');
const OUT = path.join(ROOT, 'assets', 'flags_png');
const W = 192;                      // 4x the on-screen chip width, for clean downscaling
fs.mkdirSync(OUT, { recursive: true });
let n = 0;
for (const f of fs.readdirSync(SRC).filter(f => f.endsWith('.svg'))) {
  const svg = fs.readFileSync(path.join(SRC, f), 'utf8');
  const png = new Resvg(svg, { fitTo: { mode: 'width', value: W } }).render().asPng();
  fs.writeFileSync(path.join(OUT, f.replace('.svg', '.png')), png);
  n++;
}
console.log(`flag chips written: ${n} -> assets/flags_png/`);
