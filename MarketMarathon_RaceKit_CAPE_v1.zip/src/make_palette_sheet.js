/* Renders a swatch sheet of the current colour scheme, so the regions can be checked
   at a glance without watching the video.   node src/make_palette_sheet.js [scheme] */
'use strict';
const { Resvg } = require('@resvg/resvg-js');
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const CFG = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
const P = CFG.palette;
const scheme = process.argv[2] || CFG.COLOUR_SCHEME;
const pal = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/palettes.json'), 'utf8'))[scheme];
const leg = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/region_legend.json'), 'utf8'));
const FLAGS = (() => { const d = path.join(ROOT, CFG.flags_dir), o = {};
  for (const f of fs.readdirSync(d).filter(f => f.endsWith('.png')))
    o[f.replace('.png','')] = 'data:image/png;base64,' + fs.readFileSync(path.join(d, f)).toString('base64');
  return o; })();
const ISO = JSON.parse(fs.readFileSync(path.join(ROOT, CFG.data), 'utf8'))
  .countries.reduce((a, c) => (a[c.label] = c.iso, a), {});
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
const lum = h => { const c=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255).map(v=>v<=0.03928?v/12.92:((v+0.055)/1.055)**2.4);
  return 0.2126*c[0]+0.7152*c[1]+0.0722*c[2]; };
const W = 1920, H = 1080, s = [];
s.push(`<rect width="${W}" height="${H}" fill="${P.bg}"/>`);
s.push(`<text x="60" y="84" font-size="42" font-weight="700" fill="${P.title}">BAR COLOURS BY REGION</text>`);
s.push(`<text x="60" y="120" font-size="19" fill="${P.subtitle}">scheme "${esc(scheme)}" · data/palettes.json · change any single value and re-render</text>`);
s.push(`<line x1="60" y1="146" x2="1860" y2="146" stroke="${P.rule}" stroke-width="2"/>`);
const regions = Object.keys(leg.regions);
let x = 60, y = 190, col = 0;
const COLW = 452, ROWH = 40;
for (const r of regions) {
  const ms = leg.members[r];
  const need = 46 + ms.length * ROWH + 26;
  if (y + need > H - 50) { col++; x = 60 + col * COLW; y = 190; }
  s.push(`<rect x="${x}" y="${y - 24}" width="26" height="15" fill="${leg.regions[r]}"/>`);
  s.push(`<text x="${x + 36}" y="${y - 11}" font-size="21" font-weight="700" fill="${P.gold}" letter-spacing="1.6">${esc(r.toUpperCase())}</text>`);
  y += 20;
  for (const m of ms) {
    const c = pal[m];
    s.push(`<rect x="${x}" y="${y}" width="270" height="30" fill="${c}"/>`);
    if (FLAGS[ISO[m]]) s.push(`<image x="${x + 6}" y="${y + 6}" width="24" height="18" preserveAspectRatio="none" href="${FLAGS[ISO[m]]}"/>`);
    s.push(`<text x="${x + 40}" y="${y + 21}" font-size="17" font-weight="700" fill="${lum(c) > 0.34 ? '#12202f' : '#ffffff'}">${esc(m)}</text>`);
    s.push(`<text x="${x + 282}" y="${y + 21}" font-size="15" fill="${P.footer}">${c}</text>`);
    y += ROWH;
  }
  y += 30;
}
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><g font-family="SourceSerif4 SemiBold">${s.join('')}</g></svg>`;
const png = new Resvg(svg, { fitTo: { mode: 'width', value: W },
  font: { loadSystemFonts: false, fontFiles: [path.join(ROOT, CFG.font)], defaultFontFamily: 'SourceSerif4 SemiBold' } }).render().asPng();
const out = path.join(ROOT, 'frames', `PALETTE_${scheme}.png`);
fs.writeFileSync(out, png);
console.log('  ' + path.relative(ROOT, out));
