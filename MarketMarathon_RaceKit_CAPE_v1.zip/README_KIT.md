# CAPE_v1 — World Stock Markets by CAPE Ratio | 1982–2026

The render kit for Market Marathon video "World Stock Markets by CAPE Ratio". Rendered by
`.github/workflows/render-cape-v1-split.yml`; not a Format C / C2 kit and it does not use
racekit.

## What is different from the other kits

- **Node + resvg only.** No Chromium, no Playwright, no node-canvas, no fontconfig. The
  renderer builds an SVG string per frame and rasterises it with `@resvg/resvg-js`, loading
  `assets/fonts/SourceSerif4-SemiBold.ttf` directly (`loadSystemFonts: false`), so there is
  no way for a runner to substitute a typeface.
- **Split board.** Ten most expensive markets on the left, ten least expensive on the right,
  each side with its own axis scale.
- **Quarterly.** 179 quarters, 1982 Q1 → 2026 Q3, 3.0 s each. A quarter is the mean of its
  three months and is only shown when all three exist — except the final one, which is two
  months and is marked PART QUARTER on screen.

## Frame budget

`FRAME_COUNT_ONLY=1 node src/cape_race.js` prints the plan and exits. Everything the CI needs
— total frames, and therefore the duration the music bed has to cover — comes from there, so
the video length is never written down twice.

## Environment the renderer honours

    SEG_START / SEG_END     half-open frame range, for sharded renders
    OUT                     output file for this shard
    RASTER_W                3840 for a master, 1920 for a preview
    FRAME_COUNT_ONLY        print the plan and exit
    STILL_FRAME             comma-separated GLOBAL frame indices -> frames/CARD_*.png
    STILL                   comma-separated quarters, e.g. 2000Q1
    NO_INTRO / NO_COVERAGE / NO_OUTRO / NO_HOLD

## Sharding is safe here

The row-count glide and the axis ease are eased **once across the whole timeline** into
`ROWS_AT` / `AXIS_AT` lookup tables, so every frame is a pure function of its index and a
shard boundary cannot show a jump. `WARMUP_FRAMES` is kept as belt and braces.
**`racekit_q.js` has the same class of state and no warm-up at all** — do not copy this kit's
sharding onto it without fixing that first.

## Everything presentational lives in config.json

Titles, the strapline, the absentees card, the captions file, the palette scheme, the split
headings, the pacing, the axis ladder. The renderer should not need editing to change any of
them.

## Data

`data/cape_race_quarterly.json` is built from `data/Global_CAPE_Final_v3.xlsx` by
`src/build_dataset.py`, which runs 15 integrity checks and records the workbook's SHA-256 in
the JSON. The workbook derives from the Barclays "Historic CAPE Ratio by Country" file; the
immutable raw CSV and the provenance notes live outside this kit in `Bar Charts\CAPE\`.

25 markets. The video says so on its intro card and names the notable absentees on an
end-card, because the coverage limit is real and stating it is better than arguing about it
in the comments.
