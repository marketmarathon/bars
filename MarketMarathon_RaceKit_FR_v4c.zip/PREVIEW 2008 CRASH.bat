@echo off
setlocal
cd /d "%~dp0"
title FRANCE PREVIEW - 2008 CRASH
echo.
echo   FRANCE PREVIEW - THE 2008 CRASH
echo   -------------------------------
echo   Just over a minute of the race at 1280 wide. Covers Q3 2008 to Q2 2009.
echo   Watch the CAC 40 line bottom right: it should now PLUNGE past the -40%%
echo   mark and turn, not run flat along the floor of the box. The band is
echo   labelled +50%% / -50%% at the edges.
echo.
echo   This is NOT the master. It is the clip to look at before anything expensive runs.
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js is not installed.
  echo   Install the LTS build from nodejs.org, or run:  winget install OpenJS.NodeJS.LTS
  echo.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo   ffmpeg is not installed.
  echo   Run:  winget install Gyan.FFmpeg
  echo.
  pause
  exit /b 1
)

rem The renderer's one dependency ships a NATIVE binary per operating system, so a
rem node_modules built anywhere else is useless here. npm ci wipes and rebuilds it,
rem from the pinned lockfile, every time. It is quick after the first run.
echo   Making sure the renderer's binary matches this machine...
call npm ci --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo   The dependency install failed. Nothing was rendered.
  pause
  exit /b 1
)
echo.

rem Blueprint 1j / D25: this format is proven on node 22. Another major may still work,
rem but it has not been tested, and node 20 leaked memory badly enough to kill a render.
for /f "tokens=1 delims=." %%V in ('node -p "process.versions.node"') do set NODEMAJ=%%V
if not "%NODEMAJ%"=="22" (
  echo   NOTE: this machine runs Node %NODEMAJ%. The format is proven on Node 22.
  echo   The preview will still be attempted. If it looks wrong or fails, that is why.
  echo.
)

set RASTER_W=1280
set NOOUTRO=1
set SEG_START=10296
set SEG_END=12168
set SEG_OUT=FR_preview_2008.mp4
echo   Rendering frames 10296 to 12168. A few minutes.
echo.
node racekit_q.js
echo.
if exist FR_preview_2008.mp4 (
  rem The renderer encodes at crf 0, which x264 emits as High 4:4:4 Predictive.
  rem Windows Media Player and Films and TV cannot decode that profile and show a
  rem black picture. Transcode to plain High / yuv420p so it plays anywhere.
  echo   Making a playable copy...
  ffmpeg -v error -y -i FR_preview_2008.mp4 -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 20 -preset veryfast -c:a aac -b:a 160k -movflags +faststart FR_PREVIEW_2008_watch_me.mp4
  echo   Done. FR_PREVIEW_2008_watch_me.mp4 is in this folder.
  start "" "FR_PREVIEW_2008_watch_me.mp4"
) else (
  echo   The render did not produce a file. Read the messages above.
)
echo.
pause
