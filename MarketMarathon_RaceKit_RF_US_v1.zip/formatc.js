/* Rise and Fall - the Format C renderer entry point.
 *
 * Honours the same environment contract as racekit_q.js so the shard-and-join workflow
 * is the one the other two series already use:
 *
 *   FRAME_COUNT_ONLY=1   print "FRAMES <n>" and exit, for the plan job
 *   SEG_START, SEG_END   render frames [START, END) only
 *   SEG_OUT              write that slice to this mp4
 *   RASTER_W             3840 for a master, 1920 for a preview
 *   NOMUX=1              video only; the join job adds the bed
 *
 * Unlike racekit_q.js this draws through a real browser canvas (Playwright/Chromium)
 * because player2.html is the approved Format C renderer and porting its 700 lines of
 * canvas drawing to node-canvas would be a rewrite, not a move. The runner installs
 * chromium in one step.
 *
 * The whole video is ONE timeline here - title card, race, closing card - so a shard
 * boundary can fall anywhere and the join is a plain concat.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG   = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const FPS   = CFG.fps;
const SEC   = CFG.seconds_per_year;
const INTRO = CFG.intro_sec;
const RACE  = CFG.race_sec;
const OUTRO = CFG.outro_sec;
const TOTAL = Math.round((INTRO + RACE + OUTRO) * FPS);

if (process.env.FRAME_COUNT_ONLY) { console.log('FRAMES ' + TOTAL); process.exit(0); }

const RW    = +(process.env.RASTER_W || 1920);
const R     = RW / 1920;
const A     = process.env.SEG_START ? +process.env.SEG_START : 0;
const B     = process.env.SEG_END   ? +process.env.SEG_END   : TOTAL;
const OUT   = process.env.SEG_OUT   || CFG.out;

if (!Number.isInteger(R) || R < 1) { console.error('RASTER_W must be a whole multiple of 1920'); process.exit(2); }

const b64 = (f, m) => `data:${m};base64,` + fs.readFileSync(f).toString('base64');

(async () => {
  const data  = JSON.parse(fs.readFileSync(CFG.race_file, 'utf8'));
  const short = JSON.parse(fs.readFileSync(CFG.summaries_file, 'utf8'));
  const icons = JSON.parse(fs.readFileSync(CFG.icons_file, 'utf8'));
  const logo  = b64(CFG.logo_file, 'image/png');
  const images = {};
  for (const f of fs.readdirSync(CFG.photos_dir)) {
    const m = f.match(/^(\d{4})\.jpg$/);
    if (m) images[m[1]] = b64(path.join(CFG.photos_dir, f), 'image/jpeg');
  }
  const want = data.periods.length;
  const got  = Object.keys(images).length;
  if (got < want) { console.error(`::error::expected ${want} year photographs in ${CFG.photos_dir}, found ${got}`); process.exit(2); }

  const br = await chromium.launch({ args: ['--disable-lcd-text'] });
  const pg = await br.newPage({ viewport: { width: 1920 * R, height: 1080 * R } });
  await pg.goto('file://' + path.resolve('player2.html'));
  await pg.evaluate(o => window.setup(o), {
    data, short, icons, images, logo, company: null,
    sec: SEC, start: data.periods[0] | 0, fps: FPS,
    look: CFG.look, card: CFG.card, raster: R
  });
  await pg.waitForTimeout(1200);          // let the fonts and the photographs settle

  // The rank glide is stateful, so a shard that starts mid-race must be wound up to its
  // own first frame or the eased row positions begin from the wrong place. 140 frames is
  // ten time constants at the 0.55 s glide.
  const WARM = 140;
  const draw = t => pg.evaluate(([tt, intro]) =>
    tt < intro ? drawIntro(tt) : drawAt(tt - intro), [t, INTRO]);
  for (let f = Math.max(0, A - WARM); f < A; f++) await draw(f / FPS);

  const args = ['-hide_banner','-loglevel','error','-y','-f','mjpeg','-framerate',String(FPS),'-i','pipe:0',
                '-c:v','libx264','-pix_fmt','yuv420p','-crf',String(CFG.crf),'-preset',CFG.preset,
                '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',
                '-r',String(FPS),'-movflags','+faststart', OUT];
  const ff = spawn('ffmpeg', args, { stdio: ['pipe','inherit','inherit'] });
  ff.on('error', e => { console.error('ffmpeg failed to start:', e.message); process.exit(2); });

  const write = buf => new Promise((res, rej) => ff.stdin.write(buf, e => e ? rej(e) : res()));

  const t0 = Date.now();
  for (let f = A; f < B; f++) {
    const u = await pg.evaluate(([tt, intro]) => {
      tt < intro ? drawIntro(tt) : drawAt(tt - intro);
      return document.getElementById('c').toDataURL('image/jpeg', 0.97);
    }, [f / FPS, INTRO]);
    await write(Buffer.from(u.split(',')[1], 'base64'));
    if ((f - A) % 250 === 0) {
      const done = f - A + 1, el = (Date.now() - t0) / 1000;
      console.log(`frame ${f}/${B}  ${(done/el).toFixed(1)} fps  rss ${(process.memoryUsage().rss/1e6).toFixed(0)} MB`);
    }
  }
  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  await br.close();
  console.log(`wrote ${OUT}: frames ${A} to ${B - 1} of ${TOTAL} at ${1920*R}x${1080*R}`);
})();
