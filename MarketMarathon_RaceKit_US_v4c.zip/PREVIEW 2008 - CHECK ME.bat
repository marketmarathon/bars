@echo off
setlocal
cd /d "%~dp0"
title USA PREVIEW - 2008 CRASH
echo.
echo   USA PREVIEW - 2008 CRASH
echo   ------------------------
echo   Just over a minute of the race at 1280 wide. Covers 2008-Q3 to 2009-Q2.
echo.
echo   WHAT TO LOOK AT
echo     1. The S&P 500 line, bottom right. It should PLUNGE through the autumn of 2008
echo        and TURN. It must NOT run flat along the floor of the box.
echo     2. The band edges are printed at the top and bottom of that box.
echo     3. At the turn of the year the line resets to zero and starts again
echo        against the new year's base. Watch that it does not jump or blank out.
echo     4. The bars: 2008-09 is when the banks collapse. Watch names leave the top ten.
echo.
echo   There is NO MUSIC in this preview. The bed is added at render time.
echo   This is NOT the master. It is the clip to look at before anything expensive runs.
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js is not installed.
  echo   Install the LTS build from nodejs.org, or run:  winget install OpenJS.NodeJS.LTS
  echo.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo   ffmpeg is not installed.
  echo   Run:  winget install Gyan.FFmpeg
  echo.
  pause
  exit /b 1
)

rem The renderer's one dependency ships a NATIVE binary per operating system, so a
rem node_modules built anywhere else is useless here. npm ci wipes and rebuilds it
rem from the pinned lockfile. Quick after the first run.
echo   Making sure the renderer's binary matches this machine...
call npm ci --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo   The dependency install failed. Nothing was rendered.
  pause
  exit /b 1
)
echo.

rem Blueprint 1j / D25: proven on node 22. node 20 leaked memory badly enough to kill a render.
for /f "tokens=1 delims=." %%V in ('node -p "process.versions.node"') do set NODEMAJ=%%V
if not "%NODEMAJ%"=="22" (
  echo   NOTE: this machine runs Node %NODEMAJ%. The format is proven on Node 22.
  echo   The preview will still be attempted. If it looks wrong or fails, that is why.
  echo.
)

set RASTER_W=1280
set NOOUTRO=1
set SEG_START=19656
set SEG_END=21528
set SEG_OUT=US_preview_2008.mp4
echo   Rendering frames 19656 to 21528. A few minutes.
echo.
node racekit_q.js
echo.
if exist US_preview_2008.mp4 (
  rem crf 0 emits High 4:4:4 Predictive, which Windows players cannot decode and show
  rem as a black picture. Transcode to plain High / yuv420p so it plays anywhere.
  echo   Making a playable copy...
  ffmpeg -v error -y -i US_preview_2008.mp4 -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 20 -preset veryfast -movflags +faststart US_PREVIEW_2008_watch_me.mp4
  echo   Done. US_PREVIEW_2008_watch_me.mp4 is in this folder.
  start "" "US_PREVIEW_2008_watch_me.mp4"
) else (
  echo   The render did not produce a file. Read the messages above.
)
echo.
pause
