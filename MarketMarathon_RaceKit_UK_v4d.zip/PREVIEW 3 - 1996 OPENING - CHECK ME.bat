@echo off
cd /d "%~dp0"
title UK PREVIEW - 1996 OPENING
set "LOG=_preview_1996_log.txt"
set "OUTF=UK_preview_1996.mp4"
set "PLAY=PLAYABLE_UK_preview_1996.mp4"

echo UK PREVIEW 1996 OPENING> "%LOG%"
echo started %DATE% %TIME%>> "%LOG%"
echo folder %CD%>> "%LOG%"

echo.
echo   UK PREVIEW - 1996 OPENING
echo   -----------------------------------------------------
echo   About a minute of race at 1280 wide, frames 0 to 1872.
echo.
echo   WHAT TO LOOK AT
echo     1. MARKS ^& SPENCER sits 10th through 1996. Until today it had NO
echo        colour and NO icon, because its sub-sector was written as Retail,
echo        which matched neither the colour map nor the icon set. It should
echo        now be a warm brown bar with a shop icon.
echo     2. THE OLDEST LOGOS, the ones most likely to be wrong: Glaxo Wellcome,
echo        Zeneca, British Petroleum's green and yellow shield, and BT's piper.
echo     3. Every bar in its sub-sector colour, none of them slate grey.
echo     4. The very start of the race: the axis, the first bars easing in, and
echo        the FTSE 100 panel starting from a hundred pounds.
echo.
echo   No music in a preview. This is NOT the master.
echo   A transcript is written to %LOG%.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   NODE IS NOT INSTALLED. Install the LTS build from nodejs.org.
  echo node missing>> "%LOG%"
  goto fail
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo   FFMPEG IS NOT INSTALLED. Run:  winget install Gyan.FFmpeg
  echo ffmpeg missing>> "%LOG%"
  goto fail
)
for /f "delims=" %%V in ('node -p "process.versions.node"') do set "NODEV=%%V"
echo   node %NODEV%
echo node %NODEV%>> "%LOG%"
rem Blueprint 1j / D25: the format is proven on Node 22. Node 20 leaked memory badly enough
rem to kill a render. Anything else is reported rather than blocked.
for /f "tokens=1 delims=." %%M in ("%NODEV%") do set "NODEMAJ=%%M"
if not "%NODEMAJ%"=="22" (
  echo   NOTE: the format is proven on Node 22, this machine runs Node %NODEMAJ%.
  echo   The render is still attempted. If it fails or looks wrong, that is a suspect.
  echo node major %NODEMAJ% is not 22>> "%LOG%"
)

rem The renderer's one dependency ships a native binary per operating system. If the right
rem one is already here, DO NOT run npm ci: it wipes node_modules first, so a network blip
rem would leave the kit unable to render at all. Only install when it is genuinely missing.
set "NATIVE=node_modules\@resvg\resvg-js-win32-x64-msvc\resvgjs.win32-x64-msvc.node"
if exist "%NATIVE%" goto haveDep
echo   Installing the renderer dependency, one moment...
echo running npm ci>> "%LOG%"
call npm ci --no-audit --no-fund >> "%LOG%" 2>&1
if errorlevel 1 (
  echo   THE DEPENDENCY INSTALL FAILED. See %LOG%.
  goto fail
)
goto depDone
:haveDep
echo   Renderer dependency already present, skipping the install.
echo dependency present, npm ci skipped>> "%LOG%"
:depDone

rem Clear the previous clip so a stale file cannot look like a fresh success.
if exist "%OUTF%" del /q "%OUTF%"
if exist "%PLAY%" del /q "%PLAY%"

set RASTER_W=1280
set NOOUTRO=1
set SEG_START=0
set SEG_END=1872
set "SEG_OUT=%OUTF%"
echo   Rendering. A few minutes. Do not close this window.
echo.
node racekit_q.js >> "%LOG%" 2>&1
if errorlevel 1 (
  echo   THE RENDER FAILED. See %LOG%.
  goto fail
)
if not exist "%OUTF%" (
  echo   THE RENDER WROTE NOTHING. See %LOG%.
  goto fail
)

echo   Transcoding so any Windows player can decode it...
ffmpeg -hide_banner -loglevel error -y -i "%OUTF%" -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 18 -c:a copy "%PLAY%" >> "%LOG%" 2>&1
if not exist "%PLAY%" (
  echo   THE TRANSCODE FAILED. See %LOG%.
  goto fail
)

echo finished %DATE% %TIME%>> "%LOG%"
echo.
echo   DONE. Opening %PLAY%
start "" "%PLAY%"
echo.
echo   If it does not open, the file is right here in this folder.
echo.
pause
exit /b 0

:fail
echo FAILED %DATE% %TIME%>> "%LOG%"
echo.
echo   ------------------------------------------------------------
echo   IT DID NOT COMPLETE. Nothing was damaged.
echo   Send Claude this file:  %LOG%
echo   ------------------------------------------------------------
echo.
pause
exit /b 1
