@echo off
setlocal
cd /d "%~dp0"
title RENDER MASTER
echo.
echo   RENDER MASTER
echo   -------------
echo   Renders the 4K master by splitting it across several workers at once.
echo   Segments already finished are skipped, so it is safe to run this again.
echo.
set PY=
for %%P in (python.exe py.exe) do if not defined PY (
  for /f "delims=" %%I in ('where %%P 2^>nul') do if not defined PY set PY=%%I
)
if not defined PY (
  echo   Python was not found on this PC.
  echo   Install it from python.org, tick Add to PATH, then run this again.
  echo.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js is not installed.
  echo   Install the LTS build from nodejs.org, or run:  winget install OpenJS.NodeJS.LTS
  echo   Then close this window, open a new one, and run this again.
  echo.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo   ffmpeg is not installed.
  echo   Run:  winget install Gyan.FFmpeg
  echo   Then close this window, open a new one, and run this again.
  echo.
  pause
  exit /b 1
)
echo   How many workers?
echo   Your machine has %NUMBER_OF_PROCESSORS% processors.
echo   Press Enter for the safe number, which is about half of them.
echo   More than that at 4K makes the machine unusable and can break the render.
echo.
set N=
set /p N=  Workers (Enter for automatic): 
echo.
"%PY%" "_render_master.py" %N%
echo.
pause
