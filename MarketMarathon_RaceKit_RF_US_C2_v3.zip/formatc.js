/* Rise and Fall - the Format C renderer entry point.
 *
 * Honours the same environment contract as racekit_q.js so the shard-and-join workflow
 * is the one the other two series already use:
 *
 *   FRAME_COUNT_ONLY=1   print "FRAMES <n>" and exit, for the plan job
 *   SEG_START, SEG_END   render frames [START, END) only
 *   SEG_OUT              write that slice to this mp4
 *   RASTER_W             3840 for a master, 1920 for a preview
 *   NOMUX=1              video only; the join job adds the bed
 *   REF_PNG_DIR          write each frame as a lossless PNG into this directory INSTEAD of
 *                        encoding a video, and skip ffmpeg entirely. This is how a format
 *                        reference set is cut (blueprint C2 5.1): the shipped path goes
 *                        canvas -> MJPEG q0.97 -> x264, so two mp4s of the same frame differ
 *                        by encoder noise on every text edge and are useless for a pixel
 *                        diff. The canvas PNG is the only thing that can be compared exactly.
 *
 * Unlike racekit_q.js this draws through a real browser canvas (Playwright/Chromium)
 * because player2.html is the approved Format C renderer and porting its 700 lines of
 * canvas drawing to node-canvas would be a rewrite, not a move. The runner installs
 * chromium in one step.
 *
 * The whole video is ONE timeline here - title card, race, closing card - so a shard
 * boundary can fall anywhere and the join is a plain concat.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG   = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const FPS   = CFG.fps;
const SEC   = CFG.seconds_per_year;
const INTRO = CFG.intro_sec;
const RACE  = CFG.race_sec;
const OUTRO = CFG.outro_sec;
const TOTAL = Math.round((INTRO + RACE + OUTRO) * FPS);

/* RF-3: race_sec is derived from the data, never trusted from config alone. The USA races
   29 one-year steps; the UK races 59 half-year steps. Getting this wrong once put the
   closing card on top of the last year. */

if (process.env.FRAME_COUNT_ONLY) { console.log('FRAMES ' + TOTAL); process.exit(0); }

const RW    = +(process.env.RASTER_W || 1920);
const R     = RW / 1920;
const A     = process.env.SEG_START ? +process.env.SEG_START : 0;
const B     = process.env.SEG_END   ? +process.env.SEG_END   : TOTAL;
const OUT   = process.env.SEG_OUT   || CFG.out;

if (!Number.isInteger(R) || R < 1) { console.error('RASTER_W must be a whole multiple of 1920'); process.exit(2); }

const b64 = (f, m) => `data:${m};base64,` + fs.readFileSync(f).toString('base64');

(async () => {
  const data  = JSON.parse(fs.readFileSync(CFG.race_file, 'utf8'));
  const short = JSON.parse(fs.readFileSync(CFG.summaries_file, 'utf8'));
  const icons = JSON.parse(fs.readFileSync(CFG.icons_file, 'utf8'));
  const logo  = b64(CFG.logo_file, 'image/png');
  /* C2-2, optional: a mark-only lockup for the footer (see the renderer). */
  const mark  = CFG.logo_mark_file && fs.existsSync(CFG.logo_mark_file)
              ? b64(CFG.logo_mark_file, 'image/png') : null;
  const images = {};
  /* A C2-2 plate carries an alpha channel, because the wedge is cut out of a square; a
     Format C or C2-1 photograph is a plain JPEG. Take any of the three and prefer the
     alpha formats, so a year that somehow has both does not silently draw the flat one.
     WEBP is the shipped C2-2 format: it holds the alpha losslessly and is five times
     smaller than the equivalent PNG, which is the difference between a 12 MB kit and a
     66 MB one when there are thirty-one plates. PNG is accepted so an unconverted set
     still renders. */
  const PIC = [[/^(\d{4})\.webp$/, 'image/webp'], [/^(\d{4})\.png$/, 'image/png'],
               [/^(\d{4})\.jpg$/,  'image/jpeg']];
  for (const [re, mime] of PIC)
    for (const f of fs.readdirSync(CFG.photos_dir)) {
      const m = f.match(re);
      if (m && !images[m[1]]) images[m[1]] = b64(path.join(CFG.photos_dir, f), mime);
    }
  /* One photograph per YEAR, not per period: RF-3 has two periods in each year and they
     share the year's picture. */
  const wantYears = [...new Set(data.periods.map(p => String(p).slice(0, 4)))];
  const missing = wantYears.filter(y => !images[y]);
  if (missing.length) { console.error(`::error::no photograph in ${CFG.photos_dir} for ${missing.join(', ')}`); process.exit(2); }

  const br = await chromium.launch({ executablePath: process.env.PW_CHROME || undefined, args: ['--disable-lcd-text'] });
  const pg = await br.newPage({ viewport: { width: 1920 * R, height: 1080 * R } });
  await pg.goto('file://' + path.resolve(CFG.renderer_file || 'player_formatc.html'));

  /* The runner installs Archivo as a system font. Chromium substitutes SILENTLY if it is
     missing, which would ship the wrong typography without anyone noticing, so prove it
     resolved before a single frame is drawn rather than after the render.
     document.fonts.check() is NO USE here - it only knows about @font-face rules and
     answers true for a system font that is not installed. Measure instead: render a string
     in Archivo and in a family that cannot exist, and if the widths match, the browser fell
     back to the same default for both and Archivo is not there. */
  const fontOK = await pg.evaluate(async () => {
    await document.fonts.ready;
    const c = document.createElement('canvas').getContext('2d');
    const S = 'Berkshire Hathaway 1234567890';
    c.font = '700 64px "NoSuchFamily12345"';  const fallback = c.measureText(S).width;
    c.font = '700 64px Archivo';              const archivo  = c.measureText(S).width;
    return Math.abs(archivo - fallback) > 0.5;
  });
  if (!fontOK) { console.error('::error::Archivo did not resolve on this runner - refusing to render substituted type. Check the font install step ran.'); process.exit(2); }

  await pg.evaluate(o => window.setup(o), {
    data, short, icons, images, logo, logomark: mark, company: null,
    sec: SEC, start: parseInt(String(data.periods[0]).slice(0, 4), 10), fps: FPS,
    look: CFG.look, card: CFG.card, raster: R,
    unit: CFG.unit, flag: CFG.flag, title: CFG.title, subtitle: CFG.subtitle,
    range: CFG.range, outro_q: CFG.outro_q, outro_sub: CFG.outro_sub,
    /* Decision 31 (17 Sep 2026): both optional. Absent, the renderer draws as before. */
    namew: CFG.name_col, decimals: CFG.value_decimals,
    /* FORMAT C2 (C2-1, 18 Sep 2026). Every one of these is optional and every one defaults
       to the Format C behaviour, so a Format C kit whose config omits them renders exactly
       as it did. Authority: Rise and Fall Format C2 Video Blueprint.md §3.1. */
    picw: CFG.picw, picside: CFG.picside, picgut: CFG.picgut, picchrome: CFG.picchrome,
    namemode: CFG.namemode, namescale: CFG.namescale, valout: CFG.valout, valw: CFG.valw,
    yearsize: CFG.yearsize, xfade: CFG.xfade, kenburns: CFG.kenburns,
    /* FORMAT C2-2 (20 Sep 2026). Same rule: every one optional, every one defaulting to
       the C2-1 / Format C behaviour. §3.1. */
    picmode: CFG.picmode, nameoverflow: CFG.nameoverflow, yearmode: CFG.yearmode,
    brandpos: CFG.brandpos, barend: CFG.barend
  });

  /* The race length the renderer derived from the data must match the one config declares,
     or the closing card lands in the wrong place. Check, do not assume. */
  const raceSec = await pg.evaluate(() => RACE_SEC);
  if (Math.abs(raceSec - RACE) > 0.001) {
    console.error(`::error::config says race_sec ${RACE} but the data gives ${raceSec}`); process.exit(2);
  }
  await pg.waitForTimeout(1200);          // let the fonts and the photographs settle

  // The rank glide is stateful, so a shard that starts mid-race must be wound up to its
  // own first frame or the eased row positions begin from the wrong place. 140 frames is
  // ten time constants at the 0.55 s glide.
  const WARM = 140;
  const draw = t => pg.evaluate(([tt, intro]) =>
    tt < intro ? drawIntro(tt) : drawAt(tt - intro), [t, INTRO]);
  for (let f = Math.max(0, A - WARM); f < A; f++) await draw(f / FPS);

  const REFDIR = process.env.REF_PNG_DIR;
  if (REFDIR) {
    fs.mkdirSync(REFDIR, { recursive: true });
    const el = await pg.$('#c');
    for (let f = A; f < B; f++) {
      await pg.evaluate(([tt, intro]) => { tt < intro ? drawIntro(tt) : drawAt(tt - intro); }, [f / FPS, INTRO]);
      await el.screenshot({ path: path.join(REFDIR, 'f' + String(f).padStart(5, '0') + '.png'), type: 'png' });
    }
    await br.close();
    console.log(`wrote ${B - A} reference PNG(s) to ${REFDIR} at ${1920*R}x${1080*R}`);
    return;
  }

  const args = ['-hide_banner','-loglevel','error','-y','-f','mjpeg','-framerate',String(FPS),'-i','pipe:0',
                '-c:v','libx264','-pix_fmt','yuv420p','-crf',String(CFG.crf),'-preset',CFG.preset,
                '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',
                '-r',String(FPS),'-movflags','+faststart', OUT];
  const ff = spawn('ffmpeg', args, { stdio: ['pipe','inherit','inherit'] });
  ff.on('error', e => { console.error('ffmpeg failed to start:', e.message); process.exit(2); });

  const write = buf => new Promise((res, rej) => ff.stdin.write(buf, e => e ? rej(e) : res()));

  const t0 = Date.now();
  for (let f = A; f < B; f++) {
    const u = await pg.evaluate(([tt, intro]) => {
      tt < intro ? drawIntro(tt) : drawAt(tt - intro);
      return document.getElementById('c').toDataURL('image/jpeg', 0.97);
    }, [f / FPS, INTRO]);
    await write(Buffer.from(u.split(',')[1], 'base64'));
    if ((f - A) % 250 === 0) {
      const done = f - A + 1, el = (Date.now() - t0) / 1000;
      console.log(`frame ${f}/${B}  ${(done/el).toFixed(1)} fps  rss ${(process.memoryUsage().rss/1e6).toFixed(0)} MB`);
    }
  }
  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  await br.close();
  console.log(`wrote ${OUT}: frames ${A} to ${B - 1} of ${TOTAL} at ${1920*R}x${1080*R}`);
})();
