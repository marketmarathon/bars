#!/usr/bin/env bash
echo "Panels bundled: $(ls panels | wc -l) files"
