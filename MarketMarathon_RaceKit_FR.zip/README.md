# Market Marathon — RaceKit (France, "Biggest Companies 2003-2026")
Self-contained render kit -> master.mp4 (~8 min, 1920x1080, 30fps).
Features in config.json: all_serif, panel_mode (macro _A first 10s -> company _B second 10s), show_usd (EUR + USD in brackets), year_sec 20.
Index line = CAC 40 weekly (ftse.json). Data: fr_race.json (EUR) + fr_race_usd.json.
Render on GitHub Actions: commit this zip to the repo root, add .github/workflows/render-fr.yml (copy render.yml), run it; download the master-mp4-france artifact.
