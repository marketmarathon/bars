# -*- coding: utf-8 -*-
"""
RENDER MASTER - renders the 4K master by splitting it across several workers at once.

Every frame is drawn from its own position on the timeline, so the job splits perfectly.
Each worker renders a slice, then the slices are joined and the music laid on once.

    RENDER MASTER.bat            asks how many workers, then does the lot
    python _render_master.py 8   the same thing, eight workers

Segments already finished are skipped, so if it stops you just run it again.
Nothing is deleted except this script's own segment files, and only once they have been
joined successfully.
"""
import os, sys, json, subprocess, shutil, time, io, re

HERE = os.path.dirname(os.path.abspath(__file__))
SEGDIR = os.path.join(HERE, "_segments")
LOG = io.open(os.path.join(HERE, "_render_log.txt"), "a", encoding="utf-8")

def say(m=""):
    print(m, flush=True); LOG.write(m + "\n"); LOG.flush()

def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
    return None

def total_ram_gb():
    """Windows, macOS and Linux, without needing a library installed."""
    try:
        if os.name == "nt":
            import ctypes
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys / 1e9
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1e9
    except Exception:
        return 8.0

def seg_frames(ffprobe, path):
    """How many frames are actually in this segment. A file that exists is not a file that
    finished: on 23 Aug 2026 seven workers died on a broken pipe, left a part-written mp4
    behind, and the join failed with nothing obvious to point at."""
    if not (os.path.exists(path) and os.path.getsize(path) > 0): return 0
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v:0",
                            "-count_frames", "-show_entries", "stream=nb_read_frames",
                            "-of", "csv=p=0", path], stdout=subprocess.PIPE, timeout=600)
        return int((r.stdout.decode().strip() or "0").split(",")[0])
    except Exception:
        return 0

def hhmm(sec):
    sec = int(sec)
    return "%dh %02dm" % (sec // 3600, (sec % 3600) // 60) if sec >= 3600 else "%dm %02ds" % (sec // 60, sec % 60)

def main():
    say("=" * 72); say("  RENDER MASTER   " + time.strftime("%Y-%m-%d %H:%M")); say("=" * 72); say("")

    # D38: a silent file is a PREVIEW, never a master, and it has to be asked for out loud.
    silent = "--silent" in sys.argv
    if silent:
        say("  --silent: this is a PREVIEW with no music. It is not a production master.")
        say("")

    node = which("node", "node.exe")
    ff   = which("ffmpeg", "ffmpeg.exe")
    if not node:
        say("  Node.js is not installed, or not on the PATH.")
        say("  Install it from nodejs.org (the LTS build), then run this again.")
        say("  On Windows you can also run:   winget install OpenJS.NodeJS.LTS"); return 1
    if not ff:
        say("  ffmpeg is not installed, or not on the PATH.")
        say("  On Windows:   winget install Gyan.FFmpeg")
        say("  Then close this window, open a new one, and run it again."); return 1
    say("  node   %s" % node); say("  ffmpeg %s" % ff)

    rend = sorted([f for f in os.listdir(HERE) if re.match(r"racekit.*\.js$", f)])
    if not rend:
        say("  No renderer found in this folder."); return 1
    rend = rend[-1]

    # One render can feed several encoders, because rasterising a 4K frame costs far more
    # than encoding it. encodes.json lists them; without it there is a single encode using
    # the settings in config.json.
    encpath = os.path.join(HERE, "encodes.json")
    encodes = None
    if os.path.exists(encpath):
        try: encodes = json.load(io.open(encpath, encoding="utf-8"))
        except Exception as e: say("  encodes.json is not valid JSON (%s), ignoring it" % e)
    if not encodes: encodes = [{"suffix": "", "pix": "yuv420p"}]
    cfg = json.load(io.open(os.path.join(HERE, "config.json"), encoding="utf-8"))
    out = cfg.get("out", "master.mp4")
    raster = str(cfg.get("raster_w", 1920))
    say("  kit    %s   %s   %sp wide" % (rend, out, raster)); say("")

    if not os.path.isdir(os.path.join(HERE, "node_modules")):
        say("  Installing the renderer's one dependency (once only) ...")
        r = subprocess.run([which("npm", "npm.cmd") or "npm", "ci"], cwd=HERE)
        if r.returncode != 0:
            say("  npm ci failed. Check the internet connection and try again."); return 1

    env0 = dict(os.environ); env0["FRAME_COUNT_ONLY"] = "1"
    p = subprocess.run([node, rend], cwd=HERE, env=env0,
                       stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    m = re.search(r"FRAMES (\d+)", p.stdout.decode("utf-8", "replace"))
    if not m:
        say("  Could not work out how many frames the video is. Renderer output:")
        say("  " + p.stdout.decode("utf-8", "replace")[:300]); return 1
    total = int(m.group(1))

    # ------------------------------------------------------------------ how many workers
    # Two things bite, and both were learned the hard way on 23 Aug 2026.
    #
    # THREADS. The rasteriser is itself multi-threaded and helps itself to one thread per
    # core. Fifteen workers on a sixteen-thread laptop therefore asked for about 240 threads,
    # not 15. The machine froze and seven pipes broke. Each worker is now pinned to a fixed
    # small number of threads so workers x threads is roughly the core count.
    #
    # MEMORY. Measured at 4K: about 250 MB for the renderer and 1.6 GB for its ffmpeg, so
    # call it 2 GB per worker. Sixteen workers needs 30 GB, which is where a 32 GB laptop
    # starts swapping and pipes start dying.
    cpus = os.cpu_count() or 4
    ram  = total_ram_gb()
    fourk = int(raster) > 2000
    per_worker_gb = 2.0 if fourk else 0.8
    by_ram = max(1, int((ram - 4) / per_worker_gb))          # leave 4 GB for the machine
    threads = int(os.environ.get("WORKER_THREADS", "2" if fourk else "1"))
    by_cpu = max(1, cpus // threads - (1 if fourk else 0))
    default = max(1, min(by_cpu, by_ram))

    try:    workers = int(sys.argv[1])
    except Exception: workers = default
    workers = max(1, min(workers, 64))

    say("  %d processors, %.0f GB memory" % (cpus, ram))
    say("  %d workers x %d threads each, about %.0f GB of memory"
        % (workers, threads, workers * per_worker_gb))
    if workers > default:
        say("  NOTE: %d is more than this machine should take. %d is the safe number."
            % (workers, default))
        if workers * per_worker_gb > ram - 3:
            say("        At %d workers it will run out of memory and segments will fail."
                % workers)

    per = -(-total // workers)
    jobs = []
    for i in range(workers):
        a, b = i * per, min(total, (i + 1) * per)
        if a < b: jobs.append((i, a, b))
    if not os.path.isdir(SEGDIR): os.makedirs(SEGDIR)

    say("  %d frames, %d workers, about %d frames each" % (total, len(jobs), per))
    say("  Leave this window open. Progress is written to _render_log.txt too."); say("")

    ffprobe = which("ffprobe", "ffprobe.exe") or "ffprobe"
    say("  Checking what is already done ...")
    procs, t0 = [], time.time()
    for i, a, b in jobs:
        seg = os.path.join(SEGDIR, "seg_%02d.mp4" % i)
        have = seg_frames(ffprobe, seg)
        if have == (b - a):
            say("   worker %2d  %6d..%-6d  already done, skipping" % (i, a, b - 1)); continue
        if have:
            say("   worker %2d  %6d..%-6d  only %d of %d frames, redoing"
                % (i, a, b - 1, have, b - a))
            try: os.remove(seg)
            except Exception: pass
        env = dict(os.environ)
        env.update({"SEG_START": str(a), "SEG_END": str(b), "SEG_OUT": seg,
                    "NOMUX": "1", "RASTER_W": raster,
                    "RAYON_NUM_THREADS": str(threads),      # the rasteriser
                    "FFMPEG_THREADS": str(threads),         # and the encoder
                    "ENCODES": json.dumps(encodes)})
        lg = open(os.path.join(SEGDIR, "seg_%02d.log" % i), "wb")
        procs.append((i, a, b, seg, subprocess.Popen([node, rend], cwd=HERE, env=env,
                     stdout=lg, stderr=lg), lg))
        say("   worker %2d  %6d..%-6d  started" % (i, a, b - 1))

    if procs:
        say("")
        done = set()
        while len(done) < len(procs):
            time.sleep(20)
            for i, a, b, seg, pr, lg in procs:
                if i in done: continue
                if pr.poll() is not None:
                    done.add(i)
                    say("   worker %2d finished (exit %s) after %s" % (i, pr.returncode, hhmm(time.time() - t0)))
            if len(done) < len(procs):
                fr = 0
                for i, a, b, seg, pr, lg in procs:
                    try:
                        tail = open(os.path.join(SEGDIR, "seg_%02d.log" % i), "rb").read()[-4000:].decode("utf-8", "replace")
                        mm = re.findall(r"frame (\d+)/", tail)
                        if mm: fr += int(mm[-1])
                    except Exception: pass
                el = time.time() - t0
                if fr:
                    rate = fr / el
                    say("   %6d of %d frames  %s elapsed  %.1f fps  about %s to go"
                        % (fr, total, hhmm(el), rate, hhmm(max(0, (total - fr) / max(rate, 0.01)))))
        for i, a, b, seg, pr, lg in procs: lg.close()

    def failures():
        out = []
        for i, a, b in jobs:
            if seg_frames(ffprobe, os.path.join(SEGDIR, "seg_%02d.mp4" % i)) != (b - a):
                out.append((i, a, b))
        return out

    say(""); say("  Verifying every segment holds the frames it was asked for ...")
    bad = failures()
    if bad:
        say("  %d segment(s) short. Retrying them two at a time, which is what usually"
            % len(bad)); say("  fixes it: a broken pipe means too much running at once.")
        for i, a, b in bad:
            seg = os.path.join(SEGDIR, "seg_%02d.mp4" % i)
            try: os.remove(seg)
            except Exception: pass
        for k in range(0, len(bad), 2):
            batch = bad[k:k+2]
            rp = []
            for i, a, b in batch:
                env = dict(os.environ)
                env.update({"SEG_START": str(a), "SEG_END": str(b),
                            "SEG_OUT": os.path.join(SEGDIR, "seg_%02d.mp4" % i),
                            "NOMUX": "1", "RASTER_W": raster,
                            "RAYON_NUM_THREADS": str(threads),
                            "FFMPEG_THREADS": str(threads),
                            "ENCODES": json.dumps(encodes)})
                lg = open(os.path.join(SEGDIR, "seg_%02d.log" % i), "wb")
                say("   retry worker %2d  %6d..%-6d" % (i, a, b - 1))
                rp.append((subprocess.Popen([node, rend], cwd=HERE, env=env,
                                            stdout=lg, stderr=lg), lg))
            for pr, lg in rp: pr.wait(); lg.close()
        bad = failures()

    if bad:
        say(""); say("  Segments %s still did not finish."
                     % ", ".join(str(i) for i, a, b in bad))
        say("  Run this again with fewer workers, for example 4. Everything already"); 
        say("  finished is kept, so it only redoes what is missing."); return 1

    finals = []
    for e in encodes:
        sfx = e.get("suffix", "")
        say(""); say("  Joining %d segments%s ..." % (len(jobs), (" (%s)" % sfx.lstrip("_")) if sfx else ""))
        lst = os.path.join(SEGDIR, "list%s.txt" % sfx)
        with io.open(lst, "w", encoding="utf-8") as f:
            for i, a, b in jobs:
                f.write("file '%s'\n"
                        % os.path.join(SEGDIR, "seg_%02d%s.mp4" % (i, sfx)).replace("\\", "/"))
        joined = os.path.join(SEGDIR, "_joined%s.mp4" % sfx)
        r = subprocess.run([ff, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst,
                            "-c", "copy", "-movflags", "+faststart", joined])
        if r.returncode != 0: say("  Joining%s failed." % sfx); return 1

        final = os.path.join(HERE, out.replace(".mp4", "") + sfx + ".mp4")
        # D38 (blueprint 1.9.0 s1i): music is MANDATORY and a master without it is not a
        # master. This used to read cfg["music"], a key no config has ever carried, so the
        # mux was skipped and a SILENT file was copied out and called a master. Silence is
        # now a hard failure. The bed never lives in the kit (D38 forbids audio in a kit),
        # so it is named by config as a path OUTSIDE the kit, or by --bed on the command line.
        if silent:
            say("  --silent, so no music is laid on. PREVIEW ONLY.")
            shutil.copyfile(joined, final)
            finals.append(final)
            continue
        bed = os.environ.get("MM_BED") or cfg.get("music") or cfg.get("music_path")
        if bed and not os.path.isabs(bed):
            bed = os.path.normpath(os.path.join(HERE, bed))
        if not bed or not os.path.isfile(bed):
            say("")
            say("  NO MUSIC BED, so no master is written.")
            say("  Blueprint 1.9.0 s1i (D38): music is mandatory on every video and a")
            say("  master without it is not a production master.")
            say("  The bed is not a kit asset. Point at one with either:")
            say("    set MM_BED=..\\..\\RaceKit\\music_licensed\\MarketMarathon_Bed_US_v2.mp3")
            say("  or a \"music\" path in config.json, relative to the kit or absolute.")
            say("  For a deliberately silent PREVIEW, pass --silent.")
            return 1
        say("  Laying the music on ...")
        # D38: stitched, never looped, so no -stream_loop. D41: the mux is at UNITY gain,
        # because the bed is already mastered to -14 LUFS and a 0.65 multiplier would drop
        # it about 3.7 dB below the level YouTube normalises to.
        r = subprocess.run([ff, "-y", "-v", "error", "-i", joined, "-i", bed,
                            "-filter_complex", "[1:a]afade=t=in:st=0:d=2[a]",
                            "-map", "0:v", "-map", "[a]", "-c:v", "copy",
                            "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                            "-shortest", "-movflags", "+faststart", final])
        if r.returncode != 0: say("  Muxing failed."); return 1
        finals.append(final)

    say("")
    for final in finals:
        pr = subprocess.run([ffprobe, "-v", "error", "-show_entries",
                             "stream=width,height,r_frame_rate,codec_name,pix_fmt,profile,"
                             "color_primaries,color_transfer,color_space,color_range,"
                             "sample_rate,nb_frames,bit_rate",
                             "-show_entries", "format=duration,size,bit_rate",
                             "-of", "json", final], stdout=subprocess.PIPE)
        try:
            info = json.loads(pr.stdout.decode())
            v = next((x for x in info["streams"] if x.get("width")), {})
            a = next((x for x in info["streams"] if x.get("sample_rate")), {})
            fm = info["format"]
            dur = float(fm["duration"]); sz = int(fm["size"])
            say("  MASTER  %s" % os.path.basename(final))
            say("    %sx%s  %s fps  %s %s  %s  %s/%s/%s  range %s"
                % (v.get("width"), v.get("height"),
                   eval(v.get("r_frame_rate", "0/1")) if "/" in str(v.get("r_frame_rate")) else v.get("r_frame_rate"),
                   v.get("codec_name"), v.get("profile"), v.get("pix_fmt"),
                   v.get("color_primaries"), v.get("color_transfer"), v.get("color_space"),
                   v.get("color_range") or "unspecified"))
            say("    %s frames  %s  %s audio  %.2f GB  %.2f Mbps average"
                % (v.get("nb_frames"), hhmm(dur), a.get("sample_rate"),
                   sz / 1e9, int(fm.get("bit_rate", 0)) / 1e6))
            say("")
        except Exception:
            say("  Master written to %s" % final); say("")

    say(""); say("  Total time %s" % hhmm(time.time() - t0))
    say("  The segment files are in _segments. Delete that folder once you are happy.")
    return 0

if __name__ == "__main__":
    try: sys.exit(main())
    except KeyboardInterrupt:
        say(""); say("  Stopped. Run it again and it will pick up the unfinished segments.")
