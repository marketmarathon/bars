# Market Marathon — RaceKit (UK, "Biggest Companies 1996–2026")

Self-contained render kit. Produces `master.mp4` (~10.5 min, 1920×1080, 30fps).

## What's inside
- `racekit_full.js` — renderer (SVG → resvg → ffmpeg), one pass.
- `config.json` — all settings + feature flags (already switched on).
- `uk_race.json` (£bn data) + `uk_race_usd.json` (USD companion).
- `ftse.json` — weekly FTSE 100 for the live line + rolling monthly %.
- `panels/` — 62 event cards: `UK_YYYY_A` = world-macro (first 10s of the year), `UK_YYYY_B` = company event (second 10s).
- `fonts/` (Source Serif 4 SemiBold + IBM Plex), `company_logos/`, `logo.png`, `Emotional.mp3`.

## Features baked in (via config.json)
- `all_serif: true` — Source Serif 4 SemiBold everywhere.
- `panel_mode: true` — event panel behind bars + live FTSE line (with rolling month-over-month %).
- `show_usd: true` — USD equivalent stacked under each £ figure.
- Panel switches macro → company at mid-year (10s each), crossfading at the midpoint and year boundary.
- `year_sec: 20` — 20 seconds per year.

## Render on GitHub Actions (proven route)
1. Create/choose a repo. Commit this whole zip to the repo root (as a single `.zip` file).
2. Add `.github/workflows/render.yml` (copy from `render.yml` in this kit).
3. Run the workflow. `master.mp4` is published to the run's Releases/artifacts.

## Local render (reference)
```
npm ci
node racekit_full.js config.json      # writes master.mp4
```
Flags can also be forced via env: `ALL_SERIF=1 PANEL_MODE=1 SHOW_USD=1 node racekit_full.js config.json`.

## New country
Swap `uk_race.json` + `uk_race_usd.json`, the `panels/`, and `config.json` (title/subtitle/file_prefix). For native-language editions set `show_usd: false`.
