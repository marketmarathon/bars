#!/usr/bin/env bash
# Panels are bundled in ./panels (UK_YYYY_A = world-macro, UK_YYYY_B = company event). Nothing to fetch.
echo "Panels bundled: $(ls panels | wc -l) files"
