// RaceKit QUARTERLY renderer — period-aware fork of racekit_full.js.
// Bars race on QUARTER-END keyframes ("YYYY-Qn") instead of one point per year.
// Everything else follows the locked visual spec (Source Serif 4 SemiBold, #0F1420,
// top-10 bars / track 12, sub-sector colours + icons, MM logo 1:1, index scoreboard,
// v1.3.0 (D19) — card timing from card_timing_audit.json, 1f index geometry.
// {unit}100 total-return tracker, event cards keyed by A/B PLAY ORDER and activated in their
// genuine event month (no fixed macro/company order, no mid-year switch), outro).
//
// Usage: node racekit_q.js config.json
const { Resvg } = require('@resvg/resvg-js');
const { spawn } = require('child_process');
const fs = require('fs');

const cfg = JSON.parse(fs.readFileSync(process.argv[2] || 'config.json', 'utf8'));
const ROOT = __dirname;
const FPS = +(process.env.FPS || cfg.fps || 30);
// pace: quarter_sec is authoritative; fall back to year_sec/4 so existing configs keep their tempo
const QSEC = +(process.env.QUARTER_SEC || cfg.quarter_sec || (cfg.year_sec ? cfg.year_sec / 4 : 10));
const OUTRO_SEC = +(cfg.outro_sec || 20);
const XF = 0.8;
const W = 1920, H = 1080, TOPN = 10, K = 0.05;
const BG = cfg.bg || '#0F1420', ACCENT = cfg.accent || '#2EC4B6', GOLD = '#F5C453';
const OUT = cfg.out || 'master.mp4';

const ALL_SERIF = !!(process.env.ALL_SERIF || cfg.all_serif);
const PANEL_MODE = !!(process.env.PANEL_MODE || cfg.panel_mode);
const FF = 'SourceSerif4 SemiBold';
const ICONS = JSON.parse(fs.readFileSync(`${ROOT}/subsector_icons.json`, 'utf8'));
const ICON2 = JSON.parse(fs.readFileSync(`${ROOT}/${cfg.event_icons || 'event_icons_v2.json'}`, 'utf8'));
const LOGOS = (() => {
  // Era-correct monochrome company marks, harvested from Logopedia and processed to a single
  // colour (see the blueprint's logo pipeline). Embedded as data URIs so the kit needs no
  // resource path and a missing file fails at load, not mid-render.
  const dir = `${ROOT}/logos`, out = {};
  if (!fs.existsSync(dir)) return out;
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.png'))) {
    const b = fs.readFileSync(`${dir}/${f}`);
    // PNG header: width and height are big-endian uint32 at byte 16 and 20.
    out[f] = { w: b.readUInt32BE(16), h: b.readUInt32BE(20), uri: 'data:image/png;base64,' + b.toString('base64') };
  }
  console.error(`Company logos OK — ${Object.keys(out).length} era-correct marks loaded`);
  return out;
})();
const storyFail = m => { console.error(`\nSTORY ROLLER — ${m}\nThe v2 roller will not render without a valid story schedule.\n`); process.exit(1); };
// Headlines are drawn LIVE by the renderer over a text-free photograph — they are NOT baked
// Headlines are drawn LIVE by the renderer over a text-free photograph. The card file is
// STRUCTURED — "A" and "B" are PLAY ORDER, never category — and it is validated here. There is
// no fallback to the old string-only shape and no mid-year switching. Set 10 Aug 2026.
const MONNAMES = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
function cardsFail(why) {
  console.error(`\nERROR: event card data missing or non-conforming.\n  ${why}\n` +
    `Expected Market Marathon card schema:\n` +
    `- one entry per year, keys "A" and "B"\n` +
    `- A and B are PLAY ORDER: A is whichever event happened FIRST\n` +
    `- each carries event_date (YYYY-MM-DD), event_month (MMM YYYY), category, headline\n` +
    `- A.event_date <= B.event_date, both inside their own calendar year\n` +
    `- category is provenance only and must NEVER decide play order\n`);
  process.exit(2);
}
// ============================ v2 STORY ROLLER =============================================
// v2 TEST FORMAT — a rolling stack of the four most recent stories, bottom right. No photograph.
// This replaces the single full-bleed event card of v1. v1 is untouched and still shipped.
//
// WHY THIS EXISTS. v1 gave one card the whole screen, so two events close together fought for it
// and the schedule had to trade digest time against date accuracy (blueprint D20/D21). A roller
// has four slots, so an item stays up for four gaps — a story is readable for far longer AND
// activates on its own true date. The trade-off disappears rather than being balanced.
const stampFor = (prec, Y, M, D, MONN) => {
  // NEVER invent a day. The source dates some stories to the day, some only to a month, a
  // quarter or a whole year, and a fabricated "1 JAN" reads as a real catalyst date.
  switch (prec) {
    case 'day':     return `${D} ${MONN[M - 1]} ${Y}`;
    case 'month':   return `${MONN[M - 1]} ${Y}`;
    case 'quarter': return `Q${Math.floor((M - 1) / 3) + 1} ${Y}`;
    default:        return `${Y}`;
  }
};
const STORIES = (() => {
  const p = `${ROOT}/${cfg.stories_data || 'stories.json'}`;
  if (!fs.existsSync(p)) storyFail(`"${cfg.stories_data || 'stories.json'}" not found in the kit.`);
  let j; try { j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { storyFail(`not valid JSON — ${e.message}`); }
  if (!Array.isArray(j) || !j.length) storyFail('the stories file is not a non-empty array.');
  const MONN = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
  const out = [];
  for (const e of j) {
    for (const f of ['event_date', 'headline', 'icon']) {
      if (!e[f] || typeof e[f] !== 'string' || !e[f].trim()) storyFail(`a story is missing "${f}" (${JSON.stringify(e).slice(0, 90)})`);
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(e.event_date)) storyFail(`event_date "${e.event_date}" is not YYYY-MM-DD.`);
    if (!ICON2[e.icon]) storyFail(`icon "${e.icon}" is not in event_icons_v2.json.`);
    const Y = +e.event_date.slice(0, 4), M = +e.event_date.slice(5, 7), D = +e.event_date.slice(8, 10);
    const dim = new Date(Date.UTC(Y, M, 0)).getUTCDate();
    // sub = 'what viewers may see in the bar chart' — short, and it explains the BARS.
    //       'why it mattered to share prices' is 140 chars median and truncates.
    out.push({ t: Y + (M - 1) / 12 + (D - 1) / (12 * dim), year: Y,
               stamp: stampFor(e.date_precision, Y, M, D, MONN), headline: e.headline.trim(),
               sub: (e.chart || e.why || '').trim(),
               icon: e.icon,
               logo: e.logo || null,
               mark: e.company_mark || null });
  }
  out.sort((a, b) => a.t - b.t);
  // Chronology is the whole point: an item must never appear above an older one.
  for (let i = 1; i < out.length; i++) if (out[i].t < out[i - 1].t) storyFail('stories are not in chronological order after sorting — duplicate or malformed dates.');
  console.error(`Story roller OK — ${out.length} stories ${out[0].stamp} .. ${out[out.length - 1].stamp}`);
  return out;
})();
function storiesAt(pos) {
  // index of the newest story already reached, and how far we are into its arrival
  let k = 0;
  while (k < STORIES.length && STORIES[k].t <= pos + 1e-9) k++;
  return k;                                    // 0 = none yet
}

const data = JSON.parse(fs.readFileSync(`${ROOT}/${cfg.data}`, 'utf8'));
// REBRANDING (blueprint 1h). A company that renamed keeps ONE continuous series and carries a
// dated label list, so the bar never disappears and reappears — only the name changes. The old
// model split it into two entries, which made the bar vanish exactly when the story was most
// interesting to watch.
const REBRAND_SEC = 5;

// ---------- periods ----------
const PERIODS = data.periods;
(() => {                                  // bind each label change to its period index
  for (const c of data.companies) {
    if (!c.labels) continue;
    for (const L of c.labels) {
      const i = data.periods.indexOf(L.from_period);
      if (i < 0) { console.error(`\nRACE FILE — ${c.label}: label "${L.label}" starts at ${L.from_period}, which is not a period in this race.\n`); process.exit(1); }
      L.pi = i;
    }
    c.labels.sort((a, b) => a.pi - b.pi);
  }
})();
function labelAt(c, pi) {
  if (!c.labels || !c.labels.length) return { text: c.label, since: Infinity };
  let cur = c.labels[0];
  for (const L of c.labels) { if (L.pi <= pi + 1e-9) cur = L; else break; }
  return { text: cur.label, since: (pi - cur.pi) * QSEC, first: cur.pi === c.labels[0].pi };
}                       // ["2015-Q1", ...]
const NP = PERIODS.length;
const pYear = PERIODS.map(p => +p.slice(0, 4));
const pQ    = PERIODS.map(p => +p.slice(6));
const YEAR0 = pYear[0], YEARL = pYear[NP - 1];
// continuous position -> {year, fraction through that year}
// A period keyframe is the END of that quarter: "2024-Q4" is 31 December 2024, not 1 October.
// Everything on screen — bars, index YTD, month label, ROI tracker — reads off this, so they
// all agree on the date. Fixed 10 Aug 2026 after the tracker read October at the Q4 keyframe.
function yearPos(pi) {
  const i = Math.min(Math.floor(pi), NP - 1), f = Math.max(0, Math.min(1, pi - i));
  let yr = pYear[i], yf = ((pQ[i] - 1) + f) / 4 + 0.25;
  if (yf > 1) { yf -= 1; yr += 1; }
  return { yr, yf: Math.min(0.9999, yf) };
}
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

const comps = data.companies, colours = data.colours || {};
const unit = data.unit ?? cfg.unit ?? '€', suffix = data.suffix ?? cfg.suffix ?? 'bn';
const INDEX_NAME = cfg.index_name || ({ UK: 'FTSE 100', FR: 'CAC 40', DE: 'DAX' }[cfg.file_prefix] || 'the index');
const col = c => colours[c.sub] || '#4A6572';

const b64 = p => 'data:image/png;base64,' + fs.readFileSync(p).toString('base64');
const b64any = p => 'data:image/' + (/\.jpe?g$/i.test(p) ? 'jpeg' : 'png') + ';base64,' + fs.readFileSync(p).toString('base64');
const MMLOGO = fs.existsSync(`${ROOT}/logo.png`) ? b64(`${ROOT}/logo.png`) : null;
const PANEL_DIR = `${ROOT}/panels`;
// Panel stores keyed by PLAY ORDER. _A is whichever of the year's two events happened FIRST.
// They are NOT macro/company stores — do not infer category from these names.
const PANEL_A_B64 = {}, PANEL_B_B64 = {};
if (fs.existsSync(PANEL_DIR)) for (const f of fs.readdirSync(PANEL_DIR)) {
  const m = f.match(/_(\d{4})_(A|B)\.(?:png|jpe?g)$/i); if (!m) continue;
  (m[2] === 'A' ? PANEL_A_B64 : PANEL_B_B64)[+m[1]] = b64any(`${PANEL_DIR}/${f}`);
}

// ---------- index series (CAC 40 / FTSE 100 / ...) ----------
const IDX_FILE = cfg.index_data || 'cac.json';
const IDX_RAW = fs.existsSync(`${ROOT}/${IDX_FILE}`) ? JSON.parse(fs.readFileSync(`${ROOT}/${IDX_FILE}`, 'utf8')) : [];
const IDX = IDX_RAW.map(o => { const yr = +o.d.slice(0, 4), y0 = Date.UTC(yr, 0, 1), y1 = Date.UTC(yr + 1, 0, 1); return { p: o.p, yr, yf: (Date.parse(o.d) - y0) / ((y1 - y0) || 1) }; });
const YROPEN = {}, YRCLOSE = {};
{ const fd = {}, ld = {}; for (const o of IDX_RAW) { const y = +o.d.slice(0, 4); if (fd[y] === undefined || o.d < fd[y]) { fd[y] = o.d; YROPEN[y] = o.p; } if (ld[y] === undefined || o.d > ld[y]) { ld[y] = o.d; YRCLOSE[y] = o.p; } } }
const ANNRET = {}; for (const y in YRCLOSE) { const base = (YRCLOSE[+y - 1] !== undefined) ? YRCLOSE[+y - 1] : YROPEN[y]; ANNRET[y] = (YRCLOSE[y] / base - 1) * 100; }
// value of 100 invested at the first period of the race (not the first row of the index file)
const IDX_START = (() => { const s = IDX.filter(o => o.yr === YEAR0 && o.yf >= (pQ[0] - 1) / 4); return (s[0] || IDX[0] || { p: 1 }).p; })();

// ---------- layout ----------
const PANEL = { x: 1030, y: 204, w: 870, h: 870 };
// v3: the roller moves ABOVE the chart, so the chart starts lower and compresses.
// chartH, rowH, barH and FADE_EDGE all derive from M.top, so this one number does it.
// v4: the news band is a shallow full-width strip, so the chart reclaims almost all the height.
const M = { top: 230, left: 430, bottom: 42 };
// v3: the chart is now LEVEL with the right-hand column, so it must end clear of it.
// Longest bar ends at M.left + chartW/1.16; its value label adds ~170px. 1150 keeps the
// furthest label inside x~1225, clear of the column at 1240.
const BARMAX = 1150, chartW = BARMAX - M.left, chartH = H - M.top - M.bottom;
// Row geometry is compressible. During the race CZ = 1 (the approved geometry).
// Over the outro it eases down so all 10 final bars clear the closing-question band
// instead of the bottom three being covered — under re-ranking the bottom of the
// board is where entries and exits happen, so it has to stay readable.
const CZ_OUTRO = 0.715, CZ_RAMP_FR = 24;
let CZ = 1;
const rowH = () => (chartH / TOPN) * CZ, barH = () => rowH() * 0.82;
const rowY = r => M.top + r * rowH() + (rowH() - barH()) / 2;
const FADE_EDGE = () => M.top + (TOPN - 0.30) * rowH();
const lerp = (a, b, t) => a + (b - a) * t, clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const val = comps.map(c => c.vals.map(v => v == null ? 0 : v));
const hasv = comps.map(c => c.vals.map(v => v != null && v > 0));
// interpolate between adjacent QUARTERS; a company entering/leaving grows from / shrinks to 0
const vAt = (ci, pi) => { const i = Math.floor(pi), f = pi - i, j = Math.min(i + 1, NP - 1); const a = hasv[ci][i] ? val[ci][i] : 0, b = hasv[ci][j] ? val[ci][j] : 0; return lerp(a, b, f); };

// ---------- ROI / total-return tracker (blueprint 3b) ----------
// ---------- CANONICAL PERIOD FILE: REQUIRED, and validated. There is no fallback. ----------
// Under D17 us_periods.json is the SOLE runtime authority for the displayed month/date, the
// index YTD, the annual-return trail and every ROI value. The old roi_data tracker is
// superseded. A missing or non-conforming period file stops the render. Set 12 Aug 2026.
const ROI_STANDARD = `Expected Market Marathon canonical period file (schema "MarketMarathon-Periods-1"):
- SOLE runtime authority under D17 — there is no fallback and no second source
- Base = final trading close before starting year
- Total-return series includes reinvested dividends
- Price-only series uses same base date
- CPI uses corresponding base period; an unavailable month is carried as null, never imputed
- CAGR uses actual elapsed days / 365.25`;
function roiFail(why) {
  console.error(`\nERROR: canonical period file missing or non-conforming.\n  ${why}\n${ROI_STANDARD}\n`);
  process.exit(2);
}
const PERIOD_SCHEMA = 'MarketMarathon-Periods-1';
const CPI_UNAVAILABLE = 'OFFICIAL_SOURCE_NOT_PUBLISHED';
const PD = (() => {
  // Exactly one runtime pointer. A leftover roi_data would be a second, contradictory authority.
  if (cfg.roi_data !== undefined) roiFail(`config.json still carries "roi_data" (${JSON.stringify(cfg.roi_data)}). config.roi_data is superseded by D17 and must be removed — exactly one canonical period-data runtime pointer is permitted.`);
  if (!cfg.period_data) roiFail('config.json has no "period_data" entry — the canonical period file is the sole runtime authority under D17.');
  const p = `${ROOT}/${cfg.period_data}`;
  if (!fs.existsSync(p)) roiFail(`"${cfg.period_data}" not found in the kit.`);
  let j; try { j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { roiFail(`"${cfg.period_data}" is not valid JSON — ${e.message}`); }
  if (j.schema !== PERIOD_SCHEMA) roiFail(`"${cfg.period_data}" declares schema ${j.schema ? `"${j.schema}"` : 'absent'}, expected "${PERIOD_SCHEMA}".`);
  if (!Array.isArray(j.monthly) || !j.monthly.length) roiFail(`"${cfg.period_data}" has no "monthly" observations.`);
  if (!Array.isArray(j.periods) || !j.periods.length) roiFail(`"${cfg.period_data}" has no "periods" array.`);
  if (!j.base || typeof j.base !== 'object') roiFail(`"${cfg.period_data}" has no "base" object — the starting observation is missing.`);
  if (!j.render_scope || typeof j.render_scope !== 'object') roiFail(`"${cfg.period_data}" has no "render_scope" object.`);
  return j;
})();
// The renderer's internal series, built from the period file's monthly rows.
const ROI = (() => {
  const m = PD.monthly;
  return {
    months:              m.map(r => r.month),
    price_val:           m.map(r => r.price_val),
    div_paid_reinv:      m.map(r => r.div_contribution),
    total_reinv:         m.map(r => r.total_reinv),
    cagr_reinv_pct:      m.map(r => r.cagr_pct),
    real_reinv:          m.map(r => r.real_val),
    real_cagr_reinv_pct: m.map(r => r.real_cagr_pct),
    infl_cum_pct:        m.map(r => r.infl_cum_pct),
    // kept available to the drawing code
    display_date:        m.map(r => r.display_date),
    cpi_state:           m.map(r => r.cpi_state),
    index_ytd_pct:       m.map(r => r.index_ytd_pct),
    index_close:         m.map(r => r.index_close),
    display:             m.map(r => r.display)
  };
})();
// D17: the annual-return trail and the year-to-date base read the CANONICAL PERIOD FILE, never
// the weekly index-history file. The weekly file supplies line geometry only, and may never
// supply the displayed date, YTD, an annual return, an ROI value, the canonical base or an
// annual close. YRCLOSE / YROPEN / ANNRET are rebuilt here from the canonical annual table.
{
  for (const k of Object.keys(YRCLOSE)) delete YRCLOSE[k];
  for (const k of Object.keys(YROPEN)) delete YROPEN[k];
  for (const k of Object.keys(ANNRET)) delete ANNRET[k];
  for (const a of PD.annual || []) {
    YRCLOSE[a.year] = a.close;
    if (a.annual_return_pct != null) ANNRET[a.year] = a.annual_return_pct;
  }
}
const ROI_NOMINAL_KEYS = ['price_val', 'div_paid_reinv', 'total_reinv', 'cagr_reinv_pct'];
const ROI_CPI_KEYS = ['real_reinv', 'real_cagr_reinv_pct', 'infl_cum_pct'];
const ROI_KEYS = [...ROI_NOMINAL_KEYS, ...ROI_CPI_KEYS];
const ROI_PIX = [];   // period index -> row in the monthly arrays (from periods[].month_index)
function roiInit() {
  const need = ['months', ...ROI_KEYS];
  for (const k of need) {
    if (!Array.isArray(ROI[k])) roiFail(`"${cfg.period_data}" has no "${k}" values in its monthly rows.`);
    if (ROI[k].length !== ROI.months.length) roiFail(`"${k}" has ${ROI[k].length} values but there are ${ROI.months.length} months.`);
  }
  if (!ROI.months.length) roiFail(`"${cfg.period_data}" contains no observations.`);

  // ---- BASE OBSERVATION ----
  // The standard is not "some date in December of Y-1". It is THE FINAL TRADING SESSION
  // before 1 January of the start year. That is determined by the period-file GENERATOR from a
  // daily series and stamped in; the renderer holds only a weekly index file, so it cannot
  // rebuild the trading calendar itself. What it CAN do — and does — is refuse a file that
  // has not been through that process, and cross-check the stamp against the index series.
  const B = PD.base;
  if (!B.date || !B.level) roiFail('no "base.date" / "base.level" — the starting observation is missing.');
  const bd = String(B.date);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(bd)) roiFail(`"base.date" is "${bd}", expected YYYY-MM-DD.`);
  const by = +bd.slice(0, 4), bm = +bd.slice(5, 7);
  if (by !== YEAR0 - 1 || bm !== 12) roiFail(`"base.date" is ${bd}, but a race starting ${YEAR0} must be based on the final trading close of December ${YEAR0 - 1}.`);
  if (+B.value !== 100) roiFail(`"base.value" is ${B.value}, expected 100.`);
  if (!/daily/i.test(String(B.source || ''))) {
    roiFail(`"base.source" is ${B.source ? `"${B.source}"` : 'absent'}. The base must be resolved from a DAILY series by the period-file generator and stamped in, so that it is the actual final session before 1 January ${YEAR0} and not merely a December date.`);
  }
  if (IDX_RAW.length) {
    // Nothing in the index series may sit between the stamped base and the new year — if it
    // does, the stamp is not the final session. Catches an early or invented base date.
    const later = IDX_RAW.filter(o => o.d > bd && o.d < `${YEAR0}-01-01`);
    if (later.length) roiFail(`"base.date" is ${bd}, but the index series still trades on ${later[0].d}. The base must be the FINAL session before 1 January ${YEAR0}.`);
    const priorPts = IDX_RAW.filter(o => o.d <= bd && o.d >= `${YEAR0 - 1}-01-01`);
    if (!priorPts.length) roiFail(`the index series has no observation in ${YEAR0 - 1} at or before ${bd}, so the base cannot be verified.`);
    const gap = (Date.parse(bd) - Date.parse(priorPts[priorPts.length - 1].d)) / 86400000;
    if (gap > 7) roiFail(`"base.date" ${bd} is ${Math.round(gap)} days after the last index observation of ${YEAR0 - 1} (${priorPts[priorPts.length - 1].d}) — it cannot be a real trading session.`);
    const exact = IDX_RAW.find(o => o.d === bd);
    if (exact && Math.abs(exact.p / B.level - 1) > 0.0001) {
      roiFail(`"base.level" is ${B.level} but the index closed at ${exact.p} on ${bd}.`);
    }
    // The weekly index file usually has no point on the exact base date, so tie base.level to
    // the series instead: price_val is 100 x index / base.level, therefore the first
    // observation implies a base. It must agree with the one stamped in.
    if (!exact && ROI.price_val && ROI.price_val[0] > 0 && ROI.months && ROI.months[0]) {
      const m0 = ROI.months[0];
      const inM = IDX_RAW.filter(o => o.d.slice(0, 7) === m0);
      if (inM.length) {
        const implied = 100 * inM[inM.length - 1].p / ROI.price_val[0];
        if (Math.abs(implied / B.level - 1) > 0.05) {
          roiFail(`"base.level" is ${B.level}, but the ${m0} price-only value implies a base near ${implied.toFixed(2)}. The base level and the series disagree.`);
        }
      }
    }
  }

  // ---- MONTHLY OBSERVATIONS ----
  // Array length proves nothing. The dates themselves have to be right, because the renderer
  // now walks them and lands on each one exactly.
  const MRE = /^\d{4}-(0[1-9]|1[0-2])$/;
  const mnum = m => { const y = +m.slice(0, 4), mm = +m.slice(5, 7); return y * 12 + (mm - 1); };
  for (const m of ROI.months) if (!MRE.test(String(m))) roiFail(`"${m}" is not a valid YYYY-MM observation label.`);
  for (let i = 1; i < ROI.months.length; i++) {
    const a = mnum(ROI.months[i - 1]), b = mnum(ROI.months[i]);
    if (b === a) roiFail(`month ${ROI.months[i]} appears more than once.`);
    if (b < a) roiFail(`observations are not in order — ${ROI.months[i]} follows ${ROI.months[i - 1]}.`);
    if (b !== a + 1) roiFail(`gap in the monthly series between ${ROI.months[i - 1]} and ${ROI.months[i]} — ${b - a - 1} month(s) missing.`);
  }
  // The NOMINAL series must carry a real number at every observation, so all of them describe
  // the same periods rather than merely being the same length.
  for (const key of ROI_NOMINAL_KEYS) {
    const bad = ROI[key].findIndex(v => typeof v !== 'number' || !isFinite(v));
    if (bad >= 0) roiFail(`"${key}" has no usable value at ${ROI.months[bad]} — every nominal series must cover every observation.`);
  }
  // The CPI-DEPENDENT series may be null ONLY where that month's cpi_state says the official
  // source did not publish (D15). A null anywhere else is a hole; a NUMBER on an unavailable
  // month would be a fabricated inflation figure. Both stop the render.
  for (let i = 0; i < ROI.months.length; i++) {
    const out = ROI.cpi_state[i] === CPI_UNAVAILABLE;
    for (const key of ROI_CPI_KEYS) {
      const v = ROI[key][i], fin = (typeof v === 'number' && isFinite(v));
      if (!out && !fin) roiFail(`"${key}" is ${v === null ? 'null' : `"${v}"`} at ${ROI.months[i]}, whose cpi_state is "${ROI.cpi_state[i]}". A CPI-dependent value may only be null where cpi_state is "${CPI_UNAVAILABLE}".`);
      if (out && fin) roiFail(`"${key}" carries ${v} at ${ROI.months[i]}, but that month's cpi_state is "${CPI_UNAVAILABLE}" — a value here would be fabricated. It must be null.`);
    }
  }

  // ---- PERIODS ----
  // Every period the race lands on must be complete. There is no tolerance for a final
  // still-running quarter: a partial quarter is not a keyframe.
  PD.periods.forEach((p, k) => {
    if (p.is_complete !== true) roiFail(`period ${p.period} (${p.month}) is not complete — is_complete is ${JSON.stringify(p.is_complete)}. Every period in the canonical file must be complete before it can be rendered.`);
    const mi = p.month_index;
    if (!Number.isInteger(mi) || mi < 0 || mi >= ROI.months.length) roiFail(`period ${p.period} has month_index ${JSON.stringify(mi)}, which is not a row of the ${ROI.months.length} monthly observations.`);
    if (ROI.months[mi] !== p.month) roiFail(`period ${p.period} points at month_index ${mi}, which is ${ROI.months[mi]}, not ${p.month}.`);
    ROI_PIX.push(mi);
  });
  // The first monthly observation IS the first period — no pre-race baseline (D16).
  if (PD.monthly[0].month !== PD.periods[0].month) roiFail(`the first monthly observation is ${PD.monthly[0].month} but the first period is ${PD.periods[0].month} (${PD.periods[0].period}). The series must start at the first rendered period.`);
  if (PD.periods[0].month_index !== 0) roiFail(`the first period ${PD.periods[0].period} has month_index ${PD.periods[0].month_index}, expected 0.`);
  if (PD.periods[0].display_date !== PD.monthly[0].display_date) roiFail(`the first period ${PD.periods[0].period} is labelled "${PD.periods[0].display_date}" but its monthly observation is labelled "${PD.monthly[0].display_date}".`);
  // The race's period list and the period file must be the same list. Neither is truncated or
  // padded to fit the other — a disagreement means they describe different races.
  const RS = PD.render_scope, SCOPE = `render_scope is ${RS.start_period} (${RS.start_month}) .. ${RS.end_period} (${RS.end_month})`;
  const FP = PD.periods.map(p => p.period);
  for (let k = 0; k < Math.max(NP, FP.length); k++) {
    if (PERIODS[k] !== FP[k]) roiFail(`the race period list and the canonical period file disagree at index ${k}: the race has ${PERIODS[k] === undefined ? 'no period' : `"${PERIODS[k]}"`} but the period file has ${FP[k] === undefined ? 'no period' : `"${FP[k]}"`} (race ${NP} periods, period file ${FP.length}). ${SCOPE}.`);
  }
  console.error(`CANONICAL PERIOD DATA OK \u2014 ${ROI.months.length} monthly observations `
    + `${ROI.months[0]}..${ROI.months[ROI.months.length - 1]}, contiguous; `
    + `render scope ${RS.start_period} (${RS.start_month}) .. ${RS.end_period} (${RS.end_month}); `
    + `terminal period ${FP[FP.length - 1]}; ${FP.length} complete periods; `
    + `base ${B.date} @ ${B.level} (${B.source})`);
}
// Walks the MONTHLY observations, not the quarters. At an exact month the animation lands on
// the stored value; only the frames between two months are blended, and that blend exists for
// smoothness alone. These are monthly observations — never present them as daily market data.
function roiAt(pi) {
  if (!ROI_PIX.length) return null;
  const k = clamp(Math.floor(pi), 0, NP - 1), t = clamp(pi - k, 0, 1);
  const a = ROI_PIX[k], b = ROI_PIX[Math.min(k + 1, NP - 1)];
  const mi = a + (b - a) * t;                 // continuous position in MONTHS
  const i = Math.floor(mi), f = mi - i, j = Math.min(i + 1, ROI.months.length - 1);
  // D17: the displayed month/date and the year-to-date figure come from the canonical
  // monthly spine at EVERY frame, not only at exact observations. The weekly index-history
  // file supplies line geometry and nothing else. The month in effect is the row at i; it
  // ticks when the animation lands on the next row. Year-to-date is interpolated between
  // canonical monthly values, and is NEVER blended across a calendar-year boundary, because
  // year-to-date resets there - it snaps when the animation lands on the new year's row.
  const sameYear = ROI.months[i].slice(0, 4) === ROI.months[j].slice(0, 4);
  const o = { cpi_state: ROI.cpi_state[i], display_date: ROI.display_date[i], exact: f === 0,
              month: ROI.months[i], month_row: i, mfrac: f, blend: sameYear,
              index_close: (f === 0 || !sameYear) ? ROI.index_close[i]
                                                  : lerp(ROI.index_close[i], ROI.index_close[j], f),
              index_ytd_pct: (f === 0 || !sameYear) ? ROI.index_ytd_pct[i]
                                                    : lerp(ROI.index_ytd_pct[i], ROI.index_ytd_pct[j], f) };
  // A CPI-dependent value is NEVER interpolated into or out of a month the official source did
  // not publish — blending across it would invent an inflation figure. Those rows go out null.
  const cpiOut = ROI.cpi_state[i] === CPI_UNAVAILABLE || (f !== 0 && ROI.cpi_state[j] === CPI_UNAVAILABLE);
  if (f === 0) {                                                                 // exact observation
    for (const key of ROI_NOMINAL_KEYS) o[key] = ROI[key][i];
    for (const key of ROI_CPI_KEYS) o[key] = cpiOut ? null : ROI[key][i];
    return o;
  }
  for (const key of ROI_NOMINAL_KEYS) o[key] = lerp(ROI[key][i], ROI[key][j], f);
  for (const key of ROI_CPI_KEYS) o[key] = cpiOut ? null : lerp(ROI[key][i], ROI[key][j], f);
  return o;
}

roiInit();

const USD_ON = !!(process.env.SHOW_USD || cfg.show_usd);
const USDMAP = (() => { const p = `${ROOT}/${cfg.usd_data || ''}`; return (USD_ON && cfg.usd_data && fs.existsSync(p)) ? JSON.parse(fs.readFileSync(p, 'utf8')) : null; })();
const usdAt = (label, pi) => { const a = USDMAP && USDMAP[label]; if (!a) return null; const i = Math.floor(pi), f = pi - i, j = Math.min(i + 1, NP - 1); const p = a[i], q = a[j]; if (p == null && q == null) return null; return lerp(p || 0, q || 0, f); };

const fmt = v => unit + v.toLocaleString('en-GB', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + suffix;
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const fit = (n, base, mw) => { const w = n.length * base * 0.55; return w > mw ? Math.max(16, Math.floor(base * mw / w)) : base; };

// ---------- v2 story roller ----------
// Geometry is bounded by the same two things v1's headline was: the bars, whose top value label
// reaches x~1345, and the ROI tracker, which ends at y~570. Hence x >= 1360 and y >= 575.
// yTop MEASURED, not guessed: the ROI tracker's box runs from ty+12 to ty+370 where
// ty = 120 + 23 x (annual trail rows, max 5), so its lowest edge is y=605. 615 clears it.
// x0 MEASURED, not guessed. The roller occupies the LOWER half of the chart, where the bars are
// short — the long top bar is irrelevant to it. Instrumenting every 5th frame of the whole race,
// the rightmost bar value label among rows starting below y615 ends at x=1206 (2004-Q1
// Wal-Mart Stores, $258.3bn). x0=1240 clears every frame by 34px. Re-measure if barH, M.left,
// chartW or the value font size ever change.
// v3: across the top, above the chart. 780px wide gives a 656px text column (v2 had 544), so
// headlines wrap far less. The chart's top gridline labels sit at M.top-18 = 422, clearing 385.
// v4: HORIZONTAL. Three cards across the full width. A new story enters at the far LEFT and
// pushes the row right, so the oldest falls off the right-hand edge. Same slot arithmetic as the
// vertical roller — slot = n - 1 + f — only mapped to x instead of y.
const ROLL = { x0: 60, x1: 1900, yTop: 38, cardH: 160, slots: 3,
               icon: 104, iconH: 38, gap: 13, hl: 19, sub: 13, lhHL: 1.16, lhSub: 1.22, pad: 18 };
ROLL.pitch = (ROLL.x1 - ROLL.x0) / ROLL.slots;
const SLOT_OP = [1.0, 0.88, 0.74];           // newest at full strength, then falling away
const PUSH_SEC = 0.9;                              // how long a new item takes to push the stack

function wrapAt(txt, size, maxw, maxLines) {
  const per = Math.max(6, Math.floor(maxw / (size * 0.52)));
  const words = String(txt).split(/\s+/), lines = []; let cur = '';
  for (const w of words) {
    if (!cur.length) { cur = w; continue; }
    if ((cur + ' ' + w).length <= per) cur += ' ' + w; else { lines.push(cur); cur = w; }
  }
  if (cur.length) lines.push(cur);
  if (lines.length > maxLines) {
    const keep = lines.slice(0, maxLines);
    keep[maxLines - 1] = keep[maxLines - 1].replace(/[,;:.]?$/, '') + '…';
    return keep;
  }
  return lines;
}

function drawStoryIcon(s, st, x, y, w, h, op) {
  // Priority: the company's own era-correct logo, then a lettermark, then the event-type icon.
  if (st.logo && LOGOS[st.logo]) {
    const L = LOGOS[st.logo], k = Math.min(w / L.w, h / L.h);
    const dw = L.w * k, dh = L.h * k;
    s.push(`<g opacity="${op.toFixed(3)}"><image x="${(x + (w - dw) / 2).toFixed(1)}" y="${(y + (h - dh) / 2).toFixed(1)}" width="${dw.toFixed(1)}" height="${dh.toFixed(1)}" href="${L.uri}"/></g>`);
    return;
  }
  const sz = Math.min(w, h);
  const cx = x + (w - sz) / 2;
  if (st.mark) {
    const ini = st.mark.replace(/[^A-Za-z ]/g, '').split(/\s+/).filter(Boolean)
                       .slice(0, 2).map(w2 => w2[0].toUpperCase()).join('');
    s.push(`<g opacity="${op.toFixed(3)}">`);
    s.push(`<rect x="${cx}" y="${y}" width="${sz}" height="${sz}" rx="8" fill="none" stroke="#E8B23A" stroke-opacity="0.75" stroke-width="1.8"/>`);
    s.push(`<text x="${(cx + sz / 2).toFixed(1)}" y="${(y + sz / 2 + sz * 0.20).toFixed(1)}" font-size="${(sz * (ini.length > 1 ? 0.44 : 0.58)).toFixed(1)}" font-weight="700" fill="#E8B23A" text-anchor="middle">${esc(ini)}</text>`);
    s.push(`</g>`);
    return;
  }
  const I = ICON2[st.icon];
  s.push(`<g opacity="${op.toFixed(3)}"><svg x="${cx}" y="${y}" width="${sz}" height="${sz}" viewBox="0 0 ${I.w} ${I.h}">${I.body.replace(/currentColor/g, '#E8B23A')}</svg></g>`);
}


// ---------- v3 title card (bottom right) ----------
// The headline swaps places with the roller. It is a fixed, always-on block, so it can carry
// the country's identity in a way a scrolling list never could. The motif is VECTOR and chosen
// by cfg.motif, so every country in the series gets its own without a single image asset.
const CARD = { x: 1240, y: 832, w: 668, h: 178 };
function motifUSA(s, x, y, w, h) {
  // Thirteen stripes as a low-opacity ground, and a star field, drawn in the kit's own palette
  // rather than literal red/white/blue — it has to sit inside the Market Marathon look.
  const sh = h / 13;
  for (let i = 0; i < 13; i++) {
    if (i % 2) continue;
    s.push(`<rect x="${x}" y="${(y + i * sh).toFixed(1)}" width="${w}" height="${sh.toFixed(1)}" fill="#E8B23A" fill-opacity="0.075"/>`);
  }
  const cw = w * 0.40, ch = h * 0.62;
  s.push(`<rect x="${x}" y="${y}" width="${cw.toFixed(1)}" height="${ch.toFixed(1)}" fill="#8ea6b6" fill-opacity="0.05"/>`);
  const star = (cx, cy, r) => {
    const p = [];
    for (let k = 0; k < 10; k++) {
      const rr = k % 2 ? r * 0.42 : r, a = -Math.PI / 2 + k * Math.PI / 5;
      p.push(`${(cx + rr * Math.cos(a)).toFixed(1)},${(cy + rr * Math.sin(a)).toFixed(1)}`);
    }
    s.push(`<polygon points="${p.join(' ')}" fill="#E8B23A" fill-opacity="0.30"/>`);
  };
  for (let r = 0; r < 4; r++) for (let c = 0; c < 5; c++) {
    star(x + cw * (c + 0.6) / 5.2, y + ch * (r + 0.6) / 4.2, Math.min(cw / 5.2, ch / 4.2) * 0.30);
  }
}
function drawTitleCard(s) {
  const { x, y, w, h } = CARD;
  s.push(`<clipPath id="cardClip"><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="16"/></clipPath>`);
  s.push(`<g clip-path="url(#cardClip)">`);
  s.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#0d1626"/>`);
  // A quiet stripe wash only. The logo is the hero here, so no star field competing with it.
  if ((cfg.motif || '').toLowerCase() === 'usa') {
    const sh = h / 13;
    for (let i2 = 0; i2 < 13; i2 += 2)
      s.push(`<rect x="${x}" y="${(y + i2 * sh).toFixed(1)}" width="${w}" height="${sh.toFixed(1)}" fill="#E8B23A" fill-opacity="0.055"/>`);
  }
  s.push(`</g>`);
  s.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="16" fill="none" stroke="#E8B23A" stroke-opacity="0.28"/>`);

  const lw = 196, lh = 62;
  if (MMLOGO) s.push(`<image x="${x + 26}" y="${(y + (h - lh) / 2).toFixed(1)}" width="${lw}" height="${lh}" href="${MMLOGO}" preserveAspectRatio="xMinYMid meet"/>`);
  s.push(`<line x1="${x + 26 + lw + 22}" y1="${(y + 26).toFixed(1)}" x2="${x + 26 + lw + 22}" y2="${(y + h - 26).toFixed(1)}" stroke="#E8B23A" stroke-opacity="0.30"/>`);

  const tx = x + 26 + lw + 44, inner = w - (tx - x) - 26;
  let size = 30, lines = wrapAt(cfg.title, size, inner, 3);
  while (lines.length > 2 && size > 20) { size -= 2; lines = wrapAt(cfg.title, size, inner, 3); }
  const blockH = lines.length * size * 1.16 + 26;
  let ty = y + (h - blockH) / 2 + size * 0.9;
  for (const ln of lines) {
    s.push(`<text x="${tx}" y="${ty.toFixed(1)}" font-size="${size}" font-weight="700" fill="#f4f7fa">${esc(ln)}</text>`);
    ty += size * 1.16;
  }
  s.push(`<text x="${tx}" y="${(ty + 14).toFixed(1)}" font-size="17" fill="#9fb3c4">${esc(cfg.subtitle)}</text>`);
}

function drawRoller(s, pos) {
  const k = storiesAt(pos);
  if (!k) return;
  const newest = STORIES[k - 1];
  const f = clamp(((pos - newest.t) * QSEC * 4) / PUSH_SEC, 0, 1);
  const CW = ROLL.pitch, TX = ROLL.icon + ROLL.gap;      // text column inside a card
  const tw = CW - ROLL.pad * 2 - TX;

  s.push(`<text x="${ROLL.x0}" y="${ROLL.yTop - 6}" font-size="13" font-weight="700" fill="#E8B23A" letter-spacing="1.4">WHAT MOVED THE MARKET</text>`);
  s.push(`<line x1="${ROLL.x0}" y1="${ROLL.yTop + 2}" x2="${ROLL.x1}" y2="${ROLL.yTop + 2}" stroke="#E8B23A" stroke-opacity="0.30" stroke-width="1.2"/>`);
  s.push(`<clipPath id="rollClip"><rect x="${ROLL.x0 - 4}" y="${ROLL.yTop}" width="${ROLL.x1 - ROLL.x0 + 8}" height="${ROLL.cardH + 10}"/></clipPath>`);
  s.push(`<g clip-path="url(#rollClip)">`);

  for (let n = ROLL.slots; n >= 0; n--) {
    const st = STORIES[k - 1 - n];
    if (!st) continue;
    const slot = n - 1 + f;
    if (slot >= ROLL.slots) continue;
    const x0 = ROLL.x0 + slot * CW;
    const base = SLOT_OP[Math.min(Math.max(Math.round(slot), 0), SLOT_OP.length - 1)];
    let op = base;
    if (n === 0) op = base * f;
    else if (slot > ROLL.slots - 1) op = base * (ROLL.slots - slot);
    if (op <= 0.01) continue;

    const hlLines  = wrapAt(st.stamp + ' \u00b7 ' + st.headline, ROLL.hl, tw, 2);
    const subLines = wrapAt(st.sub, ROLL.sub, tw, 2);
    const y = ROLL.yTop + 16;
    drawStoryIcon(s, st, x0 + ROLL.pad, y, ROLL.icon, ROLL.iconH, Math.min(1, op + 0.12));
    let ty = y + ROLL.hl;
    for (let li = 0; li < hlLines.length; li++) {
      const ln = hlLines[li];
      if (li === 0) {
        const cut = ln.indexOf(' \u00b7 ');
        const g = cut >= 0 ? ln.slice(0, cut + 3) : '';
        const rest = cut >= 0 ? ln.slice(cut + 3) : ln;
        s.push(`<text x="${x0 + ROLL.pad + TX}" y="${ty.toFixed(1)}" font-size="${ROLL.hl}" font-weight="700" opacity="${op.toFixed(3)}"><tspan fill="#E8B23A">${esc(g)}</tspan><tspan fill="#F3EEE6">${esc(rest)}</tspan></text>`);
      } else {
        s.push(`<text x="${x0 + ROLL.pad + TX}" y="${ty.toFixed(1)}" font-size="${ROLL.hl}" font-weight="700" fill="#F3EEE6" opacity="${op.toFixed(3)}">${esc(ln)}</text>`);
      }
      ty += ROLL.hl * ROLL.lhHL;
    }
    ty += 3;
    for (const ln of subLines) {
      s.push(`<text x="${x0 + ROLL.pad + TX}" y="${ty.toFixed(1)}" font-size="${ROLL.sub}" font-weight="600" fill="#9fb3c4" opacity="${op.toFixed(3)}">${esc(ln)}</text>`);
      ty += ROLL.sub * ROLL.lhSub;
    }
    if (slot > 0.02) s.push(`<line x1="${x0.toFixed(1)}" y1="${(ROLL.yTop + 14)}" x2="${x0.toFixed(1)}" y2="${(ROLL.yTop + ROLL.cardH - 6)}" stroke="#ffffff" stroke-opacity="${(0.14 * op).toFixed(3)}"/>`);
  }
  s.push(`</g>`);
}

function drawIndex(s, pi, hold) {
  // The canonical month, its label and the year-to-date figure come from the period file.
  // IDX (the weekly index-history file) is used for the LINE SHAPE ONLY - it may never
  // supply the displayed date, the year-to-date, an annual return, an ROI value, the
  // canonical base or an annual close.
  const rLab = roiAt(hold ? NP - 1 : pi);
  if (!rLab) roiFail('the canonical period file produced no row for the current frame.');
  const yr = +rLab.month.slice(0, 4);
  // 1f: the year-fraction comes from the CANONICAL month, never from yearPos() — whose year rolls
  // over at the START of Q4, which emptied the line for the whole of December and restarted it in
  // January. The year and the fraction must come from the same authority.
  // The month-end observation for month m sits at m/12 of the year, and between two months the
  // tip glides with the same interpolation the printed figure uses — except across a calendar-year
  // boundary, where a year-to-date cannot be blended, so both the figure and the tip HOLD at
  // December and then snap. That gives exactly one reset per year and no gap.
  const frac = ((+rLab.month.slice(5, 7)) + (rLab.blend ? rLab.mfrac : 0)) / 12;
  const box = { x: 1240, y: 686, w: 668, h: 124 };   // v2.3: directly under the date block
  // 1f: the vertical scale is CONSTANT across every year, expressed as a percentage of the
  // previous year's canonical final close — the same base the year-to-date figure beside it uses,
  // so the line IS that percentage drawn over time and the two cannot disagree. Deriving the
  // scale from the year's own high and low both anticipates data the viewer has not reached and
  // stretches every year to fill the box, so a +-3% year read as violently as 2008.
  const BAND = 35;
  const ytdNow = rLab.index_ytd_pct;
  const pbase = YRCLOSE[yr - 1];
  if (pbase == null || !(pbase > 0)) roiFail(`the canonical annual table has no ${yr - 1} close, so the ${yr} index line has no +-${BAND}% reference (blueprint 1f).`);
  // v2.4: BACK TO THE WEEKLY SERIES for shape — 52 points a year, not 12. Twelve monthly points
  // read as fake, because they are: a month is not a market movement. But the v2.3 problem was
  // real, so the weekly series is now ANCHORED to the canonical monthly figures: at every month
  // end the line is shifted to pass exactly through the canonical year-to-date value, and the
  // shift is interpolated linearly between month ends. The weekly wiggle survives intact; the
  // line cannot drift from the printed number; and the tip is taken from the LINE ITSELF, so it
  // can never detach.
  const anch = [];
  for (let i = 0; i < ROI.months.length; i++) {
    if (+ROI.months[i].slice(0, 4) !== yr) continue;
    if (ROI.index_ytd_pct[i] == null) continue;
    anch.push({ yf: (+ROI.months[i].slice(5, 7)) / 12, ytd: ROI.index_ytd_pct[i] });
  }
  const wk = IDX.filter(o => o.yr === yr).map(o => ({ yf: o.yf, pct: (o.p / pbase - 1) * 100 }));
  const interp = (arr, key, f) => {                       // linear, flat outside the ends
    if (!arr.length) return 0;
    if (f <= arr[0].yf) return arr[0][key];
    for (let i = 1; i < arr.length; i++) {
      if (f <= arr[i].yf) {
        const a = arr[i - 1], b = arr[i], t = (f - a.yf) / ((b.yf - a.yf) || 1);
        return lerp(a[key], b[key], t);
      }
    }
    return arr[arr.length - 1][key];
  };
  const shift = anch.map(a => ({ yf: a.yf, d: a.ytd - interp(wk, 'pct', a.yf) }));
  const linePct = f => interp(wk, 'pct', f) + interp(shift, 'd', f);
  const yp = wk.map(o => ({ yf: o.yf, pct: o.pct + interp(shift, 'd', o.yf) }));

  if (yp.length >= 2) {
  const maxYf = Math.max(...yp.map(o => o.yf));
  const isPartial = maxYf < 0.95;                    // final, incomplete year
  const xs = (isPartial && maxYf > 0.05) ? 1 / maxYf : 1;
  const X = f => box.x + box.w * clamp(f * xs, 0, 1),
        Ypct = v => box.y + box.h - box.h * clamp((v + BAND) / (2 * BAND), 0, 1);
  // A 0% reference. The band is constant at +-35%, so without a baseline the eye has nothing to
  // judge the line against and a flat year reads as a stray squiggle rather than a flat year.
  s.push(`<line x1="${box.x}" y1="${Ypct(0).toFixed(1)}" x2="${box.x + box.w}" y2="${Ypct(0).toFixed(1)}" stroke="#8ea6b6" stroke-opacity="0.28" stroke-width="1" stroke-dasharray="4 4"/>`);
  s.push(`<text x="${box.x - 6}" y="${(Ypct(0) + 4).toFixed(1)}" font-size="12" fill="#8ea6b6" fill-opacity="0.65" text-anchor="end">0%</text>`);
  let pts = [], tip = null;
  for (let i = 0; i < yp.length; i++) { if (yp[i].yf <= frac + 1e-9) pts.push([X(yp[i].yf), Ypct(yp[i].pct)]); else break; }
  // 1f: the TIP is the canonical year-to-date figure printed beside it, never a second value
  // interpolated out of the weekly file. The weekly reduction gives the line its SHAPE; it may
  // not give the line its endpoint, or the line and the number can disagree — on 20 Aug 2026 a
  // weekly-derived tip read -7.5% beside a printed -17.8%.
  // v2.4: the tip is the LINE's own value at the current position, so it is on the line by
  // construction. It agrees with the printed figure exactly at every month end (that is what the
  // anchoring guarantees) and differs only by the intra-month weekly detail in between.
  if (yp.length) { tip = [X(frac), Ypct(linePct(frac))]; pts.push(tip); }
  if (pts.length > 1) {
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    s.push(`<path d="${d}" fill="none" stroke="${GOLD}" stroke-opacity="0.18" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"/>`);
    s.push(`<path d="${d}" fill="none" stroke="${GOLD}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`);
  }
  if (tip) s.push(`<circle cx="${tip[0].toFixed(1)}" cy="${tip[1].toFixed(1)}" r="9" fill="${GOLD}" fill-opacity="0.25"/><circle cx="${tip[0].toFixed(1)}" cy="${tip[1].toFixed(1)}" r="5" fill="${GOLD}"/>`);
  }
  const xL = 1240, colr = v => v >= 0 ? '#35c281' : '#e5565b', sg = v => v >= 0 ? '+' : '';
  const MLBL = esc(rLab.display_date);
  const ytd = ytdNow;   // the SAME value the line's tip was placed on
  // v2.3: LEFT-aligned, and sitting immediately above the graph it describes rather than floating
  // at the top of the column above the tracker. The date, the year-to-date and the year trail are
  // one block, and that block belongs to the chart.
  if (ytd != null) s.push(`<text x="${xL}" y="636" font-size="32" font-weight="700"><tspan fill="#eef3f7">${MLBL}: </tspan><tspan fill="${colr(ytd)}">${sg(ytd)}${ytd.toFixed(1)}%</tspan></text>`);
  // v2.2: the annual-return trail is ONE HORIZONTAL STRIP, not a five-row vertical list. That is
  // what releases the 358px block the tracker needs at the top of the column.
  { const yrs = [];
    for (let y = yr - 1; y >= yr - 5; y--) { const r = ANNRET[y]; if (r !== undefined) yrs.push([y, r]); }
    let tx2 = 1240;
    for (const [y, r] of yrs) {
      s.push(`<text x="${tx2}" y="664" font-size="19" font-weight="600"><tspan fill="#8ea6b6">${y} </tspan><tspan fill="${colr(r)}">${sg(r)}${r.toFixed(1)}%</tspan></text>`);
      tx2 += 136;
    }
  }
  drawROI(s, hold ? NP - 1 : pi, 228);    // v2.3: the tracker takes the top, y52..y410
}

// The $100 total-return tracker. Five rows: price only, dividends reinvested, a split bar
// showing the two as a proportion, the total with its CAGR, and the real value with its own
// real CAGR inline. Every figure is AS AT THE MONTH ON SCREEN, never as at the end of the
// race — see blueprint 3b.
function drawROI(s, pi, ty) {
  const r = roiAt(pi); if (!r) return;
  const colr = v => v >= 0 ? '#35c281' : '#e5565b', sg = v => v >= 0 ? '+' : '';
  const GREY = '#8ea6b6', DIMG = '#6a7c90', WHT = '#eef3f7', RULE = '#3a4459';
  const CX0 = 1528, CX1 = 1908, PADX = 20;
  const L = CX0 + PADX, R = CX1 - PADX, BW = R - L;
  const cy = ty + 12, CH = 358;   // 358 after the duplicate Total value row was removed

  // ---- figures. Round the two ENDS, derive the middle, so the column always adds up. ----
  const price = Math.round(r.price_val), total = Math.round(r.total_reinv);
  const divc  = total - price;                       // never shown as a non-reconciling number
  const totPc = (r.total_reinv / 100 - 1) * 100;
  // CPI-dependent figures are absent whenever the official source did not publish (D15).
  const inflOut = (r.real_reinv == null || r.real_cagr_reinv_pct == null || r.infl_cum_pct == null);
  const realV = inflOut ? null : Math.round(r.real_reinv), realPc = inflOut ? null : (r.real_reinv / 100 - 1) * 100;
  const n = v => v.toLocaleString('en-GB');
  const pc = v => sg(v) + Math.round(v).toLocaleString('en-GB') + '%';

  const txt = (x, y, t, size, fill, anchor, weight) =>
    s.push(`<text x="${x}" y="${y}" font-size="${size}" font-weight="${weight || 700}" fill="${fill}"${anchor ? ` text-anchor="${anchor}"` : ''}>${t}</text>`);
  const rule = (yy, x0, x1, col) => s.push(`<line x1="${x0 || L}" y1="${yy}" x2="${x1 || R}" y2="${yy}" stroke="${col || RULE}" stroke-width="1.5"/>`);

  s.push(`<rect x="${CX0}" y="${cy}" width="${CX1 - CX0}" height="${CH}" rx="14" fill="#0b1220" fill-opacity="0.93"/>`);

  // 1 — heading. FIXED WORDING. It names the index, which every non-USA edition needs:
  // "$100 INVESTED IN THE FTSE 100 · 1996", "€100 INVESTED IN THE CAC 40 · 2003".
  // Do not swap it for "IF YOU INVESTED $100 IN 1998…".
  txt(L, cy + 26, `${unit}100 INVESTED IN THE ${esc(INDEX_NAME)} · ${YEAR0}`, 15, GOLD);
  rule(cy + 38);

  // 2 — the hero number, then the return line. Nothing else on the card competes with this.
  txt(L, cy + 96, `${unit}${n(total)}`, 58, WHT);
  txt(L, cy + 120, 'TOTAL VALUE', 15, GREY);
  s.push(`<text x="${L}" y="${cy + 148}" font-size="17" font-weight="700">` +
    `<tspan fill="${colr(totPc)}">${pc(totPc)}</tspan><tspan fill="${GREY}"> TOTAL RETURN · </tspan>` +
    `<tspan fill="${colr(r.cagr_reinv_pct)}">${sg(r.cagr_reinv_pct)}${r.cagr_reinv_pct.toFixed(1)}%</tspan>` +
    `<tspan fill="${GREY}"> P.A.</tspan></text>`);
  rule(cy + 164);

  // 3 — the breakdown. TWO ROWS ONLY. The old "Total value" row was removed 10 Aug 2026 as
  // duplication — the hero number above already says it, and the bar below explains the split.
  txt(L, cy + 190, 'Share-price value', 18, GREY, null, 600);
  txt(R, cy + 190, `${unit}${n(price)}`, 20, WHT, 'end');
  txt(L, cy + 218, 'Dividend contribution', 18, GREY, null, 600);
  txt(R, cy + 218, `+${unit}${n(divc)}`, 20, GOLD, 'end');

  // 4 — composition bar. Carries real narrative weight: the gold segment visibly widens across
  // the decades, so it was given more height and clearer labels. Restrained, not a dashboard.
  const frP = clamp(price / (total || 1), 0, 1), by = cy + 238, BH2 = 20;
  s.push(`<rect x="${L}" y="${by}" width="${BW}" height="${BH2}" rx="3" fill="${GOLD}"/>`);
  s.push(`<rect x="${L}" y="${by}" width="${(BW * frP).toFixed(1)}" height="${BH2}" rx="3" fill="#f2ede5"/>`);
  if (BW * frP > 4) s.push(`<rect x="${(L + BW * frP - 1).toFixed(1)}" y="${by}" width="2" height="${BH2}" fill="#0b1220"/>`);
  s.push(`<text x="${L}" y="${cy + 280}" font-size="14" font-weight="700"><tspan fill="${WHT}">${unit}${n(price)}</tspan><tspan fill="${GREY}" font-weight="600"> PRICE</tspan></text>`);
  s.push(`<text x="${R}" y="${cy + 280}" text-anchor="end" font-size="14" font-weight="700"><tspan fill="${GOLD}">${unit}${n(divc)}</tspan><tspan fill="${GREY}" font-weight="600"> DIVIDENDS</tspan></text>`);

  // 5 — inflation, two tight lines, deliberately quiet. Where the official CPI observation does
  // not exist the lines say so. THE VIEWER IS NEVER SHOWN A FABRICATED INFLATION VALUE — the
  // nominal rows above are unaffected and keep rendering normally.
  rule(cy + 296);
  if (inflOut) {
    // D15: never invent a CPI-dependent value for a month the official source did not publish,
    // and never interpolate across one. But a blank row reads as a broken renderer.
    // So show the LAST ACTUALLY PUBLISHED figures and stamp them with the month they belong to.
    // Nothing is invented: these are September's real numbers, labelled as September's.
    let k = r.month_row;
    while (k > 0 && (ROI.cpi_state[k] === CPI_UNAVAILABLE || ROI.real_reinv[k] == null)) k--;
    const hv = Math.round(ROI.real_reinv[k]), hpc = (ROI.real_reinv[k] / 100 - 1) * 100;
    const hcg = ROI.real_cagr_reinv_pct[k], stamp = String(ROI.display_date[k]).toUpperCase();
    txt(L, cy + 320, `AFTER INFLATION · ${unit}${n(hv)}`, 15, DIMG, null, 700);
    s.push(`<text x="${(L + ('AFTER INFLATION · ' + unit + n(hv)).length * 15 * 0.55 + 8).toFixed(1)}" y="${cy + 320}" font-size="11" font-weight="700" fill="${GOLD}" letter-spacing="0.8">AT ${esc(stamp)}</text>`);
    s.push(`<text x="${L}" y="${cy + 342}" font-size="15" font-weight="600">` +
      `<tspan fill="${colr(hpc)}">${pc(hpc)}</tspan><tspan fill="${DIMG}"> real return · </tspan>` +
      `<tspan fill="${colr(hcg)}">${sg(hcg)}${hcg.toFixed(1)}%</tspan>` +
      `<tspan fill="${DIMG}"> p.a. · </tspan><tspan fill="${GREY}">CPI not yet published</tspan></text>`);
  } else {
    s.push(`<text x="${L}" y="${cy + 320}" font-size="15" font-weight="700"><tspan fill="${DIMG}">AFTER INFLATION · </tspan><tspan fill="${GREY}">${unit}${n(realV)}</tspan></text>`);
    s.push(`<text x="${L}" y="${cy + 342}" font-size="15" font-weight="600">` +
      `<tspan fill="${colr(realPc)}">${pc(realPc)}</tspan><tspan fill="${DIMG}"> real return · </tspan>` +
      `<tspan fill="${colr(r.real_cagr_reinv_pct)}">${sg(r.real_cagr_reinv_pct)}${r.real_cagr_reinv_pct.toFixed(1)}%</tspan>` +
      `<tspan fill="${DIMG}"> p.a.</tspan></text>`);
  }
}

const FR_PER = Math.round(QSEC * FPS);                 // frames per QUARTER
const FINAL_FR = Math.round(FR_PER * 0.6);
const raceFrames = FR_PER * (NP - 1) + FINAL_FR;
const outroFrames = Math.round(OUTRO_SEC * FPS);
const curY = new Array(comps.length).fill(null);

function frameSVG(fr, mode, ofr) {
  // outro: ease the row geometry down so the closing band never covers the bottom bars
  CZ = (mode === 'outro') ? (() => { const t = clamp((ofr || 0) / CZ_RAMP_FR, 0, 1); const e = t * t * (3 - 2 * t); return lerp(1, CZ_OUTRO, e); })() : 1;
  const piC = mode === 'outro' ? NP - 1 : Math.min((NP - 1) + FINAL_FR / FR_PER, fr / FR_PER);
  const { yr, yf } = yearPos(piC);
  const now = comps.map((c, ci) => ({ ci, v: vAt(ci, piC) }));
  const ranked = now.filter(o => o.v > 0).sort((a, b) => b.v - a.v);
  const rankOf = new Array(comps.length).fill(TOPN + 3); ranked.forEach((o, r) => rankOf[o.ci] = r);
  const kk = mode === 'outro' ? 1 : K;
  for (let ci = 0; ci < comps.length; ci++) { const tgt = rowY(Math.min(rankOf[ci], TOPN + 2)); curY[ci] = curY[ci] == null ? tgt : curY[ci] + (tgt - curY[ci]) * kk; }
  if (fr < 0) return null;
  if (process.env.RSTART !== undefined && (fr < +process.env.RSTART || fr >= +process.env.REND)) return null;
  const xmax = Math.max(...ranked.slice(0, TOPN).map(o => o.v), 1) * 1.16, x = v => chartW * (v / xmax);
  const vis = now.filter(o => o.v > 0 && curY[o.ci] < FADE_EDGE() + 2).sort((a, b) => curY[b.ci] - curY[a.ci]);

  const s = [`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="${FF}">`];
  s.push(`<defs>` +
    `<linearGradient id="fT" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="fB" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="fL" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="cardFade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d1626" stop-opacity="0"/><stop offset="1" stop-color="#0d1626"/></linearGradient>` +
    `<linearGradient id="fR" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient></defs>`);
  if (!process.env.TRANSPARENT) s.push(`<rect width="${W}" height="${H}" fill="${BG}"/>`);
  if (mode !== 'outro') { drawRoller(s, yr + yf); drawIndex(s, piC, false); }
  // v2: the outro carries no roller — the closing band owns the lower right.
  else { drawIndex(s, 0, true); }
  drawTitleCard(s);
  // A month/year chip immediately left of the $0 gridline. The date is also printed beside the
  // index, but that is across the frame from the bars — this puts the passage of time right where
  // the eye already is. Canonical period file, same source as every other date on screen.
  {
    const rl = roiAt(mode === 'outro' ? NP - 1 : piC);
    if (rl) {
      const t2 = String(rl.display_date).toUpperCase(), fsz = 23;
      const cw2 = t2.length * fsz * 0.60 + 28, ch2 = 34;
      const bx = M.left - 44 - cw2, by = M.top - 26 - ch2 / 2;
      s.push(`<rect x="${bx.toFixed(1)}" y="${by.toFixed(1)}" width="${cw2.toFixed(1)}" height="${ch2}" rx="7" fill="#101d31" stroke="#E8B23A" stroke-opacity="0.55"/>`);
      s.push(`<text x="${(bx + cw2 / 2).toFixed(1)}" y="${(by + ch2 / 2 + fsz * 0.35).toFixed(1)}" font-size="${fsz}" font-weight="700" fill="#E8B23A" letter-spacing="1.6" text-anchor="middle">${esc(t2)}</text>`);
    }
  }
  for (let t = 0; t <= 5; t++) { const gv = xmax * t / 5, gx = M.left + x(gv); s.push(`<line x1="${gx}" y1="${M.top - 8}" x2="${gx}" y2="${(M.top + chartH * CZ).toFixed(1)}" stroke="#ffffff" stroke-opacity="0.05"/><text x="${gx}" y="${M.top - 18}" font-size="20" fill="#5f7383" text-anchor="middle">${fmt(gv)}</text>`); }
  const BH = barH();
  for (const o of vis) {
    const c = comps[o.ci], y = curY[o.ci], a = clamp((FADE_EDGE() - y) / rowH(), 0, 1);
    const w = Math.max(3, x(o.v)), barEnd = M.left + w;
    const LB = labelAt(c, piC);
    const nm = fit(LB.text, Math.min(30, Math.round(30 * Math.max(CZ, 0.8))), M.left - 30);
    s.push(`<g opacity="${a.toFixed(3)}">`);
    s.push(`<rect x="${M.left}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${BH.toFixed(1)}" fill="${col(c)}"/>`);
    s.push(`<text x="${(M.left - 22).toFixed(1)}" y="${(y + BH / 2 + 9).toFixed(1)}" font-size="${nm}" font-weight="700" fill="#eaf0f4" text-anchor="end">${esc(LB.text)}</text>`);
    // REBRANDING flash: the name has just changed, so say so ON the bar for REBRAND_SEC seconds.
    // No colour change to the bar itself — only text, pulsing, so it reads as an event not a glitch.
    if (!LB.first && LB.since >= 0 && LB.since < REBRAND_SEC && w > 150) {
      const pulse = 0.45 + 0.55 * Math.abs(Math.sin(LB.since * Math.PI * 1.6));
      const fs2 = Math.max(13, BH * 0.30);
      s.push(`<text x="${(M.left + 18).toFixed(1)}" y="${(y + BH / 2 + fs2 * 0.36).toFixed(1)}" font-size="${fs2.toFixed(1)}" font-weight="700" letter-spacing="2.2" fill="#ffffff" opacity="${pulse.toFixed(3)}">REBRANDING</text>`);
    }
    const isz = BH * 0.60; const I = ICONS[c.sub];
    if (w > isz + 34 && I) s.push(`<svg x="${(barEnd - isz - 16).toFixed(1)}" y="${(y + (BH - isz) / 2).toFixed(1)}" width="${isz.toFixed(1)}" height="${isz.toFixed(1)}" viewBox="0 0 ${I.w} ${I.h}"><g fill="#ffffff" fill-opacity="0.92">${I.body}</g></svg>`);
    const u = USD_ON ? usdAt(c.label, piC) : null;
    const vy = (u != null && u > 0) ? (y + BH / 2 - 4) : (y + BH / 2 + 9);
    s.push(`<text x="${(barEnd + 16).toFixed(1)}" y="${vy.toFixed(1)}" font-size="28" font-weight="600" fill="#ffffff">${fmt(o.v)}</text>`);
    if (u != null && u > 0) s.push(`<text x="${(barEnd + 16).toFixed(1)}" y="${(y + BH / 2 + 22).toFixed(1)}" font-size="18" fill="#8ea6b6">($${u.toLocaleString('en-GB', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}bn)</text>`);
    s.push(`</g>`);
  }
  // v4: the Market Marathon logo has moved INTO the title card, bottom right.
  if (mode === 'outro') {
    const qh = 124, qy = H - 132 - qh;
    s.push(`<rect x="0" y="${qy}" width="${W}" height="${qh}" fill="#0b1220" fill-opacity="0.9"/>`);
    s.push(`<text x="${W / 2}" y="${qy + 52}" text-anchor="middle" font-size="40" font-weight="700" fill="#eef3f7">How will the ${esc(INDEX_NAME)} perform in ${YEARL + 1}?</text>`);
    s.push(`<text x="${W / 2}" y="${qy + 98}" text-anchor="middle" font-size="30" font-weight="600" fill="${GOLD}">Share your prediction in the comments below</text>`);
    const bh = 132; s.push(`<rect x="0" y="${H - bh}" width="${W}" height="${bh}" fill="#0b1220" fill-opacity="0.86"/><rect x="0" y="${H - bh}" width="${W}" height="5" fill="${ACCENT}"/>`);
    s.push(`<text x="70" y="${H - bh + 62}" font-size="52" font-weight="700" fill="#f0f4f8">SUBSCRIBE     •     LIKE     •     COMMENT</text>`);
    s.push(`<text x="72" y="${H - bh + 108}" font-size="28" font-weight="600" fill="#96aab9">for more Market Marathon bar chart races</text>`);
  }
  s.push(`</svg>`);
  return s.join('');
}

const SERIF_PATH = `${ROOT}/fonts/SourceSerif4-SemiBold.ttf`;
const opts = { fitTo: { mode: 'width', value: +(process.env.RASTER_W || W) }, font: { loadSystemFonts: false, fontFiles: [SERIF_PATH], defaultFontFamily: 'SourceSerif4 SemiBold' } };

const ff = spawn('ffmpeg', ['-y', '-f', 'image2pipe', '-c:v', 'png', '-r', String(FPS), '-i', 'pipe:0',
  ...(cfg.music ? ['-stream_loop', '-1', '-i', `${ROOT}/${cfg.music}`] : []),
  '-c:v', 'libx264', '-crf', String(cfg.crf || 16), '-preset', cfg.preset || 'medium', '-pix_fmt', 'yuv420p',
  ...(cfg.music ? ['-filter_complex', '[1:a]volume=0.65,afade=t=in:st=0:d=2[a]', '-map', '0:v', '-map', '[a]', '-c:a', 'aac', '-b:a', '192k', '-shortest'] : []),
  '-movflags', '+faststart', OUT], { stdio: ['pipe', 'inherit', 'inherit'] });
const write = buf => new Promise(res => { if (ff.stdin.write(buf)) res(); else ff.stdin.once('drain', res); });

(async () => {
  const t0 = Date.now(); let n = 0;
  const RF = Math.min(raceFrames, +(process.env.MAXFR || raceFrames));
  for (let fr = 0; fr < RF; fr++) { const svg = frameSVG(fr, 'race'); if (!svg) continue; await write(new Resvg(svg, opts).render().asPng()); if (++n % 300 === 0) console.error(`frame ${n}/${RF + outroFrames}`); }
  if (!process.env.NOOUTRO) for (let fr = 0; fr < outroFrames; fr++) { await write(new Resvg(frameSVG(raceFrames, 'outro', fr), opts).render().asPng()); if (++n % 300 === 0) console.error(`frame ${n}`); }
  ff.stdin.end();
  console.error(`piped ${n} frames in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
})();
ff.on('close', c => console.error('ffmpeg exit', c));
