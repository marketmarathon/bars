@echo off
setlocal
cd /d "%~dp0"
title FRANCE PREVIEW - INDEX LINE YEAR CHANGE
echo.
echo   FRANCE PREVIEW - THE CAC 40 LINE ACROSS A YEAR CHANGE
echo   -----------------------------------------------------
echo   About 23 seconds of the race at 1280 wide, running from late 2020
echo   into early 2021.
echo.
echo   Watch the CAC 40 %% line bottom right. It should sweep all the way to the
echo   right-hand edge, arrive there exactly as the year ends, and restart from
echo   the LEFT edge at zero on the next frame.
echo.
echo   What it used to do: reach the edge, sit there frozen for five seconds,
echo   then jump back in a third of the way along.
echo.
echo   This is NOT the master. It is the clip to look at before anything expensive runs.
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js is not installed.
  echo   Install the LTS build from nodejs.org, or run:  winget install OpenJS.NodeJS.LTS
  echo.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo   ffmpeg is not installed.
  echo   Run:  winget install Gyan.FFmpeg
  echo.
  pause
  exit /b 1
)

echo   Making sure the renderer's binary matches this machine...
call npm ci --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo   The dependency install failed. Nothing was rendered.
  pause
  exit /b 1
)
echo.

set RASTER_W=1280
set NOOUTRO=1
set SEG_START=33000
set SEG_END=33700
set SEG_OUT=FR_preview_yearchange.mp4
echo   Rendering frames 33000 to 33700. A few minutes.
echo.
node racekit_q.js
echo.
if exist FR_preview_yearchange.mp4 (
  echo   Making a playable copy...
  ffmpeg -v error -y -i FR_preview_yearchange.mp4 -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 20 -preset veryfast -c:a aac -b:a 160k -movflags +faststart FR_PREVIEW_YEARCHANGE_watch_me.mp4
  echo   Done. FR_PREVIEW_YEARCHANGE_watch_me.mp4 is in this folder.
  start "" "FR_PREVIEW_YEARCHANGE_watch_me.mp4"
) else (
  echo   The render did not produce a file. Read the messages above.
)
echo.
pause
