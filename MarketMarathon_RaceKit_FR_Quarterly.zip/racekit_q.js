// RaceKit QUARTERLY renderer — period-aware fork of racekit_full.js.
// Bars race on QUARTER-END keyframes ("YYYY-Qn") instead of one point per year.
// Everything else follows the locked visual spec (Source Serif 4 SemiBold, #0F1420,
// top-10 bars / track 12, sub-sector colours + icons, MM logo 1:1, index scoreboard,
// £100/€100 investment tracker, macro->company panel switch at mid-year, outro).
//
// Usage: node racekit_q.js config.json
const { Resvg } = require('@resvg/resvg-js');
const { spawn } = require('child_process');
const fs = require('fs');

const cfg = JSON.parse(fs.readFileSync(process.argv[2] || 'config.json', 'utf8'));
const ROOT = __dirname;
const FPS = +(process.env.FPS || cfg.fps || 30);
// pace: quarter_sec is authoritative; fall back to year_sec/4 so existing configs keep their tempo
const QSEC = +(process.env.QUARTER_SEC || cfg.quarter_sec || (cfg.year_sec ? cfg.year_sec / 4 : 10));
const OUTRO_SEC = +(cfg.outro_sec || 20);
const XF = 0.8;
const W = 1920, H = 1080, TOPN = 10, K = 0.05;
const BG = cfg.bg || '#0F1420', ACCENT = cfg.accent || '#2EC4B6', GOLD = '#F5C453';
const OUT = cfg.out || 'master.mp4';

const ALL_SERIF = !!(process.env.ALL_SERIF || cfg.all_serif);
const PANEL_MODE = !!(process.env.PANEL_MODE || cfg.panel_mode);
const FF = 'SourceSerif4 SemiBold';
const ICONS = JSON.parse(fs.readFileSync(`${ROOT}/subsector_icons.json`, 'utf8'));
const data = JSON.parse(fs.readFileSync(`${ROOT}/${cfg.data}`, 'utf8'));

// ---------- periods ----------
const PERIODS = data.periods;                       // ["2015-Q1", ...]
const NP = PERIODS.length;
const pYear = PERIODS.map(p => +p.slice(0, 4));
const pQ    = PERIODS.map(p => +p.slice(6));
const YEAR0 = pYear[0], YEARL = pYear[NP - 1];
// continuous position -> {year, fraction through that year}
function yearPos(pi) {
  const i = Math.min(Math.floor(pi), NP - 1), f = Math.max(0, Math.min(1, pi - i));
  return { yr: pYear[i], yf: Math.min(0.9999, ((pQ[i] - 1) + f) / 4) };
}

const comps = data.companies, colours = data.colours || {};
const unit = data.unit ?? cfg.unit ?? '€', suffix = data.suffix ?? cfg.suffix ?? 'bn';
const INDEX_NAME = cfg.index_name || ({ UK: 'FTSE 100', FR: 'CAC 40', DE: 'DAX' }[cfg.file_prefix] || 'the index');
const col = c => colours[c.sub] || '#4A6572';

const b64 = p => 'data:image/png;base64,' + fs.readFileSync(p).toString('base64');
const b64any = p => 'data:image/' + (/\.jpe?g$/i.test(p) ? 'jpeg' : 'png') + ';base64,' + fs.readFileSync(p).toString('base64');
const MMLOGO = fs.existsSync(`${ROOT}/logo.png`) ? b64(`${ROOT}/logo.png`) : null;
const PANEL_DIR = `${ROOT}/panels`;
const MACROB64 = {}, COB64 = {};
if (fs.existsSync(PANEL_DIR)) for (const f of fs.readdirSync(PANEL_DIR)) {
  const m = f.match(/_(\d{4})_(A|B)\.(?:png|jpe?g)$/i); if (!m) continue;
  (m[2] === 'A' ? MACROB64 : COB64)[+m[1]] = b64any(`${PANEL_DIR}/${f}`);
}

// ---------- index series (CAC 40 / FTSE 100 / ...) ----------
const IDX_FILE = cfg.index_data || 'cac.json';
const IDX_RAW = fs.existsSync(`${ROOT}/${IDX_FILE}`) ? JSON.parse(fs.readFileSync(`${ROOT}/${IDX_FILE}`, 'utf8')) : [];
const IDX = IDX_RAW.map(o => { const yr = +o.d.slice(0, 4), y0 = Date.UTC(yr, 0, 1), y1 = Date.UTC(yr + 1, 0, 1); return { p: o.p, yr, yf: (Date.parse(o.d) - y0) / ((y1 - y0) || 1) }; });
const YROPEN = {}, YRCLOSE = {};
{ const fd = {}, ld = {}; for (const o of IDX_RAW) { const y = +o.d.slice(0, 4); if (fd[y] === undefined || o.d < fd[y]) { fd[y] = o.d; YROPEN[y] = o.p; } if (ld[y] === undefined || o.d > ld[y]) { ld[y] = o.d; YRCLOSE[y] = o.p; } } }
const ANNRET = {}; for (const y in YRCLOSE) { const base = (YRCLOSE[+y - 1] !== undefined) ? YRCLOSE[+y - 1] : YROPEN[y]; ANNRET[y] = (YRCLOSE[y] / base - 1) * 100; }
// value of 100 invested at the first period of the race (not the first row of the index file)
const IDX_START = (() => { const s = IDX.filter(o => o.yr === YEAR0 && o.yf >= (pQ[0] - 1) / 4); return (s[0] || IDX[0] || { p: 1 }).p; })();

// ---------- layout ----------
const PANEL = { x: 1030, y: 204, w: 870, h: 870 };
const M = { top: 200, left: 430, bottom: 42 };
const BARMAX = 1310, chartW = BARMAX - M.left, chartH = H - M.top - M.bottom;
// Row geometry is compressible. During the race CZ = 1 (the approved geometry).
// Over the outro it eases down so all 10 final bars clear the closing-question band
// instead of the bottom three being covered — under re-ranking the bottom of the
// board is where entries and exits happen, so it has to stay readable.
const CZ_OUTRO = 0.715, CZ_RAMP_FR = 24;
let CZ = 1;
const rowH = () => (chartH / TOPN) * CZ, barH = () => rowH() * 0.82;
const rowY = r => M.top + r * rowH() + (rowH() - barH()) / 2;
const FADE_EDGE = () => M.top + (TOPN - 0.30) * rowH();
const lerp = (a, b, t) => a + (b - a) * t, clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const val = comps.map(c => c.vals.map(v => v == null ? 0 : v));
const hasv = comps.map(c => c.vals.map(v => v != null && v > 0));
// interpolate between adjacent QUARTERS; a company entering/leaving grows from / shrinks to 0
const vAt = (ci, pi) => { const i = Math.floor(pi), f = pi - i, j = Math.min(i + 1, NP - 1); const a = hasv[ci][i] ? val[ci][i] : 0, b = hasv[ci][j] ? val[ci][j] : 0; return lerp(a, b, f); };

const USD_ON = !!(process.env.SHOW_USD || cfg.show_usd);
const USDMAP = (() => { const p = `${ROOT}/${cfg.usd_data || ''}`; return (USD_ON && cfg.usd_data && fs.existsSync(p)) ? JSON.parse(fs.readFileSync(p, 'utf8')) : null; })();
const usdAt = (label, pi) => { const a = USDMAP && USDMAP[label]; if (!a) return null; const i = Math.floor(pi), f = pi - i, j = Math.min(i + 1, NP - 1); const p = a[i], q = a[j]; if (p == null && q == null) return null; return lerp(p || 0, q || 0, f); };

const fmt = v => unit + v.toLocaleString('en-GB', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + suffix;
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const fit = (n, base, mw) => { const w = n.length * base * 0.55; return w > mw ? Math.max(16, Math.floor(base * mw / w)) : base; };

function drawPanel(s, yr, yf) {
  const F = 150, X = PANEL.x, Y = PANEL.y, Wd = PANEL.w, Hd = PANEL.h;
  const draw = (href, op) => {
    if (!href || op <= 0) return;
    s.push(`<g opacity="${op.toFixed(3)}"><image x="${X}" y="${Y}" width="${Wd}" height="${Hd}" href="${href}" preserveAspectRatio="xMidYMid slice"/>`);
    s.push(`<rect x="${X}" y="${Y}" width="${Wd}" height="${F}" fill="url(#fT)"/><rect x="${X}" y="${Y + Hd - F}" width="${Wd}" height="${F}" fill="url(#fB)"/><rect x="${X}" y="${Y}" width="${F}" height="${Hd}" fill="url(#fL)"/><rect x="${X + Wd - F}" y="${Y}" width="${F}" height="${Hd}" fill="url(#fR)"/></g>`);
  };
  const xf = XF / (QSEC * 4);                       // crossfade width expressed in year-fraction
  const macro = MACROB64[yr], co = COB64[yr];
  const nextCard = (yr + 1 > YEARL) ? null : ((yr + 1 === YEARL) ? (COB64[yr + 1] || MACROB64[yr + 1]) : MACROB64[yr + 1]);
  if (yf < 0.5 - xf) draw(macro, 1);
  else if (yf < 0.5) { const t = (yf - (0.5 - xf)) / xf; draw(macro, 1 - t); draw(co, t); }
  else if (yf < 1 - xf) draw(co, 1);
  else if (nextCard) { const t = (yf - (1 - xf)) / xf; draw(co, 1 - t); draw(nextCard, t); }
  else draw(co, 1);
}

function drawIndex(s, pi, hold) {
  if (!IDX.length) return;
  const { yr, yf } = hold ? { yr: YEARL, yf: (pQ[NP - 1]) / 4 } : yearPos(pi);
  const frac = yf;
  const yp = IDX.filter(o => o.yr === yr); if (yp.length < 2) return;
  const box = { x: 1385, y: 44, w: 290, h: 150 };
  const maxYf = Math.max(...yp.map(o => o.yf));
  const isPartial = maxYf < 0.95;                    // final, incomplete year
  const xs = (isPartial && maxYf > 0.05) ? 1 / maxYf : 1;
  const pmin = Math.min(...yp.map(o => o.p)), pmax = Math.max(...yp.map(o => o.p));
  const X = f => box.x + box.w * clamp(f * xs, 0, 1), Y = p => box.y + box.h - box.h * ((p - pmin) / ((pmax - pmin) || 1));
  let pts = [], tip = null, curPrice = null;
  for (let i = 0; i < yp.length; i++) { if (yp[i].yf <= frac) { pts.push([X(yp[i].yf), Y(yp[i].p)]); curPrice = yp[i].p; } else break; }
  for (let i = 1; i < yp.length; i++) { if (yp[i].yf >= frac) { const a = yp[i - 1], b = yp[i], t = (frac - a.yf) / ((b.yf - a.yf) || 1); curPrice = lerp(a.p, b.p, t); tip = [X(frac), Y(curPrice)]; pts.push(tip); break; } }
  if (!tip && pts.length) tip = pts[pts.length - 1];
  if (pts.length > 1) {
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    s.push(`<path d="${d}" fill="none" stroke="${GOLD}" stroke-opacity="0.18" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"/>`);
    s.push(`<path d="${d}" fill="none" stroke="${GOLD}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`);
  }
  if (tip) s.push(`<circle cx="${tip[0].toFixed(1)}" cy="${tip[1].toFixed(1)}" r="9" fill="${GOLD}" fill-opacity="0.25"/><circle cx="${tip[0].toFixed(1)}" cy="${tip[1].toFixed(1)}" r="5" fill="${GOLD}"/>`);
  const xR = 1892, colr = v => v >= 0 ? '#35c281' : '#e5565b', sg = v => v >= 0 ? '+' : '';
  const base = (YRCLOSE[yr - 1] !== undefined) ? YRCLOSE[yr - 1] : yp[0].p;
  const ytd = (curPrice != null && base) ? (curPrice / base - 1) * 100 : null;
  if (ytd != null) s.push(`<text x="${xR}" y="88" text-anchor="end" font-size="32" font-weight="700"><tspan fill="#eef3f7">${yr}: </tspan><tspan fill="${colr(ytd)}">${sg(ytd)}${ytd.toFixed(1)}%</tspan></text>`);
  let ty = 120;
  for (let y = yr - 1; y >= yr - 5; y--) { const r = ANNRET[y]; if (r === undefined) continue; s.push(`<text x="${xR}" y="${ty}" text-anchor="end" font-size="22" font-weight="600"><tspan fill="#8ea6b6">${y}: </tspan><tspan fill="${colr(r)}">${sg(r)}${r.toFixed(1)}%</tspan></text>`); ty += 23; }
  if (curPrice != null) {
    const v100 = 100 * curPrice / IDX_START, tot = v100 - 100;
    const elapsed = (yr - YEAR0) + frac - (pQ[0] - 1) / 4;
    const cagr = elapsed > 0.75 ? ((Math.pow(v100 / 100, 1 / elapsed) - 1) * 100) : null;
    const cy = ty + 24;
    s.push(`<rect x="1556" y="${cy - 26}" width="352" height="118" rx="14" fill="#0b1220" fill-opacity="0.55"/>`);
    s.push(`<text x="${xR}" y="${cy}" text-anchor="end" font-size="18" font-weight="700" fill="#8ea6b6">${unit}100 IN THE ${INDEX_NAME} · ${YEAR0}</text>`);
    s.push(`<text x="${xR}" y="${cy + 40}" text-anchor="end" font-size="34" font-weight="700"><tspan fill="#eef3f7">${unit}${v100.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</tspan><tspan fill="${colr(tot)}" font-size="26">  ${sg(tot)}${tot.toFixed(1)}%</tspan></text>`);
    if (cagr != null) s.push(`<text x="${xR}" y="${cy + 72}" text-anchor="end" font-size="20" font-weight="600"><tspan fill="#8ea6b6">CAGR </tspan><tspan fill="${colr(cagr)}">${sg(cagr)}${cagr.toFixed(1)}% / yr</tspan></text>`);
  }
}

const FR_PER = Math.round(QSEC * FPS);                 // frames per QUARTER
const FINAL_FR = Math.round(FR_PER * 0.6);
const raceFrames = FR_PER * (NP - 1) + FINAL_FR;
const outroFrames = Math.round(OUTRO_SEC * FPS);
const curY = new Array(comps.length).fill(null);

function frameSVG(fr, mode, ofr) {
  // outro: ease the row geometry down so the closing band never covers the bottom bars
  CZ = (mode === 'outro') ? (() => { const t = clamp((ofr || 0) / CZ_RAMP_FR, 0, 1); const e = t * t * (3 - 2 * t); return lerp(1, CZ_OUTRO, e); })() : 1;
  const piC = mode === 'outro' ? NP - 1 : Math.min((NP - 1) + FINAL_FR / FR_PER, fr / FR_PER);
  const { yr, yf } = yearPos(piC);
  const now = comps.map((c, ci) => ({ ci, v: vAt(ci, piC) }));
  const ranked = now.filter(o => o.v > 0).sort((a, b) => b.v - a.v);
  const rankOf = new Array(comps.length).fill(TOPN + 3); ranked.forEach((o, r) => rankOf[o.ci] = r);
  const kk = mode === 'outro' ? 1 : K;
  for (let ci = 0; ci < comps.length; ci++) { const tgt = rowY(Math.min(rankOf[ci], TOPN + 2)); curY[ci] = curY[ci] == null ? tgt : curY[ci] + (tgt - curY[ci]) * kk; }
  if (fr < 0) return null;
  if (process.env.RSTART !== undefined && (fr < +process.env.RSTART || fr >= +process.env.REND)) return null;
  const xmax = Math.max(...ranked.slice(0, TOPN).map(o => o.v), 1) * 1.16, x = v => chartW * (v / xmax);
  const vis = now.filter(o => o.v > 0 && curY[o.ci] < FADE_EDGE() + 2).sort((a, b) => curY[b.ci] - curY[a.ci]);

  const s = [`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="${FF}">`];
  s.push(`<defs>` +
    `<linearGradient id="fT" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="fB" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="fL" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="fR" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="${BG}"/><stop offset="1" stop-color="${BG}" stop-opacity="0"/></linearGradient></defs>`);
  if (!process.env.TRANSPARENT) s.push(`<rect width="${W}" height="${H}" fill="${BG}"/>`);
  if (mode !== 'outro') { if (PANEL_MODE) drawPanel(s, yr, yf); drawIndex(s, piC, false); }
  else { if (PANEL_MODE) drawPanel(s, YEARL, (pQ[NP - 1]) / 4); drawIndex(s, 0, true); }
  s.push(`<text x="${M.left}" y="80" font-size="50" font-weight="700" fill="#eef3f7">${esc(cfg.title)}</text>`);
  s.push(`<text x="${M.left}" y="120" font-size="26" fill="#8ba1b0">${esc(cfg.subtitle)}</text>`);
  // quarter stamp — the race now moves 4x per year, so name the quarter explicitly
  if (mode !== 'outro') {
    const qi = Math.min(Math.floor(piC), NP - 1);
    s.push(`<text x="${M.left}" y="166" font-size="30" font-weight="700" fill="${ACCENT}">${PERIODS[qi].replace('-', ' ')}</text>`);
  }
  for (let t = 0; t <= 5; t++) { const gv = xmax * t / 5, gx = M.left + x(gv); s.push(`<line x1="${gx}" y1="${M.top - 8}" x2="${gx}" y2="${(M.top + chartH * CZ).toFixed(1)}" stroke="#ffffff" stroke-opacity="0.05"/><text x="${gx}" y="${M.top - 18}" font-size="20" fill="#5f7383" text-anchor="middle">${fmt(gv)}</text>`); }
  const BH = barH();
  for (const o of vis) {
    const c = comps[o.ci], y = curY[o.ci], a = clamp((FADE_EDGE() - y) / rowH(), 0, 1);
    const w = Math.max(3, x(o.v)), barEnd = M.left + w;
    const nm = fit(c.label, Math.min(30, Math.round(30 * Math.max(CZ, 0.8))), M.left - 30);
    s.push(`<g opacity="${a.toFixed(3)}">`);
    s.push(`<rect x="${M.left}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${BH.toFixed(1)}" fill="${col(c)}"/>`);
    s.push(`<text x="${(M.left - 22).toFixed(1)}" y="${(y + BH / 2 + 9).toFixed(1)}" font-size="${nm}" font-weight="700" fill="#eaf0f4" text-anchor="end">${esc(c.label)}</text>`);
    const isz = BH * 0.60; const I = ICONS[c.sub];
    if (w > isz + 34 && I) s.push(`<svg x="${(barEnd - isz - 16).toFixed(1)}" y="${(y + (BH - isz) / 2).toFixed(1)}" width="${isz.toFixed(1)}" height="${isz.toFixed(1)}" viewBox="0 0 ${I.w} ${I.h}"><g fill="#ffffff" fill-opacity="0.92">${I.body}</g></svg>`);
    const u = USD_ON ? usdAt(c.label, piC) : null;
    const vy = (u != null && u > 0) ? (y + BH / 2 - 4) : (y + BH / 2 + 9);
    s.push(`<text x="${(barEnd + 16).toFixed(1)}" y="${vy.toFixed(1)}" font-size="28" font-weight="600" fill="#ffffff">${fmt(o.v)}</text>`);
    if (u != null && u > 0) s.push(`<text x="${(barEnd + 16).toFixed(1)}" y="${(y + BH / 2 + 22).toFixed(1)}" font-size="18" fill="#8ea6b6">($${u.toLocaleString('en-GB', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}bn)</text>`);
    s.push(`</g>`);
  }
  if (MMLOGO) s.push(`<image x="40" y="26" width="354" height="112" href="${MMLOGO}" preserveAspectRatio="xMinYMid meet"/>`);
  if (mode === 'outro') {
    const qh = 124, qy = H - 132 - qh;
    s.push(`<rect x="0" y="${qy}" width="${W}" height="${qh}" fill="#0b1220" fill-opacity="0.9"/>`);
    s.push(`<text x="${W / 2}" y="${qy + 52}" text-anchor="middle" font-size="40" font-weight="700" fill="#eef3f7">How will the ${INDEX_NAME} perform in ${YEARL + 1}?</text>`);
    s.push(`<text x="${W / 2}" y="${qy + 98}" text-anchor="middle" font-size="30" font-weight="600" fill="${GOLD}">Share your prediction in the comments below</text>`);
    const bh = 132; s.push(`<rect x="0" y="${H - bh}" width="${W}" height="${bh}" fill="#0b1220" fill-opacity="0.86"/><rect x="0" y="${H - bh}" width="${W}" height="5" fill="${ACCENT}"/>`);
    s.push(`<text x="70" y="${H - bh + 62}" font-size="52" font-weight="700" fill="#f0f4f8">SUBSCRIBE     •     LIKE     •     COMMENT</text>`);
    s.push(`<text x="72" y="${H - bh + 108}" font-size="28" font-weight="600" fill="#96aab9">for more Market Marathon bar chart races</text>`);
  }
  s.push(`</svg>`);
  return s.join('');
}

const SERIF_PATH = `${ROOT}/fonts/SourceSerif4-SemiBold.ttf`;
const opts = { fitTo: { mode: 'width', value: +(process.env.RASTER_W || W) }, font: { loadSystemFonts: false, fontFiles: [SERIF_PATH], defaultFontFamily: 'SourceSerif4 SemiBold' } };

const ff = spawn('ffmpeg', ['-y', '-f', 'image2pipe', '-c:v', 'png', '-r', String(FPS), '-i', 'pipe:0',
  ...(cfg.music ? ['-stream_loop', '-1', '-i', `${ROOT}/${cfg.music}`] : []),
  '-c:v', 'libx264', '-crf', String(cfg.crf || 16), '-preset', cfg.preset || 'medium', '-pix_fmt', 'yuv420p',
  ...(cfg.music ? ['-filter_complex', '[1:a]volume=0.65,afade=t=in:st=0:d=2[a]', '-map', '0:v', '-map', '[a]', '-c:a', 'aac', '-b:a', '192k', '-shortest'] : []),
  '-movflags', '+faststart', OUT], { stdio: ['pipe', 'inherit', 'inherit'] });
const write = buf => new Promise(res => { if (ff.stdin.write(buf)) res(); else ff.stdin.once('drain', res); });

(async () => {
  const t0 = Date.now(); let n = 0;
  const RF = Math.min(raceFrames, +(process.env.MAXFR || raceFrames));
  for (let fr = 0; fr < RF; fr++) { const svg = frameSVG(fr, 'race'); if (!svg) continue; await write(new Resvg(svg, opts).render().asPng()); if (++n % 300 === 0) console.error(`frame ${n}/${RF + outroFrames}`); }
  if (!process.env.NOOUTRO) for (let fr = 0; fr < outroFrames; fr++) { await write(new Resvg(frameSVG(raceFrames, 'outro', fr), opts).render().asPng()); if (++n % 300 === 0) console.error(`frame ${n}`); }
  ff.stdin.end();
  console.error(`piped ${n} frames in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
})();
ff.on('close', c => console.error('ffmpeg exit', c));
